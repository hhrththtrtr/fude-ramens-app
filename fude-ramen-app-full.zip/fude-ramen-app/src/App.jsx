import { useState, useEffect, useRef, useMemo, createContext, useContext } from 'react';
import { Phone, ChefHat, Gift, ArrowLeft, Plus, Minus, User, LogOut, Search, History, Sparkles, Store, UserCircle2, Trash2, X, ShoppingBag, Clock, Check, Receipt, Package, Bell, CreditCard, Lock, CheckCircle2, Loader2, Eye, EyeOff, MessageSquare, Image, Upload, Camera } from 'lucide-react';
import MENU_IMAGES from './menu-images.json';

const MENU = {
  ramen: [
    { id: 'rm19', name: '19 Eby supu ramen', price: 14.9, desc: 'Ramen in brodo di fude, gamberi* argentini, uovo marinato, naruto*, bambù marinato, spinaci, baby pannocchie di mais, cipollotto', allergens: ['Crostacei', 'Uova', 'Pesce', 'Soia', 'Sesamo', 'Solfiti'], emoji: '🍜' },
    { id: 'rm20', name: '20 Hot ramen', price: 14.9, desc: 'Ramen in brodo di manzo, ragù di manzo, uovo marinato, naruto*, bambù marinato, spinaci, germogli di soia, cipollotto, salsa piccante', allergens: ['Uova', 'Pesce', 'Soia', 'Sesamo', 'Solfiti'], emoji: '🍜' },
    { id: 'rm21', name: '21 Gyukotsu ramen', price: 15.9, desc: 'Ramen in brodo di manzo, bambù marinato, spinaci, chashu di manzo, uovo marinato, naruto*, germogli di soia, cipollotto', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia', 'Sesamo'], emoji: '🍜' },
    { id: 'rm22', name: '22 Miso ramen', price: 14.9, desc: 'Ramen in brodo di miso, chashu di maiale, uovo marinato, naruto*, bacon, broccoli, germogli di soia, cipollotto', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia', 'Molluschi'], emoji: '🍜' },
    { id: 'rm23', name: '23 Miso spicy ramen', price: 15.9, desc: 'Ramen in brodo di miso, chashu di maiale, naruto, mais, cipollotto, bambù, uovo marinato, bacon, salsa piccante', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia', 'Molluschi', 'Sesamo'], emoji: '🌶️' },
    { id: 'rm24', name: '24 Tonkotsu beef ramen', price: 16.9, desc: 'Ramen in brodo di manzo, chashu di manzo, chashu di maiale, uovo marinato, naruto*, bambù, spinaci e cipollotto', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia', 'Sesamo'], emoji: '🍜' },
    { id: 'rm25', name: '25 Vege ramen', price: 13.9, desc: 'Ramen in brodo di miso, tofu alla piastra, ceci, bambù marinato, spinaci, broccoli, germogli di soia, cipollotto', allergens: ['Glutine', 'Uova', 'Soia', 'Sesamo', 'Solfiti', 'Lupini', 'Molluschi'], emoji: '🌿' },
    { id: 'rm26', name: '26 Karaage ramen', price: 15.9, desc: 'Ramen in brodo di fude, pollo fritto*, uovo marinato, naruto*, bambù marinato, spinaci, baby pannocchie di mais, cipollotto', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia', 'Sesamo'], emoji: '🍗' },
    { id: 'rm27', name: '27 Salmon ramen', price: 16.9, desc: 'Ramen in brodo di fude, salmone alla piastra, uovo marinato, naruto*, bambù marinato, spinaci, baby pannocchie di mais, cipollotto', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia', 'Sesamo'], emoji: '🐟' },
    { id: 'rm28', name: '28 Eby ramen', price: 15.9, desc: 'Ramen in brodo di fude, tempura di gamberi*, funghi enoki, uovo marinato, naruto*, bambù marinato, spinaci, baby pannocchie di mais, cipollotto', allergens: ['Glutine', 'Crostacei', 'Uova', 'Pesce', 'Soia', 'Sesamo', 'Solfiti'], emoji: '🦐' },
    { id: 'rm29', name: '29 Red gyukotsu ramen', price: 18.9, desc: 'Ramen in brodo di manzo, manzo al pomodoro, uovo marinato, bambù, cipollotto, spinaci, broccoli', allergens: ['Glutine', 'Uova', 'Soia', 'Sesamo', 'Molluschi'], emoji: '🔴' },
    { id: 'rm30', name: '30 Fude ramen', price: 18.9, desc: 'Ramen in brodo di fude, capesante*, vongole*, funghi enoki, chashu di manzo, uovo marinato, naruto*, bambù marinato, spinaci, baby pannocchie di mais, cipollotto', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia', 'Sesamo', 'Solfiti', 'Molluschi'], emoji: '⭐' },
    { id: 'rm31', name: '31 Dry beef noodles', price: 14.9, desc: 'Ramen senza brodo, ragù di manzo, uovo in camicia, mais, cipollotto, broccoli, 7 spezie', allergens: ['Glutine', 'Uova', 'Soia', 'Sesamo', 'Molluschi'], emoji: '🍜' },
  ],
  antipasti: [
    { id: 'a1', name: '1 Takoyaki', price: 7, desc: 'Polpette di polipo* fritte con salsa teriyaki, maionese e tonno essiccato', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia', 'Latte', 'Senape', 'Molluschi'], emoji: '🐙' },
    { id: 'a2', name: '2 Bao pork', price: 4.5, desc: 'Bao al vapore* con carne di suino, insalata e salsa spicy mayo', allergens: ['Glutine', 'Uova', 'Latte'], emoji: '🥙' },
    { id: 'a3', name: '3 Bao carne', price: 2.5, desc: 'Pane bianco al vapore* con carne di suino, cipollotto e funghi', allergens: ['Glutine', 'Uova', 'Arachidi', 'Soia', 'Latte', 'Senape', 'Sesamo', 'Molluschi'], emoji: '🥙' },
    { id: 'a4', name: '4 Pringles maguro', price: 6, desc: 'Tartare di tonno pinna gialla con pringles, philadelphia', allergens: ['Pesce', 'Soia', 'Latte'], emoji: '🐟' },
    { id: 'a5', name: '5 Pringles sakè', price: 6, desc: 'Tartare di salmone con pringles, philadelphia', allergens: ['Pesce', 'Soia', 'Latte'], emoji: '🐟' },
    { id: 'a6', name: '6 Wakame', price: 5, desc: 'Alghe verdi', allergens: ['Soia', 'Sesamo'], emoji: '🌿' },
    { id: 'a7', name: '7 Edamame', price: 5, desc: 'Fagioli di soia', allergens: ['Soia'], emoji: '🫘' },
    { id: 'a8', name: '8 Zuppa di miso', price: 4.5, desc: 'Zuppa di soia con alghe, tofu, erba cipollina', allergens: ['Soia', 'Sesamo', 'Molluschi'], emoji: '🍵' },
    { id: 'a9', name: '9 Ebi spring roll', price: 6, desc: 'Involtini in foglio di riso, mazzancolla in tempura, insalata iceberg, avocado, frittatina, mayo giapponese', allergens: ['Crostacei', 'Soia', 'Solfiti'], emoji: '🥗' },
    { id: 'a17', name: '17 Crispy gyoza', price: 7.5, desc: 'Ravioli alla piastra, salsa, cheddar, salsa teriyaki, cipolla fritta', allergens: ['Glutine', 'Crostacei', 'Uova', 'Soia', 'Latte', 'Sedano', 'Senape', 'Sesamo'], emoji: '🥟' },
    { id: 'a18', name: '18 Pork gyoza', price: 7.5, desc: 'Ravioli alla piastra, maionese, salsa teriyaki, meat floss', allergens: ['Glutine', 'Crostacei', 'Uova', 'Soia', 'Latte', 'Sedano', 'Senape', 'Sesamo'], emoji: '🥟' },
    { id: 'a53', name: '53 Poke vegetariano', price: 8, desc: 'Riso bianco, avocado, cetriolo, carota, edamame*, ceci, mais, sesamo', allergens: ['Soia', 'Sesamo', 'Solfiti', 'Lupini'], emoji: '🥗' },
    { id: 'a54', name: '54 Poke tropicale', price: 10, desc: 'Riso bianco, salmone, mango, edamame*, mais, avocado', allergens: ['Pesce', 'Soia', 'Sesamo'], emoji: '🥗' },
  ],
  ravioli: [
    { id: 'r10', name: '10 Ravioli di pollo alla piastra', price: 6, desc: 'Ravioli* di pollo alla piastra', allergens: ['Soia', 'Glutine', 'Sesamo', 'Molluschi'], emoji: '🥟' },
    { id: 'r11', name: '11 Ravioli di pollo al vapore', price: 6, desc: 'Ravioli* di pollo al vapore', allergens: ['Soia', 'Glutine', 'Sesamo', 'Molluschi'], emoji: '🥟' },
    { id: 'r12', name: '12 Ravioli di verdura alla piastra', price: 6, desc: 'Ravioli di verdura alla piastra', allergens: ['Soia', 'Sesamo'], emoji: '🥟' },
    { id: 'r13', name: '13 Ravioli di verdura al vapore', price: 6, desc: 'Ravioli di verdura al vapore', allergens: ['Soia', 'Sesamo'], emoji: '🥟' },
    { id: 'r14', name: '14 Ravioli di gamberi', price: 6, desc: 'Ravioli di gamberi al vapore', allergens: ['Crostacei', 'Pesce', 'Sesamo', 'Soia'], emoji: '🥟' },
    { id: 'r15', name: '15 Ravioli di carne alla piastra', price: 6, desc: 'Ravioli di carne alla piastra', allergens: ['Crostacei', 'Uova', 'Soia', 'Sedano', 'Sesamo'], emoji: '🥟' },
    { id: 'r16', name: '16 Ravioli di carne al vapore', price: 6, desc: 'Ravioli di carne al vapore', allergens: ['Crostacei', 'Uova', 'Soia', 'Sedano', 'Sesamo'], emoji: '🥟' },
  ],
  pasta: [
    { id: 'p36', name: '36 Udon ai frutti di mare', price: 13, desc: 'Spaghetti di grano duro con pesce misto, verdure, germogli di soia', allergens: ['Crostacei', 'Pesce', 'Soia', 'Solfiti', 'Molluschi'], emoji: '🍝' },
    { id: 'p37', name: '37 Udon vege', price: 8, desc: 'Spaghetti di grano tenero con verdure, germogli di soia', allergens: ['Glutine', 'Soia'], emoji: '🍝' },
    { id: 'p38', name: '38 Verdure miste', price: 5, desc: 'Germogli di soia, carote, zucchine', allergens: ['Glutine', 'Soia', 'Sesamo'], emoji: '🥦' },
    { id: 'p39', name: '39 Yakisoba capesante e zenzero', price: 12, desc: 'Spaghetti di grano saraceno con capesante, zenzero fresco, verdure', allergens: ['Glutine', 'Soia', 'Molluschi'], emoji: '🍝' },
    { id: 'p40', name: '40 Chicken soba', price: 11, desc: 'Yakisoba saltati con pollo, carote, zucchine', allergens: ['Glutine', 'Uova', 'Soia'], emoji: '🍝' },
    { id: 'p41', name: '41 Riso chicken', price: 10, desc: 'Riso saltato con pollo, carote, zucchine, uova', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia'], emoji: '🍚' },
    { id: 'p42', name: '42 Riso capesante e zafferano', price: 12, desc: 'Riso saltato con capesante*, zafferano, carote, zucchine', allergens: ['Glutine', 'Pesce', 'Soia', 'Molluschi'], emoji: '🍚' },
    { id: 'p43', name: '43 Riso ebi', price: 12, desc: 'Riso saltato con gamberi*, carote, zucchine', allergens: ['Glutine', 'Crostacei', 'Uova', 'Pesce', 'Soia', 'Solfiti'], emoji: '🍚' },
    { id: 'p44', name: '44 Riso bianco', price: 3, desc: 'Riso al vapore', allergens: ['Sesamo'], emoji: '🍚' },
  ],
  tempura: [
    { id: 't45', name: '45 Ebi tempura', price: 12, desc: 'Tempura di gamberi*', allergens: ['Glutine', 'Crostacei', 'Soia', 'Solfiti'], emoji: '🍤' },
    { id: 't46', name: '46 Yasai tempura', price: 9, desc: 'Tempura di carote, zucchine, patate dolci', allergens: ['Glutine', 'Soia'], emoji: '🍤' },
    { id: 't47', name: '47 Karaage', price: 9, desc: 'Pollo fritto* giapponese, maionese, salsa teriyaki, 7 spezie', allergens: ['Glutine', 'Uova', 'Pesce', 'Soia', 'Latte', 'Senape'], emoji: '🍗' },
    { id: 't48', name: '48 Tempura mista', price: 12, desc: 'Tempura di gamberi, zucchine, carote, patate dolci', allergens: ['Glutine', 'Crostacei', 'Solfiti'], emoji: '🍤' },
    { id: 't49', name: '49 Tekka teppanyaki', price: 14, desc: 'Filetto di tonno pinna gialla alla piastra con sesamo, salsa teriyaki', allergens: ['Glutine', 'Pesce', 'Soia', 'Sesamo'], emoji: '🥩' },
    { id: 't50', name: '50 Sake teppanyaki', price: 13, desc: 'Filetto di salmone alla piastra con sesamo, salsa teriyaki', allergens: ['Glutine', 'Pesce', 'Soia', 'Sesamo'], emoji: '🥩' },
    { id: 't51', name: '51 Yakiebi – 4pz', price: 8, desc: 'Spiedini di gamberi*', allergens: ['Glutine', 'Crostacei', 'Soia', 'Solfiti'], emoji: '🍢' },
    { id: 't52', name: '52 Yakitori – 4pz', price: 7, desc: 'Spiedini di pollo', allergens: ['Glutine', 'Soia'], emoji: '🍢' },
  ],
  sushi_party: [
    { id: 'sp64', name: '64 Party 45', price: 45, desc: 'Mix di 45 pezzi di sushi', allergens: ['Pesce', 'Glutine', 'Soia', 'Sesamo'], emoji: '🎉' },
    { id: 'sp65', name: '65 Party 65', price: 65, desc: 'Mix di 65 pezzi di sushi', allergens: ['Pesce', 'Glutine', 'Soia', 'Sesamo'], emoji: '🎉' },
    { id: 'sp66', name: '66 Party 25', price: 25, desc: 'Mix di 25 pezzi di sushi', allergens: ['Pesce', 'Glutine', 'Soia'], emoji: '🎉' },
    { id: 'sp67', name: '67 Happy Party', price: 18, desc: '4 pezzi di akira, 4 pezzi di philadelphia, 4 pezzi di rainbow, 4 pezzi di uramaki misti', allergens: ['Pesce', 'Glutine', 'Soia', 'Sesamo', 'Latte'], emoji: '🎉' },
    { id: 'sp68', name: '68 Party Salmone', price: 19, desc: '2 pezzi nigiri salmone, 2 pezzi nigiri salmone scottato, 4 pezzi hoso sake, 4 pezzi uramaki salmone', allergens: ['Pesce', 'Soia'], emoji: '🐟' },
  ],
  nigiri: [
    { id: 'ni69', name: '69 Nigiri Salmone – 8pz', price: 10, desc: 'Riso, salmone', allergens: ['Pesce', 'Soia'], emoji: '🍱' },
    { id: 'ni70', name: '70 Nigiri Tonno Pinna Gialla – 8pz', price: 12, desc: 'Riso, tonno pinna gialla', allergens: ['Pesce', 'Soia'], emoji: '🍱' },
    { id: 'ni107', name: '107 Nigiri Avocado', price: 3, desc: 'Riso, avocado', allergens: [], emoji: '🍱' },
    { id: 'ni108', name: '108 Nigiri Sake', price: 3, desc: 'Riso, salmone', allergens: ['Pesce', 'Soia'], emoji: '🍱' },
    { id: 'ni109', name: '109 Nigiri Maguro', price: 3.5, desc: 'Riso, tonno pinna gialla', allergens: ['Pesce', 'Soia'], emoji: '🍱' },
    { id: 'ni110', name: '110 Nigiri Branzino', price: 3, desc: 'Riso, branzino', allergens: ['Pesce', 'Soia'], emoji: '🍱' },
    { id: 'ni111', name: '111 Nigiri Amaebi', price: 3.5, desc: 'Riso, gambero', allergens: ['Crostacei', 'Soia'], emoji: '🍱' },
    { id: 'ni112', name: '112 Nigiri Ebi', price: 3.5, desc: 'Riso, mazzancolla al vapore', allergens: ['Crostacei', 'Soia'], emoji: '🍱' },
    { id: 'ni113', name: '113 Nigiri Anguilla', price: 4, desc: 'Riso, alga, anguilla, salsa teriyaki', allergens: ['Pesce', 'Glutine', 'Soia'], emoji: '🍱' },
    { id: 'ni114', name: '114 Nigiri Gourmet', price: 16, desc: '2 nigiri salmone con avocado e ikura*, 2 nigiri tonno pinna gialla con tartufo, 2 nigiri capesante* con tobiko*', allergens: ['Pesce', 'Molluschi', 'Soia'], emoji: '⭐' },
  ],
  sashimi: [
    { id: 'sa115', name: '115 Sashimi Matzu – 12pz', price: 15, desc: '3 fette di salmone, 3 fette di tonno pinna gialla, 3 fette di branzino, 3 fette miste', allergens: ['Pesce'], emoji: '🐟' },
    { id: 'sa116', name: '116 Sashimi Sake – 4pz', price: 12, desc: 'Salmone', allergens: ['Pesce'], emoji: '🐟' },
    { id: 'sa117', name: '117 Sashimi Maguro – 4pz', price: 13, desc: 'Tonno pinna gialla', allergens: ['Pesce'], emoji: '🐟' },
    { id: 'sa118', name: '118 Sashimi Branzino – 4pz', price: 11, desc: 'Branzino', allergens: ['Pesce'], emoji: '🐟' },
    { id: 'sa119', name: '119 Sashimi Scampo – 3pz', price: 9, desc: 'Scampo', allergens: ['Crostacei'], emoji: '🦐' },
    { id: 'sa120', name: '120 Sashimi Gamberi – 3pz', price: 10, desc: 'Gamberi', allergens: ['Crostacei'], emoji: '🦐' },
    { id: 'sa121', name: '121 Sashimi Capesante – 5pz', price: 9, desc: 'Capesante', allergens: ['Molluschi'], emoji: '🐚' },
    { id: 'sa122', name: '122 Sashimi Amaebi – 3pz', price: 4.5, desc: 'Gamberi crudi', allergens: ['Crostacei'], emoji: '🦐' },
  ],
  gunkan: [
    { id: 'gk61', name: '61 Gunkan Sake', price: 5, desc: 'Riso avvolto con salmone, tabasco, erba cipollina, tobiko*', allergens: ['Pesce', 'Soia', 'Sesamo'], emoji: '🦪' },
    { id: 'gk62', name: '62 Gunkan Mango', price: 6, desc: 'Tartare di salmone avvolto con il mango, tabasco, erba cipollina, tobiko*', allergens: ['Pesce', 'Soia', 'Sesamo'], emoji: '🦪' },
    { id: 'gk63', name: '63 Gunkan Maguro', price: 6, desc: 'Riso avvolto con tonno pinna gialla, tabasco, erba cipollina, tobiko*', allergens: ['Pesce', 'Soia', 'Sesamo'], emoji: '🦪' },
  ],
  tartare: [
    { id: 'ta58', name: '58 Tartare Sake', price: 10, desc: 'Tartare di salmone, erba cipollina', allergens: ['Pesce', 'Soia'], emoji: '🐟' },
    { id: 'ta59', name: '59 Tartare Maguro', price: 11, desc: 'Tartare di tonno pinna gialla, erba cipollina', allergens: ['Pesce', 'Soia'], emoji: '🐟' },
    { id: 'ta60', name: '60 Tartare Waikiki', price: 13, desc: 'Tartare di salmone con avocado, passion fruit, uova di lompo*, lime', allergens: ['Pesce', 'Molluschi'], emoji: '🐟' },
  ],
  hosomaki: [
    { id: 'ho74', name: '74 Hoso Jungle', price: 5, desc: 'Foglia di riso, insalata gentile, salmone, cetriolo', allergens: ['Pesce', 'Soia'], emoji: '🌿' },
    { id: 'ho75', name: '75 Hosomaki Sake', price: 4.5, desc: 'Riso, alga, salmone', allergens: ['Pesce'], emoji: '🌀' },
    { id: 'ho76', name: '76 Hosomaki Maguro', price: 5, desc: 'Riso, alga, tonno pinna gialla', allergens: ['Pesce'], emoji: '🌀' },
    { id: 'ho77', name: '77 Hosomaki Ebi', price: 5, desc: 'Riso, alga, mazzancolla* al vapore', allergens: ['Crostacei'], emoji: '🌀' },
    { id: 'ho78', name: '78 Hosomaki Avocado', price: 4, desc: 'Riso, alga, avocado', allergens: [], emoji: '🌀' },
    { id: 'ho79', name: '79 Huso Ebi Tempura', price: 7, desc: 'Riso, alga impanata fritta, gamberi cotti*, salsa teriyaki', allergens: ['Crostacei', 'Glutine', 'Sesamo'], emoji: '🌀' },
    { id: 'ho80', name: '80 Hoso Sake Red', price: 7, desc: 'Riso, alga impanata fritta, salmone cotto, philadelphia, fragola', allergens: ['Pesce', 'Latte', 'Glutine'], emoji: '🌀' },
  ],
  uramaki: [
    { id: 'ur81', name: '81 Uramaki Philadelphia', price: 8.5, desc: 'Riso, alga, philadelphia, salmone, avocado, sesamo', allergens: ['Pesce', 'Latte', 'Soia', 'Sesamo'], emoji: '🍣' },
    { id: 'ur82', name: '82 Uraneghitoro Sake', price: 9, desc: 'Riso, salmone, tabasco, erba cipollina, sesamo', allergens: ['Pesce', 'Soia', 'Sesamo'], emoji: '🍣' },
    { id: 'ur83', name: '83 Uraneghitoro Maguro', price: 9.5, desc: 'Riso, tonno pinna gialla, tabasco, erba cipollina, sesamo', allergens: ['Pesce', 'Soia', 'Sesamo'], emoji: '🍣' },
    { id: 'ur84', name: '84 Uramaki Hasu', price: 12, desc: 'Riso, tonno pinna gialla, philadelphia, gamberi cotti*, avocado, salmone, salsa teriyaki', allergens: ['Pesce', 'Crostacei', 'Latte', 'Glutine', 'Soia'], emoji: '🍣' },
    { id: 'ur85', name: '85 Uramaki Zero', price: 10, desc: 'Riso, salmone, insalata verde, cetriolo, tobiko*, philadelphia', allergens: ['Pesce', 'Latte', 'Soia', 'Sesamo'], emoji: '🍣' },
    { id: 'ur86', name: '86 Uramaki Hiro', price: 15, desc: 'Riso, salmone, avocado, gambero rosso*, carpaccio di tartufo nero', allergens: ['Pesce', 'Crostacei', 'Soia'], emoji: '⭐' },
    { id: 'ur87', name: '87 Uramaki Crazy Roll', price: 14, desc: 'Riso, mazzancolla* in tempura, avocado, maionese, salmone, tonno pinna gialla, branzino, salsa teriyaki', allergens: ['Pesce', 'Crostacei', 'Glutine', 'Uova', 'Soia'], emoji: '🍣' },
    { id: 'ur88', name: '88 Uramaki Spada', price: 12, desc: 'Riso, mazzancolla in tempura, spada affumicata, philadelphia', allergens: ['Pesce', 'Crostacei', 'Glutine', 'Latte'], emoji: '🍣' },
    { id: 'ur89', name: '89 Uramaki Panther', price: 12, desc: 'Riso, mazzancolla in tempura, philadelphia, basilico, fette di salmone, pasta kataifi, salsa teriyaki', allergens: ['Pesce', 'Crostacei', 'Glutine', 'Latte', 'Soia'], emoji: '🐆' },
    { id: 'ur90', name: '90 Uramaki Passion Roll', price: 14, desc: 'Riso, salmone, avocado, polpa di astice*, maionese, passion fruit', allergens: ['Pesce', 'Crostacei', 'Uova', 'Soia'], emoji: '🍣' },
    { id: 'ur91', name: '91 Uramaki Tiger Roll', price: 13, desc: 'Riso, manzancolla* in tempura, maionese, sashimi di salmone, ikura*', allergens: ['Pesce', 'Crostacei', 'Glutine', 'Uova'], emoji: '🐯' },
    { id: 'ur92', name: '92 Uramaki Sicilia', price: 14, desc: 'Riso, gambero rosso*, philadelphia, papaya, sashimi di avocado, gambero crudo', allergens: ['Crostacei', 'Latte', 'Soia'], emoji: '🍣' },
    { id: 'ur93', name: '93 Uramaki Rainbow', price: 9.5, desc: 'Riso, mazzancolla* al vapore, avocado, maionese, salmone, tonno pinna gialla, branzino', allergens: ['Pesce', 'Crostacei', 'Uova', 'Soia'], emoji: '🌈' },
    { id: 'ur94', name: '94 Uramaki Philamenta', price: 12, desc: 'Riso, salsa di tonno pinna gialla, mango, sashimi di salmone flambato, philadelphia, menta', allergens: ['Pesce', 'Latte', 'Soia'], emoji: '🍣' },
    { id: 'ur95', name: '95 Uramaki Tempura', price: 9, desc: 'Riso, mazzancolla* in tempura, maionese, salsa teriyaki', allergens: ['Crostacei', 'Glutine', 'Uova', 'Soia'], emoji: '🍤' },
    { id: 'ur96', name: '96 Uramaki Karma', price: 13, desc: 'Riso, tempura di gamberi*, papaya, philadelphia, sashimi di avocado, mazzancolla* al vapore', allergens: ['Crostacei', 'Glutine', 'Latte', 'Soia'], emoji: '🍣' },
    { id: 'ur97', name: '97 Uramaki Akira', price: 13, desc: 'Riso, mazzancolla* in tempura, maionese giapponese, salsa di tonno pinna gialla, carpaccio di mango, erba cipollina', allergens: ['Crostacei', 'Pesce', 'Glutine', 'Uova', 'Soia'], emoji: '🍣' },
    { id: 'ur98', name: '98 Uramaki Lobster', price: 16, desc: 'Riso, polpa di astice*, maionese, avocado, tobiko*, salsa teriyaki', allergens: ['Crostacei', 'Uova', 'Glutine', 'Soia'], emoji: '🦞' },
    { id: 'ur99', name: '99 Uramaki Red Dragon', price: 15, desc: 'Riso, mazzancolla* in tempura, sashimi di avocado, polpa di astice*, maionese, tobiko*, salsa teriyaki', allergens: ['Crostacei', 'Glutine', 'Uova', 'Soia'], emoji: '🔴' },
    { id: 'ur100', name: '100 Uramaki California', price: 8.5, desc: 'Riso, mazzancolla* al vapore, avocado, salsa di tonno pinna gialla, sesamo', allergens: ['Pesce', 'Crostacei', 'Soia', 'Sesamo'], emoji: '🍣' },
    { id: 'ur101', name: '101 Uramaki Vege', price: 8, desc: 'Riso, tofu, avocado, pomodoro, erba cipollina', allergens: ['Soia'], emoji: '🥦' },
    { id: 'ur102', name: '102 Uramaki Vegan', price: 9, desc: 'Riso, zucchine in tempura, peperoni in tempura, cetrioli, zest lime', allergens: ['Glutine'], emoji: '🌱' },
  ],
  futomaki: [
    { id: 'fu103', name: '103 Futomaki Zeng', price: 8, desc: 'Riso, alga, salmone, philadelphia, avocado, tobiko*, gamberi cotti*', allergens: ['Pesce', 'Crostacei', 'Latte', 'Soia', 'Sesamo'], emoji: '🌯' },
    { id: 'fu104', name: '104 Futomaki Big California', price: 7, desc: 'Riso, alga, gamberi cotti*, salsa di tonno pinna gialla, avocado', allergens: ['Crostacei', 'Pesce', 'Soia'], emoji: '🌯' },
    { id: 'fu105', name: '105 Futomaki Kireimaki', price: 6, desc: 'Riso, alga, salmone, gamberi cotti*, avocado', allergens: ['Pesce', 'Crostacei', 'Soia'], emoji: '🌯' },
    { id: 'fu106', name: '106 Futomaki Aimaki', price: 7, desc: 'Riso, alga, tonno pinna gialla, mazzancolla* al vapore, avocado, philadelphia', allergens: ['Pesce', 'Crostacei', 'Latte', 'Soia'], emoji: '🌯' },
  ],
  poke: [
    { id: 'pk53', name: '53 Poke vegetariano', price: 8, desc: 'Riso bianco, avocado, cetriolo, carota, edamame*, ceci, mais, sesamo', allergens: ['Soia', 'Sesamo', 'Solfiti', 'Lupini'], emoji: '🥗' },
    { id: 'pk54', name: '54 Poke tropicale', price: 10, desc: 'Riso bianco, salmone, mango, edamame*, mais, avocado', allergens: ['Pesce', 'Soia', 'Sesamo'], emoji: '🥗' },
    { id: 'pk55', name: '55 Poke California', price: 10, desc: 'Riso bianco, mazzancolla* al vapore, avocado, wakame*, salsa tonnata, mais, sesamo', allergens: ['Crostacei', 'Soia', 'Sesamo', 'Solfiti'], emoji: '🥗' },
    { id: 'pk56', name: '56 Poke Sake', price: 10, desc: 'Riso bianco, salmone, edamame*, mais, ceci, cetrioli, tobiko*, sesamo', allergens: ['Pesce', 'Soia', 'Sesamo'], emoji: '🥗' },
    { id: 'pk57', name: '57 Poke Maguro', price: 10, desc: 'Riso bianco, tonno pinna gialla, ceci, mais, wakame*', allergens: ['Pesce', 'Soia', 'Sesamo'], emoji: '🥗' },
  ],
};

const MENU_TABS = [
  ['ramen', 'Ramen', 'ラーメン', '🍜'],
  ['antipasti', 'Antipasti', '前菜', '🥢'],
  ['ravioli', 'Ravioli', '餃子', '🥟'],
  ['pasta', 'Pasta & Riso', '面饭', '🍝'],
  ['tempura', 'Tempura', '天妇罗', '🍤'],
  ['sushi_party', 'Sushi Party', '寿司拼盘', '🎉'],
  ['nigiri', 'Nigiri', '握寿司', '🍣'],
  ['sashimi', 'Sashimi', '刺身', '🐟'],
  ['gunkan', 'Gunkan', '军舰', '🍙'],
  ['tartare', 'Tartare', '塔塔', '🥩'],
  ['hosomaki', 'Hosomaki', '细卷', '🌀'],
  ['uramaki', 'Uramaki', '反卷', '🍱'],
  ['futomaki', 'Futomaki', '太卷', '🌯'],
  ['poke', 'Poke', '波奇饭', '🥗'],
];

const ALLERGENS = [
  { id: 'Glutine', it: 'Glutine', cn: '麸质', emoji: '🌾' },
  { id: 'Crostacei', it: 'Crostacei', cn: '甲壳类', emoji: '🦐' },
  { id: 'Uova', it: 'Uova', cn: '鸡蛋', emoji: '🥚' },
  { id: 'Pesce', it: 'Pesce', cn: '鱼类', emoji: '🐟' },
  { id: 'Arachidi', it: 'Arachidi', cn: '花生', emoji: '🥜' },
  { id: 'Soia', it: 'Soia', cn: '大豆', emoji: '🌱' },
  { id: 'Latte', it: 'Latte', cn: '牛奶', emoji: '🥛' },
  { id: 'Sedano', it: 'Sedano', cn: '芹菜', emoji: '🌿' },
  { id: 'Senape', it: 'Senape', cn: '芥末', emoji: '🌶️' },
  { id: 'Sesamo', it: 'Sesamo', cn: '芝麻', emoji: '🟤' },
  { id: 'Solfiti', it: 'Solfiti', cn: '亚硫酸盐', emoji: '🍷' },
  { id: 'Lupini', it: 'Lupini', cn: '羽扇豆', emoji: '🫘' },
  { id: 'Molluschi', it: 'Molluschi', cn: '软体类', emoji: '🦑' },
];

const PRIZES = [
  { label: '5 积分', type: 'points', value: 5, color: '#3a2e2a', text: '#f5ede0' },
  { label: '免费玉子烧', type: 'item', value: '玉子烧寿司 ×2', color: '#e85d2f', text: '#fff' },
  { label: '10 积分', type: 'points', value: 10, color: '#3a2e2a', text: '#f5ede0' },
  { label: '拉面 8 折', type: 'coupon', value: '拉面 8 折券', color: '#c44a25', text: '#fff' },
  { label: '20 积分', type: 'points', value: 20, color: '#3a2e2a', text: '#f5ede0' },
  { label: '寿司买一送一', type: 'coupon', value: '寿司买一送一券', color: '#e85d2f', text: '#fff' },
  { label: '谢谢参与', type: 'none', value: null, color: '#2a2420', text: '#8a7a6e' },
  { label: '50 积分', type: 'points', value: 50, color: '#d4a574', text: '#1a1614' },
];

const SPIN_COST = 20;
const EMPLOYEE_PIN = '1234';

const RECHARGE_TIERS = [
  { amount: 25, bonus: 0, tag: null },
  { amount: 50, bonus: 5, tag: '送 €5' },
  { amount: 100, bonus: 15, tag: '送 €15' },
  { amount: 200, bonus: 40, tag: '送 €40 · 推荐' },
];

const STORAGE_KEY = 'restaurant-loyalty-data';
const ORDERS_KEY = 'restaurant-orders-data';

const ALL_ITEMS = Object.values(MENU).flat();
const findItem = (id) => ALL_ITEMS.find((i) => i.id === id);

const formatPhone = (p) => p.replace(/(\d{3})(\d{3})(\d{4})/, '$1 $2 $3');
const PHONE_REGEX = /^3\d{9}$/;
const PHONE_PLACEHOLDER = '333 123 4567';
const PHONE_MAX_LEN = 10;

const STATUS_META = {
  pending: { label: '准备中', color: '#e85d2f', bg: 'rgba(232,93,47,0.15)' },
  ready: { label: '可取餐', color: '#d4a574', bg: 'rgba(212,165,116,0.18)' },
  completed: { label: '已完成', color: '#8a7a6e', bg: 'rgba(138,122,110,0.15)' },
};

// ========== 密码 / 安全 ==========
// 注意: 生产环境必须用后端 bcrypt 处理密码，前端 hash 仅作演示
async function hashPassword(password, salt) {
  const data = new TextEncoder().encode(password + ':' + salt);
  const buf = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

function generateSalt() {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return Array.from(arr).map((b) => b.toString(16).padStart(2, '0')).join('');
}

function passwordChecks(pw) {
  return [
    { test: pw.length >= 8, label: '至少 8 位' },
    { test: /[A-Z]/.test(pw), label: '含大写字母' },
    { test: /[a-z]/.test(pw), label: '含小写字母' },
    { test: /\d/.test(pw), label: '含数字' },
    { test: /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(pw), label: '含特殊符号' },
  ];
}

function passwordStrong(pw) {
  return passwordChecks(pw).every((c) => c.test);
}

function generateResetCode() {
  return String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
}

// 格式化欧元价格: 12 → "12", 12.5 → "12.50"
const fmtPrice = (n) => (Number.isInteger(n) ? String(n) : Number(n).toFixed(2));

// ========== i18n 多语言 ==========
const SUPPORTED_LANGS = ['zh', 'it', 'en'];
const LANG_META = {
  zh: { code: 'zh', name: '简体中文', flag: '🇨🇳', short: '中' },
  it: { code: 'it', name: 'Italiano', flag: '🇮🇹', short: 'IT' },
  en: { code: 'en', name: 'English', flag: '🇬🇧', short: 'EN' },
};
const LANG_KEY = 'app-language';

const TRANSLATIONS = {
  // ── Common 通用 ──
  'common.back':       { zh: '返回',      it: 'Indietro',     en: 'Back' },
  'common.close':      { zh: '关闭',      it: 'Chiudi',       en: 'Close' },
  'common.cancel':     { zh: '取消',      it: 'Annulla',      en: 'Cancel' },
  'common.confirm':    { zh: '确认',      it: 'Conferma',     en: 'Confirm' },
  'common.save':       { zh: '保存',      it: 'Salva',        en: 'Save' },
  'common.delete':     { zh: '删除',      it: 'Elimina',      en: 'Delete' },
  'common.search':     { zh: '搜索',      it: 'Cerca',        en: 'Search' },
  'common.submit':     { zh: '提交',      it: 'Invia',        en: 'Submit' },
  'common.loading':    { zh: '加载中...', it: 'Caricamento...', en: 'Loading...' },
  'common.clear':      { zh: '清空',      it: 'Svuota',       en: 'Clear' },
  'common.apply':      { zh: '应用',      it: 'Applica',      en: 'Apply' },
  'common.reset':      { zh: '重置',      it: 'Ripristina',   en: 'Reset' },
  'common.enter':      { zh: '进入',      it: 'Entra',        en: 'Enter' },
  'common.selected':   { zh: '已选',      it: 'Selezionato',  en: 'Selected' },
  'common.current':    { zh: '当前',      it: 'Attuale',      en: 'Current' },
  'common.switch':     { zh: '切换',      it: 'Cambia',       en: 'Switch' },
  'common.optional':   { zh: '可选',      it: 'opzionale',    en: 'optional' },

  // ── Role select 身份选择 ──
  'role.title':        { zh: '请选择身份',  it: 'Scegli il ruolo',     en: 'Choose your role' },
  'role.customer':     { zh: '顾客端',     it: 'Cliente',             en: 'Customer' },
  'role.customerSub':  { zh: '查看积分・下单',  it: 'Punti · Ordina',  en: 'Points · Order' },
  'role.employee':     { zh: '员工端',     it: 'Personale',           en: 'Staff' },
  'role.employeeSub':  { zh: '管理顾客・订单', it: 'Gestione ordini',  en: 'Manage orders' },
  'role.tagline':      { zh: 'RAMEN・SUSHI・SCHIO · SAN BONIFACIO', it: 'RAMEN・SUSHI・SCHIO · SAN BONIFACIO', en: 'RAMEN・SUSHI・SCHIO · SAN BONIFACIO' },
  'role.viewStores':   { zh: '查看店铺',   it: 'I nostri locali',     en: 'Our locations' },

  // ── Login 登录 ──
  'login.label':       { zh: 'WELCOME',   it: 'BENVENUTO',           en: 'WELCOME' },
  'login.title':       { zh: '输入手机号进入', it: 'Inserisci il tuo numero', en: 'Enter your phone' },
  'login.subtitle':    { zh: '首次使用赠送 50 积分。再次进入直接识别您的账户。',
                         it: 'Primo accesso: 50 punti omaggio. Le visite successive riconoscono automaticamente il tuo account.',
                         en: "First-time bonus: 50 points. We'll recognize your account on return visits." },
  'login.phone':       { zh: '手机号',     it: 'Numero di telefono',  en: 'Phone number' },
  'login.name':        { zh: '用户名',     it: 'Nome',                en: 'Name' },
  'login.firstTime':   { zh: '首次使用',   it: 'primo accesso',       en: 'first time' },
  'login.btnRegister': { zh: '注册并进入', it: 'Registrati ed entra', en: 'Sign up and enter' },
  'login.btnEnter':    { zh: '进入',       it: 'Entra',               en: 'Enter' },
  'login.welcomeBack': { zh: '欢迎回来，{name}', it: 'Bentornato {name}', en: 'Welcome back, {name}' },
  'login.welcomeBonus': { zh: '欢迎,赠送 50 积分!', it: 'Benvenuto! 50 punti omaggio!', en: 'Welcome! 50 free points!' },
  'login.noPassword':  { zh: '演示阶段无需密码 · 后续可启用密码登录',
                         it: 'Modalità demo · accesso senza password',
                         en: 'Demo mode · no password required' },
  'login.balance':     { zh: '余额',       it: 'Saldo',               en: 'Balance' },
  'login.points':      { zh: '积分',       it: 'Punti',               en: 'Points' },

  // ── Home 首页 ──
  'home.welcome':      { zh: 'WELCOME',   it: 'BENVENUTO',           en: 'WELCOME' },
  'home.sede':         { zh: 'SEDE',      it: 'SEDE',                en: 'LOCATION' },
  'home.orderReady':   { zh: '订单已就绪', it: 'Ordine pronto',       en: 'Order ready' },
  'home.orderReadySub':{ zh: '您的订单已准备好', it: 'Il tuo ordine è pronto al ritiro', en: 'Your order is ready' },
  'home.balanceLabel': { zh: 'BALANCE · 储值余额', it: 'SALDO PORTAFOGLIO', en: 'WALLET BALANCE' },
  'home.recharge':     { zh: '充值 →',    it: 'Ricarica →',          en: 'Top up →' },
  'home.points':       { zh: '积分',       it: 'Punti',               en: 'Points' },
  'home.coupons':      { zh: '优惠券',     it: 'Coupon',              en: 'Coupons' },
  'home.myCoupons':    { zh: 'MY COUPONS', it: 'I MIEI COUPON',     en: 'MY COUPONS' },
  'home.showInStore':  { zh: '到店出示',   it: 'Mostra in negozio',   en: 'Show in store' },
  'home.actMenu':      { zh: '打包外带',   it: 'Asporto',             en: 'Take Away' },
  'home.actMenuSub':   { zh: '浏览菜单下单', it: 'Sfoglia e ordina',  en: 'Browse menu' },
  'home.actOrders':    { zh: '我的订单',   it: 'I miei ordini',       en: 'My orders' },
  'home.actOrdersSubActive': { zh: '{n} 进行中', it: '{n} in corso',  en: '{n} active' },
  'home.actOrdersSubEmpty':  { zh: '查看历史', it: 'Storico',         en: 'History' },
  'home.actSpin':      { zh: '幸运转盘',   it: 'Ruota fortuna',       en: 'Spin wheel' },
  'home.actSpinSub':   { zh: '{n} 积分一次', it: '{n} punti / giro',  en: '{n} pts per spin' },
  'home.actHistory':   { zh: '积分明细',   it: 'Storico punti',       en: 'Points log' },
  'home.actHistorySub':{ zh: '查看记录',   it: 'Vedi cronologia',     en: 'View history' },

  // ── VIP ──
  'vip.title':         { zh: '我的等级',   it: 'Il mio livello',      en: 'My level' },
  'vip.label':         { zh: 'VIP · 会员等级', it: 'VIP · LIVELLO',  en: 'VIP · TIER' },
  'vip.current':       { zh: 'ATTUALE · 当前等级', it: 'LIVELLO ATTUALE', en: 'CURRENT TIER' },
  'vip.totalSpent':    { zh: '累计消费',   it: 'Speso totale',        en: 'Total spent' },
  'vip.pointsBalance': { zh: '积分余额',   it: 'Punti disponibili',   en: 'Points balance' },
  'vip.toNext':        { zh: '距 {next} 还差 €{diff}', it: 'Mancano €{diff} a {next}', en: '€{diff} to {next}' },
  'vip.toNextLong':    { zh: '距 {emoji} V{level} {name}', it: 'Verso {emoji} V{level} {name}', en: 'To {emoji} V{level} {name}' },
  'vip.progressNote':  { zh: '每 €1 消费 = 1 经验 · {p}% 已达成', it: '€1 = 1 punto esperienza · {p}% completato', en: '€1 = 1 XP · {p}% complete' },
  'vip.maxLevel':      { zh: '🎉 您已达到最高等级 · 感谢您的支持', it: '🎉 Hai raggiunto il livello massimo · Grazie!', en: "🎉 You've reached the highest level · Thank you!" },
  'vip.viewBenefits':  { zh: '查看权益 →', it: 'Vedi vantaggi →',     en: 'See benefits →' },
  'vip.benefits':      { zh: 'I VOSTRI BENEFICI · 当前权益', it: 'I TUOI VANTAGGI', en: 'YOUR BENEFITS' },
  'vip.allLevels':     { zh: 'TUTTI I LIVELLI · 全部等级', it: 'TUTTI I LIVELLI', en: 'ALL TIERS' },
  'vip.thisLevel':     { zh: '累计消费',   it: 'Speso totale',        en: 'Total spent' },
  'vip.rulesTitle':    { zh: '📋 等级规则', it: '📋 Regole VIP',      en: '📋 VIP Rules' },
  'vip.rule1':         { zh: '每 €1 真实消费 = 1 经验 + 1 积分', it: '€1 speso = 1 XP + 1 punto', en: '€1 spent = 1 XP + 1 point' },
  'vip.rule2':         { zh: '累计消费决定 VIP 等级,不会因消费积分而降级', it: 'Il livello si basa sulla spesa totale, non scende mai', en: 'Tier based on total spend, never decreases' },
  'vip.rule3':         { zh: '注册赠送积分、转盘奖励、员工手动加分不计入等级经验', it: 'Bonus registrazione, ruota fortuna e crediti manuali non contano per il livello', en: 'Signup bonus, spin wins, manual credits do not count for tier' },
  'vip.rule4':         { zh: '一旦升级永久保留,无降级机制', it: 'Una volta raggiunto, il livello è permanente', en: 'Once unlocked, tier is permanent' },
  // VIP level names (localized)
  'vip.lv1.name':      { zh: '新会员', it: 'Bronzo',   en: 'Bronze' },
  'vip.lv2.name':      { zh: '银会员', it: 'Argento',  en: 'Silver' },
  'vip.lv3.name':      { zh: '金会员', it: 'Oro',      en: 'Gold' },
  'vip.lv4.name':      { zh: '铂金会员', it: 'Platino', en: 'Platinum' },
  'vip.lv5.name':      { zh: '钻石会员', it: 'Diamante', en: 'Diamond' },
  // VIP perks (用 | 分隔多条)
  'vip.lv1.perks':     {
    zh: '会员基础权益|生日小礼物|注册赠送 50 积分',
    it: 'Vantaggi base|Regalo di compleanno|50 punti omaggio alla registrazione',
    en: 'Base benefits|Birthday gift|50 points on signup',
  },
  'vip.lv2.perks':     {
    zh: '每月一份免费玉子烧 (2 贯)|转盘抽奖九折|专属客服',
    it: '1 tamagoyaki gratis al mese (2 pz)|10% di sconto sulla ruota|Servizio clienti dedicato',
    en: '1 free tamagoyaki monthly (2 pcs)|10% off spin wheel|Dedicated customer service',
  },
  'vip.lv3.perks':     {
    zh: '生日免费拉面|€20 以上订单免外送费|新品优先试吃',
    it: 'Ramen gratis di compleanno|Consegna gratis sopra €20|Anteprima nuovi piatti',
    en: 'Free ramen on birthday|Free delivery above €20|Early access to new dishes',
  },
  'vip.lv4.perks':     {
    zh: '优先备餐|每月免费小食 1 份|专属优惠券 10% off',
    it: 'Preparazione prioritaria|1 antipasto gratis al mese|Coupon esclusivo 10% di sconto',
    en: 'Priority cooking|1 free appetizer monthly|Exclusive 10% coupon',
  },
  'vip.lv5.perks':     {
    zh: '免费配送 (任意金额)|VIP 专线接待|月度免费寿司拼盘|专属菜品试吃会',
    it: 'Consegna gratis (qualsiasi importo)|Linea VIP dedicata|Vassoio sushi gratis mensile|Eventi degustazione esclusivi',
    en: 'Free delivery (any amount)|VIP hotline|Free monthly sushi platter|Exclusive tasting events',
  },

  // ── Stores 店铺 ──
  'stores.title':      { zh: 'Fude Ramen 店铺', it: 'I nostri locali', en: 'Our locations' },
  'stores.label':      { zh: 'LOCALI · 店铺', it: 'LOCALI',            en: 'LOCATIONS' },
  'stores.intro':      { zh: '我们在 Veneto 有两家店。选择您要下单的店铺,菜单和价格相同,但配送区域不同(各覆盖店铺周边 {km} km)。',
                         it: 'Abbiamo due ristoranti in Veneto. Stesso menu e prezzi, ma zone di consegna diverse ({km} km dal punto vendita scelto).',
                         en: 'Two locations in Veneto. Same menu and prices, but each store covers its own {km} km delivery area.' },
  'stores.hours':      { zh: 'ORARI · 营业时间', it: 'ORARI',          en: 'HOURS' },
  'stores.navigate':   { zh: '📍 地图导航', it: '📍 Apri in mappa',   en: '📍 Open in maps' },
  'stores.select':     { zh: '选择此店铺', it: 'Scegli questo',       en: 'Choose this' },
  'stores.currentSelect': { zh: '当前选择', it: 'Selezionato',        en: 'Selected' },
  'stores.deliveryNote':{ zh: '外送范围: 各店周边 {km} km · 时段 18:30-22:00', it: 'Consegne: entro {km} km · 18:30-22:00', en: 'Delivery: within {km} km · 18:30-22:00' },
  'stores.takeAwayNote':{ zh: 'Take Away 可订午餐 + 晚餐时段', it: 'Asporto disponibile pranzo e cena', en: 'Take Away: lunch and dinner' },
  'stores.selected':   { zh: '已选择 {name}', it: 'Selezionato: {name}', en: 'Selected: {name}' },
  // 店铺营业时间标签 (店铺数据里硬编码的中文 day 字段太多, 单独翻译)
  'stores.day.mon':    { zh: '周一', it: 'Lunedì', en: 'Monday' },
  'stores.day.tueSunLunch':  { zh: '周二-日 午餐', it: 'Mar-Dom Pranzo', en: 'Tue-Sun Lunch' },
  'stores.day.tueSunDinner': { zh: '周二-日 晚餐', it: 'Mar-Dom Cena',   en: 'Tue-Sun Dinner' },
  'stores.day.delivery':     { zh: '外送', it: 'Delivery',              en: 'Delivery' },
  'stores.closed':     { zh: '休息', it: 'Chiuso', en: 'Closed' },
  'stores.schio.note':       { zh: '免费停车位', it: 'Parcheggio gratuito', en: 'Free parking' },
  'stores.sanbonifacio.note':{ zh: '市中心位置', it: 'Posizione centrale',  en: 'City center location' },

  // ── 杂项 ──
  'lang.switchTo':     { zh: '切换语言', it: 'Cambia lingua', en: 'Change language' },
  'menu.addToCart':    { zh: '加入购物车', it: 'Aggiungi al carrello', en: 'Add to cart' },
  'menu.allergens':    { zh: '过敏原',    it: 'Allergeni',           en: 'Allergens' },
  'menu.description':  { zh: '描述',      it: 'Descrizione',         en: 'Description' },
  'menu.noDescription':{ zh: '暂无描述',  it: 'Descrizione non disponibile', en: 'No description available' },
  'menu.tapToDetail':  { zh: '点击查看详情', it: 'Tocca per i dettagli', en: 'Tap for details' },
};

function detectLang() {
  if (typeof navigator === 'undefined') return 'it';
  const lang = (navigator.language || navigator.userLanguage || '').toLowerCase();
  if (lang.startsWith('zh')) return 'zh';
  if (lang.startsWith('it')) return 'it';
  if (lang.startsWith('en')) return 'en';
  return 'it'; // 默认意大利语(餐厅在意大利)
}

function translate(key, lang, params = {}) {
  const entry = TRANSLATIONS[key];
  if (!entry) {
    if (process?.env?.NODE_ENV !== 'production') console.warn('Missing translation:', key);
    return key;
  }
  let s = entry[lang] || entry.zh || key;
  Object.entries(params).forEach(([k, v]) => {
    s = s.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
  });
  return s;
}

// React context
const I18nContext = createContext({
  lang: 'zh',
  t: (k, p) => translate(k, 'zh', p),
  setLang: () => {},
});
function useT() {
  return useContext(I18nContext);
}

// ========== 店铺信息（来自 fuderamen.com）==========
const STORES = {
  schio: {
    id: 'schio',
    name: 'Schio',
    province: 'VI',
    fullName: 'Fude Ramen Schio',
    address: 'Viale Europa Unita, 2/A',
    cap: '36015 Schio (VI)',
    phone: '0445 513012',
    coords: { lat: 45.7061218, lng: 11.368496 },
    noteKey: 'stores.schio.note',
    hours: [
      { dayKey: 'mon', textKey: 'stores.closed' },
      { dayKey: 'tueSunLunch', text: '12:00 – 15:00' },
      { dayKey: 'tueSunDinner', text: '18:30 – 23:00' },
      { dayKey: 'delivery', text: '18:30 – 22:00' },
    ],
  },
  sanbonifacio: {
    id: 'sanbonifacio',
    name: 'San Bonifacio',
    province: 'VR',
    fullName: 'Fude Ramen San Bonifacio',
    address: 'Viale delle Fontanelle, 147',
    cap: '37047 San Bonifacio (VR)',
    phone: '045 9242036',
    coords: { lat: 45.3790963, lng: 11.2845852 },
    noteKey: 'stores.sanbonifacio.note',
    hours: [
      { dayKey: 'mon', textKey: 'stores.closed' },
      { dayKey: 'tueSunLunch', text: '12:00 – 14:30' },
      { dayKey: 'tueSunDinner', text: '18:00 – 23:00' },
      { dayKey: 'delivery', text: '18:30 – 22:00' },
    ],
  },
};
const STORE_LIST = Object.values(STORES);

// ========== VIP 等级体系 ==========
// 累计消费 (totalSpent, €) 决定等级。每 €1 = 1 经验,注册/转盘奖励不计入。
const VIP_LEVELS = [
  {
    level: 1, name: '新会员', it: 'Bronzo', emoji: '🥉',
    color: '#c97d4f', minSpent: 0,
    perks: ['会员基础权益', '生日小礼物', '注册赠送 50 积分'],
  },
  {
    level: 2, name: '银会员', it: 'Argento', emoji: '🥈',
    color: '#b8bcc4', minSpent: 100,
    perks: ['每月一份免费玉子烧 (2 贯)', '转盘抽奖九折', '专属客服'],
  },
  {
    level: 3, name: '金会员', it: 'Oro', emoji: '🥇',
    color: '#e6c772', minSpent: 300,
    perks: ['生日免费拉面', '€20 以上订单免外送费', '新品优先试吃'],
  },
  {
    level: 4, name: '铂金会员', it: 'Platino', emoji: '💎',
    color: '#a8d8ea', minSpent: 700,
    perks: ['优先备餐', '每月免费小食 1 份', '专属优惠券 10% off'],
  },
  {
    level: 5, name: '钻石会员', it: 'Diamante', emoji: '💠',
    color: '#7dd3fc', minSpent: 1500,
    perks: ['免费配送 (任意金额)', 'VIP 专线接待', '月度免费寿司拼盘', '专属菜品试吃会'],
  },
];

function getVipLevel(totalSpent) {
  let current = VIP_LEVELS[0];
  for (const lv of VIP_LEVELS) {
    if (totalSpent >= lv.minSpent) current = lv;
  }
  return current;
}

function getNextVip(currentLevel) {
  return VIP_LEVELS.find((l) => l.level === currentLevel + 1) || null;
}


const MAX_DELIVERY_KM = 10;
const MIN_PREP_MIN = 10;
const MIN_PER_KM = 3;

// Haversine: 计算两点公里距离
function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ========== Google Maps API ==========
// 与 fuderamen.com 网站使用同一个 key (已在网站源码中公开)
// 生产环境务必在 Google Cloud Console:
//   1. 限制 HTTP referrer (只允许你的域名)
//   2. 限制 API 范围 (Places API New + Geocoding API)
//   3. 设置每日配额上限
const GMAPS_KEY = 'AIzaSyDBl02TghKQb0GX_XQXszpTUU4DJ-pkgiQ';

// Google Places Autocomplete (New API) - 支持 CORS,适合浏览器
async function googlePlacesAutocomplete(query, biasLat, biasLng) {
  try {
    const resp = await fetch('https://places.googleapis.com/v1/places:autocomplete', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': GMAPS_KEY,
      },
      body: JSON.stringify({
        input: query,
        locationBias: {
          circle: {
            center: { latitude: biasLat, longitude: biasLng },
            radius: 30000, // 30 km
          },
        },
        languageCode: 'it',
        regionCode: 'it',
        includedPrimaryTypes: ['street_address', 'route', 'premise', 'subpremise'],
      }),
    });
    if (!resp.ok) {
      console.warn('Google Places autocomplete failed:', resp.status);
      return null;
    }
    const data = await resp.json();
    return (data?.suggestions || [])
      .map((s) => {
        const p = s.placePrediction;
        if (!p) return null;
        const main = p.structuredFormat?.mainText?.text || p.text?.text || '';
        const sec = p.structuredFormat?.secondaryText?.text || '';
        return { placeId: p.placeId, display: main, secondary: sec };
      })
      .filter((r) => r && r.display);
  } catch (e) {
    console.warn('Google Places autocomplete error:', e);
    return null;
  }
}

// 获取 Place 详细信息(包含坐标)
async function googlePlaceDetails(placeId) {
  try {
    const resp = await fetch(`https://places.googleapis.com/v1/places/${placeId}`, {
      headers: {
        'X-Goog-Api-Key': GMAPS_KEY,
        'X-Goog-FieldMask': 'location,formattedAddress',
      },
    });
    if (!resp.ok) return null;
    const data = await resp.json();
    if (!data.location) return null;
    return {
      coords: { lat: data.location.latitude, lng: data.location.longitude },
      address: data.formattedAddress,
    };
  } catch (e) {
    return null;
  }
}

// Google Geocoding API - 直接文本→坐标 (与你网站现在用的相同)
async function googleGeocode(addr) {
  try {
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(addr + ', Italia')}&key=${GMAPS_KEY}`;
    const resp = await fetch(url);
    const data = await resp.json();
    if (data.status !== 'OK' || !data.results?.length) return null;
    const r = data.results[0];
    return {
      coords: { lat: r.geometry.location.lat, lng: r.geometry.location.lng },
      address: r.formatted_address,
    };
  } catch (e) {
    return null;
  }
}

// 单次地理编码 (fallback)
async function geocodeAddress(addr) {
  const g = await googleGeocode(addr);
  if (g) return { ...g.coords, displayName: g.address };
  // Photon fallback
  try {
    const url = `https://photon.komoot.io/api/?q=${encodeURIComponent(addr)}&limit=1&lang=it`;
    const resp = await fetch(url);
    const data = await resp.json();
    if (!data?.features?.length) return null;
    const f = data.features[0];
    return {
      lat: f.geometry.coordinates[1],
      lng: f.geometry.coordinates[0],
      displayName: formatPhotonAddress(f.properties),
    };
  } catch (e) {
    return null;
  }
}

// 地址自动补全 - Google 优先, Photon 备用
async function autocompleteAddress(query, biasLat, biasLng) {
  // 试 Google Places (New)
  const googleResults = await googlePlacesAutocomplete(query, biasLat, biasLng);
  if (googleResults && googleResults.length > 0) {
    return googleResults; // 含 placeId, 需要在 pick 时再调 details
  }
  // Fallback Photon
  try {
    const url = `https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&limit=6&lang=it&lat=${biasLat}&lon=${biasLng}`;
    const resp = await fetch(url);
    const data = await resp.json();
    return (data?.features || [])
      .map((f) => ({
        coords: { lat: f.geometry.coordinates[1], lng: f.geometry.coordinates[0] },
        display: formatPhotonAddress(f.properties),
        secondary: formatPhotonSecondary(f.properties),
      }))
      .filter((s) => s.display);
  } catch (e) {
    return [];
  }
}

// 解析建议的坐标 (Google 需要再调 details, Photon 直接有)
async function resolveSuggestionCoords(suggestion) {
  if (suggestion.coords) return suggestion.coords;
  if (suggestion.placeId) {
    const details = await googlePlaceDetails(suggestion.placeId);
    return details?.coords || null;
  }
  return null;
}

function formatPhotonAddress(p) {
  const parts = [];
  const streetPart = p.street ? (p.street + (p.housenumber ? ' ' + p.housenumber : '')) : (p.name || '');
  if (streetPart) parts.push(streetPart);
  return parts.join(', ');
}

function formatPhotonSecondary(p) {
  const parts = [];
  if (p.postcode) parts.push(p.postcode);
  const city = p.city || p.town || p.village || p.county;
  if (city) parts.push(city);
  if (p.state) parts.push(p.state);
  return parts.join(' · ');
}

const LOCATION_KEY = 'restaurant-location';
const MENU_OVERRIDES_KEY = 'menu-overrides';

export default function App() {
  const [view, setView] = useState('role');
  const [currentPhone, setCurrentPhone] = useState(null);
  const [customers, setCustomers] = useState({});
  const [orders, setOrders] = useState({});
  const [cart, setCart] = useState({}); // { itemId: qty }
  const [currentLocation, setCurrentLocation] = useState('schio');
  const [lang, setLangState] = useState(detectLang());
  const [menuOverrides, setMenuOverrides] = useState({});
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Noto+Serif+JP:wght@400;700;900&family=Noto+Sans+SC:wght@300;400;500;700;900&family=Shippori+Mincho:wght@500;700;800&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const result = await window.storage.get(STORAGE_KEY, true);
        if (result?.value) setCustomers(JSON.parse(result.value));
      } catch (e) { /* first time */ }
      try {
        const result = await window.storage.get(ORDERS_KEY, true);
        if (result?.value) setOrders(JSON.parse(result.value));
      } catch (e) { /* first time */ }
      try {
        const result = await window.storage.get(LOCATION_KEY, false);
        if (result?.value && STORES[result.value]) setCurrentLocation(result.value);
      } catch (e) { /* default */ }
      try {
        const result = await window.storage.get(LANG_KEY, false);
        if (result?.value && SUPPORTED_LANGS.includes(result.value)) setLangState(result.value);
      } catch (e) { /* auto-detect already done */ }
      try {
        const result = await window.storage.get(MENU_OVERRIDES_KEY, true);
        if (result?.value) setMenuOverrides(JSON.parse(result.value));
      } catch (e) { /* none */ }
      setLoading(false);
    })();
  }, []);

  const setLocation = async (locId) => {
    setCurrentLocation(locId);
    try { await window.storage.set(LOCATION_KEY, locId, false); } catch (e) {}
  };

  const setLang = async (newLang) => {
    if (!SUPPORTED_LANGS.includes(newLang)) return;
    setLangState(newLang);
    try { await window.storage.set(LANG_KEY, newLang, false); } catch (e) {}
  };

  const saveMenuOverrides = async (next) => {
    setMenuOverrides(next);
    try { await window.storage.set(MENU_OVERRIDES_KEY, JSON.stringify(next), true); } catch (e) {}
  };

  // 取最终展示用的菜品数据(合并 MENU + 静态 menu-images.json + 后台覆盖)
  // 优先级: 后台上传 > public/menu/ 文件 (或网站远程 URL) > 原始 MENU emoji
  const mergedMENU = useMemo(() => {
    const out = {};
    for (const [cat, items] of Object.entries(MENU)) {
      out[cat] = items.map((it) => {
        const fileImage = MENU_IMAGES[it.id];
        const override = menuOverrides[it.id];
        let merged = it;
        if (fileImage) merged = { ...merged, image: fileImage };
        if (override) merged = { ...merged, ...override };
        return merged;
      });
    }
    return out;
  }, [menuOverrides]);

  const t = (key, params) => translate(key, lang, params);

  const saveCustomers = async (next) => {
    setCustomers(next);
    try {
      await window.storage.set(STORAGE_KEY, JSON.stringify(next), true);
    } catch (e) {
      showToast('保存失败，请重试');
    }
  };

  const saveOrders = async (next) => {
    setOrders(next);
    try {
      await window.storage.set(ORDERS_KEY, JSON.stringify(next), true);
    } catch (e) {
      showToast('订单保存失败');
    }
  };

  // 购物车操作
  const cartCount = Object.values(cart).reduce((s, q) => s + q, 0);
  const cartTotal = Object.entries(cart).reduce((sum, [id, qty]) => {
    const item = findItem(id);
    return sum + (item?.price || 0) * qty;
  }, 0);

  const updateCart = (id, delta) => {
    setCart((prev) => {
      const next = { ...prev };
      const q = (next[id] || 0) + delta;
      if (q <= 0) delete next[id];
      else next[id] = q;
      return next;
    });
  };

  // 下单
  const placeOrder = async (orderData) => {
    const { note, payWithBalance, orderType, locationId, deliveryAddress, distanceKm, etaMin } = orderData;
    const items = Object.entries(cart).map(([id, qty]) => {
      const item = findItem(id);
      return { id, name: item.name, price: item.price, unit: item.unit, qty };
    });
    const order = {
      id: 'ord_' + Date.now().toString(36),
      customerPhone: currentPhone,
      customerName: customers[currentPhone]?.name || '顾客',
      items,
      total: cartTotal,
      status: 'pending',
      note: (note || '').trim(),
      orderType: orderType || 'takeaway',
      locationId: locationId || currentLocation,
      locationName: STORES[locationId || currentLocation]?.name,
      deliveryAddress: orderType === 'delivery' ? (deliveryAddress || '').trim() : '',
      distanceKm: orderType === 'delivery' ? distanceKm : null,
      etaMin: orderType === 'delivery' ? etaMin : null,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      paid: !!payWithBalance,
      paymentMethod: payWithBalance ? 'balance' : 'pickup',
    };

    if (payWithBalance) {
      const next = { ...customers };
      const c = { ...next[currentPhone] };
      c.balance = (c.balance || 0) - cartTotal;
      c.history = [{ t: Date.now(), text: `余额支付订单 #${order.id.slice(-6).toUpperCase()}`, delta: 0, balanceDelta: -cartTotal }, ...c.history];
      next[currentPhone] = c;
      await saveCustomers(next);
    }

    await saveOrders({ ...orders, [order.id]: order });
    setCart({});
    setView('customer-orders');
    showToast(payWithBalance ? '已支付下单！' : '已下单，我们正在准备');
  };

  // 员工更新订单状态
  const updateOrderStatus = async (orderId, status) => {
    const o = { ...orders[orderId], status, updatedAt: Date.now() };
    if (status === 'completed' && !o.pointsEarned) {
      const pts = Math.floor(o.total);
      const custNext = { ...customers };
      if (custNext[o.customerPhone]) {
        const c = { ...custNext[o.customerPhone] };
        const oldLevel = getVipLevel(c.totalSpent || 0).level;
        c.points += pts;
        c.totalSpent = (c.totalSpent || 0) + o.total;
        const newLevel = getVipLevel(c.totalSpent).level;
        c.history = [{ t: Date.now(), text: `打包订单完成 +${pts} 积分（€${o.total}）`, delta: pts }, ...c.history];
        if (newLevel > oldLevel) {
          const lv = VIP_LEVELS.find((x) => x.level === newLevel);
          c.history = [{ t: Date.now(), text: `🎉 升级到 ${lv.emoji} V${lv.level} ${lv.name}！`, delta: 0 }, ...c.history];
        }
        custNext[o.customerPhone] = c;
        await saveCustomers(custNext);
      }
      o.pointsEarned = pts;
      o.completedAt = Date.now();
    }
    await saveOrders({ ...orders, [orderId]: o });
  };

  // 充值
  const recharge = async (amount, bonus) => {
    const total = amount + bonus;
    const next = { ...customers };
    const c = { ...next[currentPhone] };
    c.balance = (c.balance || 0) + total;
    const text = bonus > 0 ? `充值 €${amount}，赠送 €${bonus}` : `充值 €${amount}`;
    c.history = [{ t: Date.now(), text, delta: 0, balanceDelta: total }, ...c.history];
    next[currentPhone] = c;
    await saveCustomers(next);
  };

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2200);
  };

  const customer = currentPhone ? customers[currentPhone] : null;

  return (
    <I18nContext.Provider value={{ lang, t, setLang }}>
    <div className="min-h-screen w-full" style={{ background: '#1a1614', fontFamily: "'Noto Sans SC', sans-serif" }}>
      <style>{`
        .font-jp { font-family: 'Shippori Mincho', 'Noto Serif JP', serif; }
        .font-display { font-family: 'Noto Serif JP', serif; font-weight: 900; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes scaleIn { from { opacity: 0; transform: scale(0.96); } to { opacity: 1; transform: scale(1); } }
        @keyframes slideUpSheet { from { transform: translateY(100%); } to { transform: translateY(0); } }
        @keyframes shimmer { 0%, 100% { opacity: 0.6; } 50% { opacity: 1; } }
        .fade-up { animation: fadeUp 0.4s ease-out both; }
        .scale-in { animation: scaleIn 0.3s ease-out both; }
        .shimmer { animation: shimmer 2s ease-in-out infinite; }
        .grain::before {
          content: ''; position: absolute; inset: 0; pointer-events: none;
          background-image: radial-gradient(circle at 1px 1px, rgba(245,237,224,0.02) 1px, transparent 0);
          background-size: 3px 3px;
        }
      `}</style>

      <div className="max-w-md mx-auto min-h-screen relative" style={{ background: '#1a1614' }}>
        {loading ? (
          <div className="flex items-center justify-center min-h-screen text-amber-100/40 shimmer">{t('common.loading')}</div>
        ) : view === 'role' ? (
          <RoleSelect onPick={setView} onStores={() => setView('stores')} />
        ) : view === 'customer-login' ? (
          <CustomerLogin
            customers={customers}
            onBack={() => setView('role')}
            onEnter={async (phone, name) => {
              const next = { ...customers };
              if (!next[phone]) {
                // 首次进入，自动注册
                next[phone] = {
                  name: name || '顾客', phone, points: 50, balance: 0, totalSpent: 0, coupons: [],
                  history: [{ t: Date.now(), text: '注册奖励 +50 积分', delta: 50 }],
                  createdAt: Date.now(),
                };
                await saveCustomers(next);
                showToast('欢迎，赠送 50 积分！');
              } else {
                showToast(`欢迎回来，${next[phone].name}`);
              }
              setCurrentPhone(phone);
              setView('customer-home');
            }}
          />
        ) : view === 'customer-home' && customer ? (
          <CustomerHome
            customer={customer}
            myOrders={Object.values(orders).filter((o) => o.customerPhone === currentPhone)}
            currentLocation={currentLocation}
            onLogout={() => { setCurrentPhone(null); setCart({}); setView('role'); }}
            onMenu={() => setView('customer-menu')}
            onSpin={() => setView('customer-spin')}
            onHistory={() => setView('customer-history')}
            onOrders={() => setView('customer-orders')}
            onRecharge={() => setView('customer-recharge')}
            onStores={() => setView('stores')}
            onVip={() => setView('customer-vip')}
          />
        ) : view === 'customer-vip' && customer ? (
          <VipView
            customer={customer}
            onBack={() => setView('customer-home')}
          />
        ) : view === 'stores' ? (
          <StoresView
            currentLocation={currentLocation}
            onSelect={(id) => { setLocation(id); showToast(`已选择 ${STORES[id].name}`); }}
            onBack={() => setView(currentPhone ? 'customer-home' : 'role')}
          />
        ) : view === 'customer-recharge' && customer ? (
          <RechargeView
            customer={customer}
            onBack={() => setView('customer-home')}
            onRecharge={async (amount, bonus) => {
              await recharge(amount, bonus);
              showToast(`充值成功 +€${amount + bonus}`);
            }}
          />
        ) : view === 'customer-menu' ? (
          <MenuView
            cart={cart}
            cartCount={cartCount}
            cartTotal={cartTotal}
            menuData={mergedMENU}
            onUpdateCart={updateCart}
            onBack={() => setView('customer-home')}
            onCheckout={() => setView('customer-cart')}
          />
        ) : view === 'customer-cart' ? (
          <CartView
            cart={cart}
            cartTotal={cartTotal}
            customer={customer}
            currentLocation={currentLocation}
            onLocation={setLocation}
            onUpdateCart={updateCart}
            onClear={() => setCart({})}
            onBack={() => setView('customer-menu')}
            onPlace={placeOrder}
          />
        ) : view === 'customer-orders' && customer ? (
          <CustomerOrdersView
            orders={Object.values(orders).filter((o) => o.customerPhone === currentPhone).sort((a, b) => b.createdAt - a.createdAt)}
            onBack={() => setView('customer-home')}
          />
        ) : view === 'customer-spin' && customer ? (
          <SpinView
            customer={customer}
            onBack={() => setView('customer-home')}
            onResult={async (prize) => {
              const next = { ...customers };
              const c = { ...next[currentPhone] };
              c.points -= SPIN_COST;
              const entry = { t: Date.now(), text: `转盘消耗 ${SPIN_COST} 积分`, delta: -SPIN_COST };
              if (prize.type === 'points') {
                c.points += prize.value;
                c.history = [{ t: Date.now(), text: `转盘中奖 +${prize.value} 积分`, delta: prize.value }, entry, ...c.history];
              } else if (prize.type === 'item' || prize.type === 'coupon') {
                c.coupons = [...(c.coupons || []), { id: Date.now(), label: prize.value, t: Date.now() }];
                c.history = [{ t: Date.now(), text: `转盘获得「${prize.value}」`, delta: 0 }, entry, ...c.history];
              } else {
                c.history = [{ t: Date.now(), text: '转盘未中奖', delta: 0 }, entry, ...c.history];
              }
              next[currentPhone] = c;
              await saveCustomers(next);
            }}
          />
        ) : view === 'customer-history' && customer ? (
          <HistoryView customer={customer} onBack={() => setView('customer-home')} />
        ) : view === 'employee-login' ? (
          <EmployeeLogin
            onBack={() => setView('role')}
            onLogin={() => setView('employee-home')}
            showToast={showToast}
          />
        ) : view === 'employee-home' ? (
          <EmployeeHome
            customers={customers}
            orders={orders}
            onLogout={() => setView('role')}
            onPick={(phone) => { setCurrentPhone(phone); setView('employee-detail'); }}
            onNew={() => setView('employee-new')}
            onOrders={() => setView('employee-orders')}
            onMenu={() => setView('employee-menu')}
          />
        ) : view === 'employee-menu' ? (
          <EmployeeMenuView
            menuOverrides={menuOverrides}
            onUpdate={async (itemId, patch) => {
              const next = { ...menuOverrides };
              if (patch === null) delete next[itemId];
              else next[itemId] = { ...(next[itemId] || {}), ...patch };
              await saveMenuOverrides(next);
            }}
            onBack={() => setView('employee-home')}
            showToast={showToast}
          />
        ) : view === 'employee-orders' ? (
          <EmployeeOrdersView
            orders={orders}
            onBack={() => setView('employee-home')}
            onUpdate={updateOrderStatus}
            showToast={showToast}
          />
        ) : view === 'employee-new' ? (
          <EmployeeNewCustomer
            onBack={() => setView('employee-home')}
            onCreate={(phone, name) => {
              if (customers[phone]) { showToast('该手机号已存在'); return; }
              const next = { ...customers, [phone]: { name, phone, points: 50, balance: 0, totalSpent: 0, coupons: [], history: [{ t: Date.now(), text: '员工注册 +50 积分', delta: 50 }], createdAt: Date.now() } };
              saveCustomers(next);
              showToast('已创建顾客');
              setView('employee-home');
            }}
          />
        ) : view === 'employee-detail' && customer ? (
          <EmployeeDetail
            customer={customer}
            onBack={() => { setCurrentPhone(null); setView('employee-home'); }}
            onUpdate={async (updater) => {
              const next = { ...customers };
              next[currentPhone] = updater(next[currentPhone]);
              await saveCustomers(next);
            }}
            onDelete={async () => {
              const next = { ...customers };
              delete next[currentPhone];
              await saveCustomers(next);
              setCurrentPhone(null);
              setView('employee-home');
              showToast('已删除顾客');
            }}
            showToast={showToast}
          />
        ) : null}

        {toast && (
          <div className="fixed left-1/2 -translate-x-1/2 bottom-8 px-5 py-3 rounded-full text-sm scale-in z-50"
               style={{ background: '#f5ede0', color: '#1a1614', boxShadow: '0 8px 32px rgba(0,0,0,0.4)' }}>
            {toast}
          </div>
        )}
      </div>
    </div>
    </I18nContext.Provider>
  );
}

// ========== 角色选择 ==========
function RoleSelect({ onPick, onStores }) {
  const { t, lang, setLang } = useT();
  const [langPickerOpen, setLangPickerOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col px-8 py-16 relative grain" style={{ background: 'linear-gradient(180deg, #1a1614 0%, #221915 100%)' }}>
      {/* 语言切换按钮 */}
      <div className="absolute top-4 right-4 z-10">
        <button onClick={() => setLangPickerOpen(!langPickerOpen)}
                className="px-3 py-1.5 rounded-full flex items-center gap-1.5 text-xs"
                style={{ background: '#2a2420', color: '#f5ede0', border: '1px solid #3a2e2a' }}>
          <span>{LANG_META[lang].flag}</span>
          <span>{LANG_META[lang].short}</span>
        </button>
        {langPickerOpen && (
          <div className="absolute top-full right-0 mt-1 rounded-xl overflow-hidden scale-in"
               style={{ background: '#1f1916', border: '1px solid #3a2e2a', boxShadow: '0 12px 32px rgba(0,0,0,0.5)' }}>
            {SUPPORTED_LANGS.map((l) => (
              <button key={l}
                      onClick={() => { setLang(l); setLangPickerOpen(false); }}
                      className="w-full px-4 py-2.5 flex items-center gap-2 text-sm whitespace-nowrap transition-colors"
                      style={{
                        background: l === lang ? 'rgba(232,93,47,0.15)' : 'transparent',
                        color: l === lang ? '#e85d2f' : '#f5ede0',
                      }}>
                <span>{LANG_META[l].flag}</span>
                <span>{LANG_META[l].name}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="flex-1 flex flex-col justify-center fade-up">
        <div className="mb-2 text-xs tracking-[0.4em]" style={{ color: '#e85d2f' }}>{t('role.tagline')}</div>
        <h1 className="font-display text-7xl leading-none mb-3" style={{ color: '#f5ede0' }}>
          Fude<br />Ramen
        </h1>
        <div className="font-jp text-sm mb-12" style={{ color: '#8a7a6e' }}>筆 ・ 会員プログラム</div>

        <button
          onClick={() => onPick('customer-login')}
          className="group relative overflow-hidden rounded-2xl p-6 mb-4 text-left transition-transform active:scale-[0.98]"
          style={{ background: '#e85d2f', color: '#fff' }}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs tracking-[0.3em] opacity-80 mb-1">CUSTOMER</div>
              <div className="font-display text-2xl">{t('role.customer')}</div>
              <div className="text-xs opacity-80 mt-2">{t('role.customerSub')}</div>
            </div>
            <UserCircle2 size={40} strokeWidth={1.2} />
          </div>
        </button>

        <button
          onClick={() => onPick('employee-login')}
          className="group relative overflow-hidden rounded-2xl p-6 mb-4 text-left transition-transform active:scale-[0.98] border"
          style={{ background: 'transparent', color: '#f5ede0', borderColor: '#3a2e2a' }}
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs tracking-[0.3em] mb-1" style={{ color: '#8a7a6e' }}>STAFF</div>
              <div className="font-display text-2xl">{t('role.employee')}</div>
              <div className="text-xs mt-2" style={{ color: '#8a7a6e' }}>{t('role.employeeSub')}</div>
            </div>
            <Store size={40} strokeWidth={1.2} />
          </div>
        </button>

        <button onClick={onStores}
                className="text-xs text-center py-2 transition-colors"
                style={{ color: '#8a7a6e' }}>
          📍 {t('role.viewStores')}
        </button>
      </div>
      <div className="text-center text-xs tracking-widest" style={{ color: '#3a2e2a' }}>EST. 2024 ・ 営業中</div>
    </div>
  );
}

// ========== 顾客登录 ==========
function CustomerLogin({ customers, onBack, onEnter }) {
  const { t } = useT();
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const existing = customers[phone];
  const isNew = PHONE_REGEX.test(phone) && !existing;
  const canSubmit = PHONE_REGEX.test(phone) && !submitting;

  const submit = async () => {
    if (!canSubmit) return;
    setSubmitting(true);
    await onEnter(phone, name.trim());
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen flex flex-col px-8 py-8 fade-up">
      <button onClick={onBack} className="self-start p-2 -ml-2" style={{ color: '#f5ede0' }}>
        <ArrowLeft size={22} />
      </button>
      <div className="flex-1 flex flex-col justify-center">
        <div className="text-xs tracking-[0.4em] mb-3" style={{ color: '#e85d2f' }}>{t('login.label')}</div>
        <h2 className="font-display text-3xl mb-2" style={{ color: '#f5ede0' }}>{t('login.title')}</h2>
        <div className="text-xs mb-8" style={{ color: '#8a7a6e' }}>
          {t('login.subtitle')}
        </div>

        <label className="text-xs mb-2" style={{ color: '#8a7a6e' }}>{t('login.phone')}</label>
        <input
          type="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, PHONE_MAX_LEN))}
          onKeyDown={(e) => { if (e.key === 'Enter' && (!isNew || name.trim())) submit(); }}
          placeholder={PHONE_PLACEHOLDER}
          className="bg-transparent border-b text-xl py-3 mb-6 outline-none transition-colors"
          style={{ color: '#f5ede0', borderColor: phone ? '#e85d2f' : '#3a2e2a' }}
        />

        {isNew && (
          <div className="fade-up">
            <label className="text-xs mb-2 block" style={{ color: '#8a7a6e' }}>
              {t('login.name')} <span style={{ color: '#5a4a3e' }}>({t('login.firstTime')})</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value.slice(0, 20))}
              onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
              placeholder="Marco"
              className="bg-transparent border-b text-xl py-3 mb-8 outline-none transition-colors w-full"
              style={{ color: '#f5ede0', borderColor: name ? '#e85d2f' : '#3a2e2a' }}
            />
          </div>
        )}

        {existing && (
          <div className="mb-8 px-4 py-3 rounded-xl flex items-center gap-3 scale-in"
               style={{ background: 'rgba(232,93,47,0.1)', border: '1px solid rgba(232,93,47,0.3)' }}>
            <div className="w-9 h-9 rounded-full flex items-center justify-center font-display"
                 style={{ background: '#3a2e2a', color: '#e85d2f' }}>
              {existing.name[0]}
            </div>
            <div className="flex-1">
              <div className="text-sm" style={{ color: '#f5ede0' }}>{t('login.welcomeBack', { name: existing.name })}</div>
              <div className="text-xs mt-0.5" style={{ color: '#8a7a6e' }}>
                {existing.points} {t('login.points')} · €{(existing.balance || 0).toFixed(2)}
              </div>
            </div>
          </div>
        )}

        <button
          disabled={!canSubmit}
          onClick={submit}
          className="rounded-2xl py-4 font-medium transition-all active:scale-[0.98] flex items-center justify-center gap-2"
          style={{ background: canSubmit ? '#e85d2f' : '#3a2e2a', color: canSubmit ? '#fff' : '#5a4a3e' }}
        >
          {submitting ? <Loader2 size={18} className="animate-spin" /> : (isNew ? t('login.btnRegister') : t('login.btnEnter'))}
        </button>

        <div className="text-[11px] mt-6 text-center" style={{ color: '#5a4a3e' }}>
          {t('login.noPassword')}
        </div>
      </div>
    </div>
  );
}

// ========== 顾客注册 ==========
function CustomerRegister({ customers, onBack, onRegister }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const checks = passwordChecks(password);
  const strong = checks.every((c) => c.test);
  const match = password === confirm && confirm.length > 0;
  const phoneTaken = customers[phone];
  const canSubmit = name.trim() && PHONE_REGEX.test(phone) && !phoneTaken && strong && match && !submitting;
  const strengthScore = checks.filter((c) => c.test).length;
  const strengthLabel = ['很弱', '弱', '一般', '中等', '较强', '强'][strengthScore];
  const strengthColor = ['#c44a25', '#c44a25', '#d4a574', '#d4a574', '#a3c577', '#5fb950'][strengthScore];

  const submit = async () => {
    if (!canSubmit) return;
    setSubmitting(true);
    await onRegister(phone, name.trim(), password);
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen flex flex-col px-8 py-8 fade-up">
      <button onClick={onBack} className="self-start p-2 -ml-2" style={{ color: '#f5ede0' }}>
        <ArrowLeft size={22} />
      </button>
      <div className="flex-1 flex flex-col justify-center">
        <div className="text-xs tracking-[0.4em] mb-3" style={{ color: '#e85d2f' }}>REGISTER</div>
        <h2 className="font-display text-3xl mb-6" style={{ color: '#f5ede0' }}>新用户注册</h2>

        <label className="text-xs mb-2" style={{ color: '#8a7a6e' }}>用户名</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value.slice(0, 20))}
          placeholder="Marco"
          className="bg-transparent border-b text-lg py-2.5 mb-5 outline-none transition-colors"
          style={{ color: '#f5ede0', borderColor: name ? '#e85d2f' : '#3a2e2a' }}
        />

        <label className="text-xs mb-2" style={{ color: '#8a7a6e' }}>手机号</label>
        <input
          type="tel"
          value={phone}
          onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, PHONE_MAX_LEN))}
          placeholder={PHONE_PLACEHOLDER}
          className="bg-transparent border-b text-lg py-2.5 mb-1 outline-none transition-colors"
          style={{
            color: '#f5ede0',
            borderColor: phoneTaken ? '#c44a25' : phone ? '#e85d2f' : '#3a2e2a',
          }}
        />
        {phoneTaken && <div className="text-[11px] mb-4" style={{ color: '#c44a25' }}>该手机号已被注册</div>}
        {!phoneTaken && <div className="mb-4" />}

        <label className="text-xs mb-2" style={{ color: '#8a7a6e' }}>密码</label>
        <div className="relative mb-2">
          <input
            type={showPw ? 'text' : 'password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="设置登录密码"
            className="w-full bg-transparent border-b text-lg py-2.5 pr-10 outline-none transition-colors"
            style={{ color: '#f5ede0', borderColor: password ? '#e85d2f' : '#3a2e2a' }}
          />
          <button onClick={() => setShowPw(!showPw)} className="absolute right-0 top-1/2 -translate-y-1/2 p-2" style={{ color: '#8a7a6e' }}>
            {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
          </button>
        </div>

        {/* 密码强度 */}
        {password && (
          <>
            <div className="flex items-center gap-2 mb-2">
              <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: '#2a2420' }}>
                <div className="h-full transition-all"
                     style={{ width: `${(strengthScore / 5) * 100}%`, background: strengthColor }} />
              </div>
              <span className="text-[11px]" style={{ color: strengthColor }}>{strengthLabel}</span>
            </div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 mb-4">
              {checks.map((c, i) => (
                <div key={i} className="flex items-center gap-1 text-[11px]">
                  {c.test ? (
                    <Check size={11} style={{ color: '#5fb950' }} />
                  ) : (
                    <X size={11} style={{ color: '#5a4a3e' }} />
                  )}
                  <span style={{ color: c.test ? '#a3c577' : '#5a4a3e' }}>{c.label}</span>
                </div>
              ))}
            </div>
          </>
        )}

        <label className="text-xs mb-2" style={{ color: '#8a7a6e' }}>确认密码</label>
        <input
          type={showPw ? 'text' : 'password'}
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') submit(); }}
          placeholder="再次输入密码"
          className="bg-transparent border-b text-lg py-2.5 mb-1 outline-none transition-colors"
          style={{
            color: '#f5ede0',
            borderColor: confirm && !match ? '#c44a25' : confirm ? '#e85d2f' : '#3a2e2a',
          }}
        />
        {confirm && !match && <div className="text-[11px] mb-4" style={{ color: '#c44a25' }}>两次密码不一致</div>}
        {(!confirm || match) && <div className="mb-6" />}

        <button
          disabled={!canSubmit}
          onClick={submit}
          className="rounded-2xl py-4 font-medium transition-all active:scale-[0.98] flex items-center justify-center gap-2"
          style={{ background: canSubmit ? '#e85d2f' : '#3a2e2a', color: canSubmit ? '#fff' : '#5a4a3e' }}
        >
          {submitting ? <Loader2 size={18} className="animate-spin" /> : '注册（赠 50 积分）'}
        </button>

        <div className="text-[11px] mt-4 leading-relaxed" style={{ color: '#5a4a3e' }}>
          注册即表示同意《会员服务协议》。我们不会与第三方共享您的密码与手机号。
        </div>
      </div>
    </div>
  );
}

// ========== 忘记密码 ==========
function CustomerForgot({ customers, onBack, onReset, showToast }) {
  const [step, setStep] = useState(1); // 1: phone, 2: code, 3: new password
  const [phone, setPhone] = useState('');
  const [sentCode, setSentCode] = useState(null); // { code, expiresAt }
  const [inputCode, setInputCode] = useState('');
  const [resendIn, setResendIn] = useState(0);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn(resendIn - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);

  const sendCode = () => {
    if (!PHONE_REGEX.test(phone)) { showToast('请输入正确手机号'); return; }
    if (!customers[phone]) { showToast('该手机号未注册'); return; }

    const code = generateResetCode();
    const expiresAt = Date.now() + 5 * 60 * 1000;
    setSentCode({ code, expiresAt });
    setResendIn(30);
    setStep(2);
    // 演示模式: 直接在 toast 中显示验证码
    // 生产模式: 服务端通过 Twilio 发送 SMS
    setTimeout(() => showToast(`📱 [演示] 验证码: ${code}`), 200);
  };

  const verifyCode = () => {
    if (!sentCode) return;
    if (Date.now() > sentCode.expiresAt) { showToast('验证码已过期，请重新发送'); return; }
    if (inputCode !== sentCode.code) { showToast('验证码错误'); return; }
    setStep(3);
  };

  const submitReset = async () => {
    if (!passwordStrong(password)) { showToast('密码强度不够'); return; }
    if (password !== confirm) { showToast('两次密码不一致'); return; }
    setSubmitting(true);
    await onReset(phone, password);
    setSubmitting(false);
  };

  const checks = passwordChecks(password);
  const strong = checks.every((c) => c.test);
  const strengthScore = checks.filter((c) => c.test).length;

  return (
    <div className="min-h-screen flex flex-col px-8 py-8 fade-up">
      <button onClick={step === 1 ? onBack : () => setStep(step - 1)} className="self-start p-2 -ml-2" style={{ color: '#f5ede0' }}>
        <ArrowLeft size={22} />
      </button>
      <div className="flex-1 flex flex-col justify-center">
        <div className="text-xs tracking-[0.4em] mb-3" style={{ color: '#e85d2f' }}>FORGOT PASSWORD · 步骤 {step} / 3</div>
        <h2 className="font-display text-3xl mb-8" style={{ color: '#f5ede0' }}>
          {step === 1 ? '找回密码' : step === 2 ? '输入验证码' : '设置新密码'}
        </h2>

        {step === 1 && (
          <>
            <div className="text-sm mb-6" style={{ color: '#8a7a6e' }}>
              输入注册时使用的手机号，我们将发送 6 位验证码短信。
            </div>
            <label className="text-xs mb-2" style={{ color: '#8a7a6e' }}>手机号</label>
            <input type="tel" value={phone}
                   onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, PHONE_MAX_LEN))}
                   placeholder={PHONE_PLACEHOLDER}
                   className="bg-transparent border-b text-xl py-3 mb-10 outline-none"
                   style={{ color: '#f5ede0', borderColor: phone ? '#e85d2f' : '#3a2e2a' }} />
            <button onClick={sendCode}
                    disabled={!PHONE_REGEX.test(phone)}
                    className="rounded-2xl py-4 font-medium flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
                    style={{
                      background: PHONE_REGEX.test(phone) ? '#e85d2f' : '#3a2e2a',
                      color: PHONE_REGEX.test(phone) ? '#fff' : '#5a4a3e',
                    }}>
              <MessageSquare size={16} />
              发送验证码
            </button>
          </>
        )}

        {step === 2 && (
          <>
            <div className="text-sm mb-2" style={{ color: '#8a7a6e' }}>
              验证码已发送至 <span style={{ color: '#f5ede0' }}>+39 {formatPhone(phone)}</span>
            </div>
            <div className="text-xs mb-6" style={{ color: '#5a4a3e' }}>5 分钟内有效</div>

            <div className="flex gap-2 justify-center mb-6">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="w-11 h-14 rounded-xl flex items-center justify-center text-2xl font-display"
                     style={{
                       background: '#2a2420',
                       border: `1px solid ${inputCode.length === i ? '#e85d2f' : '#3a2e2a'}`,
                       color: '#f5ede0',
                     }}>
                  {inputCode[i] || ''}
                </div>
              ))}
            </div>

            <input
              autoFocus
              type="tel"
              value={inputCode}
              onChange={(e) => {
                const v = e.target.value.replace(/\D/g, '').slice(0, 6);
                setInputCode(v);
                if (v.length === 6) setTimeout(verifyCode, 200);
              }}
              className="opacity-0 absolute"
              inputMode="numeric"
            />

            <button onClick={() => resendIn === 0 && sendCode()}
                    disabled={resendIn > 0}
                    className="text-xs mb-6 self-center"
                    style={{ color: resendIn > 0 ? '#5a4a3e' : '#e85d2f' }}>
              {resendIn > 0 ? `重新发送 (${resendIn}s)` : '重新发送'}
            </button>

            <button onClick={verifyCode}
                    disabled={inputCode.length !== 6}
                    className="rounded-2xl py-4 font-medium transition-all active:scale-[0.98]"
                    style={{
                      background: inputCode.length === 6 ? '#e85d2f' : '#3a2e2a',
                      color: inputCode.length === 6 ? '#fff' : '#5a4a3e',
                    }}>
              验证
            </button>
          </>
        )}

        {step === 3 && (
          <>
            <label className="text-xs mb-2" style={{ color: '#8a7a6e' }}>新密码</label>
            <div className="relative mb-2">
              <input type={showPw ? 'text' : 'password'} value={password}
                     onChange={(e) => setPassword(e.target.value)}
                     placeholder="设置新密码"
                     className="w-full bg-transparent border-b text-lg py-2.5 pr-10 outline-none"
                     style={{ color: '#f5ede0', borderColor: password ? '#e85d2f' : '#3a2e2a' }} />
              <button onClick={() => setShowPw(!showPw)} className="absolute right-0 top-1/2 -translate-y-1/2 p-2" style={{ color: '#8a7a6e' }}>
                {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {password && (
              <>
                <div className="h-1 rounded-full overflow-hidden mb-2" style={{ background: '#2a2420' }}>
                  <div className="h-full transition-all"
                       style={{ width: `${(strengthScore / 5) * 100}%`, background: ['#c44a25', '#c44a25', '#d4a574', '#d4a574', '#a3c577', '#5fb950'][strengthScore] }} />
                </div>
                <div className="grid grid-cols-2 gap-x-3 gap-y-1 mb-4">
                  {checks.map((c, i) => (
                    <div key={i} className="flex items-center gap-1 text-[11px]">
                      {c.test ? <Check size={11} style={{ color: '#5fb950' }} /> : <X size={11} style={{ color: '#5a4a3e' }} />}
                      <span style={{ color: c.test ? '#a3c577' : '#5a4a3e' }}>{c.label}</span>
                    </div>
                  ))}
                </div>
              </>
            )}

            <label className="text-xs mb-2 mt-2" style={{ color: '#8a7a6e' }}>确认新密码</label>
            <input type={showPw ? 'text' : 'password'} value={confirm}
                   onChange={(e) => setConfirm(e.target.value)}
                   placeholder="再次输入"
                   className="bg-transparent border-b text-lg py-2.5 mb-8 outline-none"
                   style={{
                     color: '#f5ede0',
                     borderColor: confirm && password !== confirm ? '#c44a25' : confirm ? '#e85d2f' : '#3a2e2a',
                   }} />

            <button onClick={submitReset}
                    disabled={!strong || password !== confirm || submitting}
                    className="rounded-2xl py-4 font-medium transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                    style={{
                      background: strong && password === confirm && !submitting ? '#e85d2f' : '#3a2e2a',
                      color: strong && password === confirm ? '#fff' : '#5a4a3e',
                    }}>
              {submitting ? <Loader2 size={18} className="animate-spin" /> : '重置密码并登录'}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ========== 顾客首页 ==========
function CustomerHome({ customer, myOrders, currentLocation, onLogout, onMenu, onSpin, onHistory, onOrders, onRecharge, onStores, onVip }) {
  const { t, lang } = useT();
  const activeOrders = (myOrders || []).filter((o) => o.status !== 'completed');
  const readyOrder = activeOrders.find((o) => o.status === 'ready');
  const balance = customer.balance || 0;
  const loc = STORES[currentLocation] || STORES.schio;
  const totalSpent = customer.totalSpent || 0;
  const vip = getVipLevel(totalSpent);
  const nextVip = getNextVip(vip.level);
  const vipProgress = nextVip ? Math.min(1, (totalSpent - vip.minSpent) / (nextVip.minSpent - vip.minSpent)) : 1;
  const vipName = t(`vip.lv${vip.level}.name`);

  return (
    <div className="min-h-screen flex flex-col pb-8 fade-up">
      <div className="px-6 pt-8 pb-4 flex items-start justify-between">
        <div>
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>{t('home.welcome')}</div>
          <div className="font-display text-2xl flex items-center gap-2" style={{ color: '#f5ede0' }}>
            {customer.name}
            <button onClick={onVip}
                    className="text-xs px-2 py-0.5 rounded-full flex items-center gap-1 font-sans"
                    style={{ background: `${vip.color}20`, color: vip.color, border: `1px solid ${vip.color}50` }}>
              {vip.emoji} V{vip.level}
            </button>
          </div>
          <div className="text-xs mt-1" style={{ color: '#5a4a3e' }}>{formatPhone(customer.phone)}</div>
        </div>
        <button onClick={onLogout} className="p-2" style={{ color: '#8a7a6e' }}>
          <LogOut size={20} />
        </button>
      </div>

      {/* 当前店铺 */}
      <button onClick={onStores}
              className="mx-6 mb-4 rounded-xl px-4 py-2.5 flex items-center justify-between transition-transform active:scale-[0.99]"
              style={{ background: '#2a2420', border: '1px solid #3a2e2a' }}>
        <div className="flex items-center gap-2.5">
          <span className="text-lg">📍</span>
          <div className="text-left">
            <div className="text-[10px] tracking-widest" style={{ color: '#8a7a6e' }}>{t('home.sede')}</div>
            <div className="text-sm font-medium" style={{ color: '#f5ede0' }}>Fude Ramen · {loc.name}</div>
          </div>
        </div>
        <div className="text-xs" style={{ color: '#e85d2f' }}>{t('common.switch')} →</div>
      </button>

      {/* 取餐提醒 */}
      {readyOrder && (
        <button onClick={onOrders}
                className="mx-6 mb-4 rounded-2xl p-4 flex items-center gap-3 scale-in transition-transform active:scale-[0.98]"
                style={{ background: '#d4a574', color: '#1a1614' }}>
          <Bell size={24} strokeWidth={2} />
          <div className="text-left flex-1">
            <div className="text-xs tracking-widest opacity-70">{t('home.orderReady')}</div>
            <div className="font-medium text-sm">{t('home.orderReadySub')}</div>
          </div>
        </button>
      )}

      {/* 钱包卡 - 余额 + 积分 + 优惠券 */}
      <div className="mx-6 rounded-3xl p-6 relative overflow-hidden mb-6"
           style={{ background: 'linear-gradient(135deg, #e85d2f 0%, #c44a25 60%, #8a3015 100%)' }}>
        <div className="absolute -right-8 -top-8 w-40 h-40 rounded-full opacity-20" style={{ background: '#fff' }} />
        <div className="absolute -right-16 -bottom-16 w-48 h-48 rounded-full opacity-10" style={{ background: '#fff' }} />

        <div className="relative flex items-start justify-between">
          <div>
            <div className="text-xs tracking-[0.3em] text-white/70 mb-1">{t('home.balanceLabel')}</div>
            <div className="font-display text-5xl text-white mb-1">€{balance.toFixed(2)}</div>
          </div>
          <button onClick={onRecharge}
                  className="px-4 py-2 rounded-full text-xs font-medium flex items-center gap-1 transition-transform active:scale-95"
                  style={{ background: '#fff', color: '#e85d2f' }}>
            {t('home.recharge')}
          </button>
        </div>

        <div className="relative mt-5 pt-4 flex items-center gap-6" style={{ borderTop: '1px solid rgba(255,255,255,0.18)' }}>
          <div>
            <div className="text-xs text-white/70">{t('home.points')}</div>
            <div className="font-display text-2xl text-white">{customer.points}</div>
          </div>
          <div className="w-px h-8 bg-white/20" />
          <div>
            <div className="text-xs text-white/70">{t('home.coupons')}</div>
            <div className="font-display text-2xl text-white">{(customer.coupons || []).length}</div>
          </div>
        </div>
      </div>

      {/* VIP 等级卡 */}
      <button onClick={onVip}
              className="mx-6 mb-6 rounded-2xl p-4 transition-transform active:scale-[0.98] text-left"
              style={{
                background: `linear-gradient(135deg, ${vip.color}25 0%, ${vip.color}08 100%)`,
                border: `1px solid ${vip.color}40`,
              }}>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl">{vip.emoji}</span>
            <div>
              <div className="text-xs tracking-widest" style={{ color: vip.color }}>
                V{vip.level} · {vip.it.toUpperCase()}
              </div>
              <div className="font-display text-base" style={{ color: '#f5ede0' }}>{vipName}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[10px]" style={{ color: '#8a7a6e' }}>{t('vip.totalSpent')}</div>
            <div className="font-display text-lg" style={{ color: '#f5ede0' }}>€{totalSpent.toFixed(0)}</div>
          </div>
        </div>

        {nextVip ? (
          <>
            <div className="h-2 rounded-full overflow-hidden mb-1.5" style={{ background: 'rgba(255,255,255,0.08)' }}>
              <div className="h-full rounded-full transition-all"
                   style={{ width: `${vipProgress * 100}%`, background: `linear-gradient(90deg, ${vip.color}, ${nextVip.color})` }} />
            </div>
            <div className="flex items-center justify-between text-[11px]">
              <span style={{ color: '#8a7a6e' }}>
                {t('vip.toNext', { next: `${nextVip.emoji} V${nextVip.level}`, diff: (nextVip.minSpent - totalSpent).toFixed(0) })}
              </span>
              <span style={{ color: '#5a4a3e' }}>{t('vip.viewBenefits')}</span>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-between text-[11px]">
            <span style={{ color: vip.color }}>🎉 {t('vip.maxLevel').replace(' · 感谢您的支持', '').replace(' · Grazie!', '').replace(' · Thank you!', '')}</span>
            <span style={{ color: '#5a4a3e' }}>{t('vip.viewBenefits')}</span>
          </div>
        )}
      </button>

      {/* 优惠券预览 */}
      {customer.coupons && customer.coupons.length > 0 && (
        <div className="px-6 mb-6">
          <div className="text-xs tracking-[0.3em] mb-3" style={{ color: '#8a7a6e' }}>{t('home.myCoupons')}</div>
          <div className="space-y-2">
            {customer.coupons.map((c) => (
              <div key={c.id} className="rounded-xl px-4 py-3 flex items-center justify-between border-l-4"
                   style={{ background: '#2a2420', borderColor: '#e85d2f', color: '#f5ede0' }}>
                <div className="flex items-center gap-2">
                  <Gift size={16} style={{ color: '#e85d2f' }} />
                  <span className="text-sm">{c.label}</span>
                </div>
                <span className="text-xs" style={{ color: '#5a4a3e' }}>{t('home.showInStore')}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 功能按钮 */}
      <div className="px-6 grid grid-cols-2 gap-3">
        <ActionCard onClick={onMenu} icon={<Package size={28} strokeWidth={1.4} />} title={t('home.actMenu')} sub={t('home.actMenuSub')} accent />
        <ActionCard
          onClick={onOrders}
          icon={<Receipt size={28} strokeWidth={1.4} />}
          title={t('home.actOrders')}
          sub={activeOrders.length > 0 ? t('home.actOrdersSubActive', { n: activeOrders.length }) : t('home.actOrdersSubEmpty')}
          badge={activeOrders.length > 0 ? activeOrders.length : null}
        />
        <ActionCard onClick={onSpin} icon={<Sparkles size={28} strokeWidth={1.4} />} title={t('home.actSpin')} sub={t('home.actSpinSub', { n: SPIN_COST })} />
        <ActionCard onClick={onHistory} icon={<History size={28} strokeWidth={1.4} />} title={t('home.actHistory')} sub={t('home.actHistorySub')} />
      </div>
    </div>
  );
}

function ActionCard({ onClick, icon, title, sub, accent, badge }) {
  return (
    <button onClick={onClick} className="rounded-2xl p-5 text-left transition-transform active:scale-[0.97] relative"
            style={{
              background: accent ? '#e85d2f' : '#2a2420',
              color: accent ? '#fff' : '#f5ede0',
              border: accent ? 'none' : '1px solid #3a2e2a',
            }}>
      {icon}
      <div className="mt-3 text-sm font-medium">{title}</div>
      <div className="text-xs mt-1 opacity-70">{sub}</div>
      {badge && (
        <div className="absolute top-3 right-3 min-w-5 h-5 px-1.5 rounded-full flex items-center justify-center text-xs font-bold"
             style={{ background: accent ? '#fff' : '#e85d2f', color: accent ? '#e85d2f' : '#fff' }}>
          {badge}
        </div>
      )}
    </button>
  );
}

// ========== 菜单 ==========
function MenuView({ cart, cartCount, cartTotal, menuData, onUpdateCart, onBack, onCheckout }) {
  const menu = menuData || MENU;
  const [tab, setTab] = useState('ramen');
  const [query, setQuery] = useState('');
  const [excludedAllergens, setExcludedAllergens] = useState([]);
  const [filterOpen, setFilterOpen] = useState(false);
  const [detailItem, setDetailItem] = useState(null);

  // 过滤逻辑: 类别 + 搜索 + 过敏原排除
  const searching = query.trim().length > 0;
  const q = query.trim().toLowerCase();

  // 搜索时跨所有类别，否则只显示当前类别
  const baseItems = searching ? Object.values(menu).flat() : menu[tab];
  const filteredItems = baseItems.filter((item) => {
    // 搜索匹配
    if (searching) {
      const hay = (item.name + ' ' + item.desc).toLowerCase();
      if (!hay.includes(q)) return false;
    }
    // 过敏原过滤
    if (excludedAllergens.length > 0 && item.allergens) {
      const hasExcluded = item.allergens.some((a) => excludedAllergens.includes(a));
      if (hasExcluded) return false;
    }
    return true;
  });

  return (
    <div className="min-h-screen fade-up" style={{ paddingBottom: cartCount > 0 ? 96 : 32 }}>
      <div className="px-6 pt-8 pb-3 flex items-center gap-3">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <div className="flex-1">
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>MENU · TAKEOUT</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>打包菜单</div>
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full" style={{ background: '#2a2420', color: '#d4a574' }}>
          <Package size={12} />
          <span className="text-xs">外带</span>
        </div>
      </div>

      {/* 搜索栏 + 过敏原过滤按钮 */}
      <div className="px-6 mb-3 flex gap-2">
        <div className="flex-1 flex items-center gap-2 px-3 py-2.5 rounded-xl" style={{ background: '#2a2420' }}>
          <Search size={16} style={{ color: '#8a7a6e' }} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索菜名或食材..."
            className="flex-1 bg-transparent outline-none text-sm"
            style={{ color: '#f5ede0' }}
          />
          {query && (
            <button onClick={() => setQuery('')} style={{ color: '#5a4a3e' }}>
              <X size={14} />
            </button>
          )}
        </div>
        <button onClick={() => setFilterOpen(true)}
                className="relative px-3 rounded-xl flex items-center gap-1.5 transition-all"
                style={{
                  background: excludedAllergens.length > 0 ? '#e85d2f' : '#2a2420',
                  color: excludedAllergens.length > 0 ? '#fff' : '#8a7a6e',
                }}>
          <span className="text-base">🚫</span>
          <span className="text-xs font-medium">过敏</span>
          {excludedAllergens.length > 0 && (
            <span className="absolute -top-1 -right-1 min-w-4 h-4 px-1 rounded-full flex items-center justify-center text-[10px] font-bold"
                  style={{ background: '#fff', color: '#e85d2f' }}>
              {excludedAllergens.length}
            </span>
          )}
        </button>
      </div>

      {/* 已激活的过敏原 chips */}
      {excludedAllergens.length > 0 && (
        <div className="px-6 mb-3 flex flex-wrap gap-1.5">
          <span className="text-[11px] py-1" style={{ color: '#8a7a6e' }}>排除:</span>
          {excludedAllergens.map((a) => {
            const allergen = ALLERGENS.find((x) => x.id === a);
            return (
              <button key={a} onClick={() => setExcludedAllergens(excludedAllergens.filter((x) => x !== a))}
                      className="text-[11px] px-2 py-1 rounded-full flex items-center gap-1"
                      style={{ background: 'rgba(232,93,47,0.15)', color: '#e85d2f' }}>
                {allergen?.emoji} {allergen?.cn || a}
                <X size={10} />
              </button>
            );
          })}
          <button onClick={() => setExcludedAllergens([])}
                  className="text-[11px] py-1 ml-1 underline" style={{ color: '#8a7a6e' }}>
            全部清除
          </button>
        </div>
      )}

      {/* 类别 tab (搜索时隐藏) */}
      {!searching && (
        <div className="px-6 flex gap-2 mb-4 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
          {MENU_TABS.map(([id, cn, jp, emoji]) => (
            <button key={id} onClick={() => setTab(id)}
                    className="flex-shrink-0 px-3 py-2 rounded-xl transition-all"
                    style={{
                      background: tab === id ? '#e85d2f' : '#2a2420',
                      color: tab === id ? '#fff' : '#8a7a6e',
                      minWidth: 64,
                    }}>
              <div className="text-base leading-none mb-1">{emoji}</div>
              <div className="text-xs font-medium whitespace-nowrap">{cn}</div>
            </button>
          ))}
        </div>
      )}

      {searching && (
        <div className="px-6 mb-3 text-xs" style={{ color: '#8a7a6e' }}>
          找到 <span style={{ color: '#e85d2f' }}>{filteredItems.length}</span> 道符合「{query}」的菜
        </div>
      )}

      <div className="px-6 space-y-3">
        {filteredItems.length === 0 ? (
          <div className="py-16 text-center">
            <Search size={40} strokeWidth={1} className="mx-auto mb-3" style={{ color: '#3a2e2a' }} />
            <div className="text-sm mb-1" style={{ color: '#8a7a6e' }}>没有找到菜品</div>
            <div className="text-xs" style={{ color: '#5a4a3e' }}>
              {searching && excludedAllergens.length > 0 ? '试试调整搜索词或过敏原过滤' :
               searching ? '换个关键词试试' :
               '这个类别下所有菜都含您选的过敏原'}
            </div>
          </div>
        ) : filteredItems.map((item, i) => {
          const qty = cart[item.id] || 0;
          return (
            <div key={item.id}
                 role="button"
                 tabIndex={0}
                 onClick={() => setDetailItem(item)}
                 onKeyDown={(e) => { if (e.key === 'Enter') setDetailItem(item); }}
                 className="w-full rounded-2xl p-4 flex items-center gap-3 fade-up transition-transform active:scale-[0.99] cursor-pointer select-none"
                 style={{ background: '#2a2420', animationDelay: `${Math.min(i * 30, 300)}ms` }}>
              <div className="flex-1 min-w-0 pointer-events-none">
                <div className="text-base font-medium flex items-center gap-1.5" style={{ color: '#f5ede0' }}>
                  {item.emoji && <span className="text-sm">{item.emoji}</span>}
                  <span className="truncate">{item.name}</span>
                </div>
                <div className="text-xs mt-1 truncate" style={{ color: '#8a7a6e' }}>{item.desc}</div>
                {item.allergens && item.allergens.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {item.allergens.slice(0, 4).map((a) => {
                      const al = ALLERGENS.find((x) => x.id === a);
                      return (
                        <span key={a} className="text-[10px] px-1.5 py-0.5 rounded"
                              style={{ background: '#221c19', color: '#5a4a3e' }}>
                          {al?.emoji} {al?.cn || a}
                        </span>
                      );
                    })}
                    {item.allergens.length > 4 && (
                      <span className="text-[10px] py-0.5" style={{ color: '#5a4a3e' }}>+{item.allergens.length - 4}</span>
                    )}
                  </div>
                )}
                <div className="mt-2 flex items-baseline gap-1">
                  <span className="font-display text-lg" style={{ color: '#e85d2f' }}>€{fmtPrice(item.price)}</span>
                  {item.unit && <span className="text-xs" style={{ color: '#5a4a3e' }}>/ {item.unit}</span>}
                </div>
              </div>
              {qty === 0 ? (
                <button type="button" onClick={(e) => { e.stopPropagation(); onUpdateCart(item.id, 1); }}
                        className="w-9 h-9 rounded-full flex items-center justify-center transition-transform active:scale-90 flex-shrink-0"
                        style={{ background: '#e85d2f', color: '#fff' }}>
                  <Plus size={18} />
                </button>
              ) : (
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button type="button" onClick={(e) => { e.stopPropagation(); onUpdateCart(item.id, -1); }}
                          className="w-8 h-8 rounded-full flex items-center justify-center"
                          style={{ background: '#3a2e2a', color: '#f5ede0' }}>
                    <Minus size={14} />
                  </button>
                  <span className="font-display text-lg w-6 text-center pointer-events-none" style={{ color: '#f5ede0' }}>{qty}</span>
                  <button type="button" onClick={(e) => { e.stopPropagation(); onUpdateCart(item.id, 1); }}
                          className="w-8 h-8 rounded-full flex items-center justify-center"
                          style={{ background: '#e85d2f', color: '#fff' }}>
                    <Plus size={14} />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* 菜品详情弹层 */}
      {detailItem && (
        <ItemDetail
          item={detailItem}
          qty={cart[detailItem.id] || 0}
          onUpdate={(delta) => onUpdateCart(detailItem.id, delta)}
          onClose={() => setDetailItem(null)}
        />
      )}

      {/* 底部结算条 */}
      {cartCount > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-30 scale-in">
          <div className="max-w-md mx-auto px-4 pb-4">
            <button onClick={onCheckout}
                    className="w-full flex items-center justify-between rounded-2xl px-5 py-4 transition-transform active:scale-[0.98]"
                    style={{ background: '#e85d2f', color: '#fff', boxShadow: '0 8px 32px rgba(232,93,47,0.4)' }}>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <ShoppingBag size={22} />
                  <div className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 rounded-full flex items-center justify-center text-xs font-bold"
                       style={{ background: '#fff', color: '#e85d2f' }}>
                    {cartCount}
                  </div>
                </div>
                <div className="text-left">
                  <div className="text-xs opacity-80">合计</div>
                  <div className="font-display text-xl">€{fmtPrice(cartTotal)}</div>
                </div>
              </div>
              <div className="text-sm font-medium">去结算 →</div>
            </button>
          </div>
        </div>
      )}

      {/* 过敏原过滤弹层 */}
      {filterOpen && (
        <div className="fixed inset-0 z-40 flex items-end" style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)' }}
             onClick={(e) => { if (e.target === e.currentTarget) setFilterOpen(false); }}>
          <div className="w-full max-w-md mx-auto rounded-t-3xl p-6 scale-in"
               style={{ background: '#1a1614', animation: 'slideUpModal 0.3s ease-out', maxHeight: '80vh', overflowY: 'auto' }}>
            <div className="flex items-center justify-between mb-2">
              <div>
                <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>ALLERGEN FILTER</div>
                <div className="font-display text-xl" style={{ color: '#f5ede0' }}>过敏原过滤</div>
              </div>
              <button onClick={() => setFilterOpen(false)} className="p-2" style={{ color: '#8a7a6e' }}>
                <X size={20} />
              </button>
            </div>
            <div className="text-xs mb-5" style={{ color: '#8a7a6e' }}>
              选择您要排除的过敏原。含此过敏原的菜品将被隐藏。
            </div>

            <div className="grid grid-cols-2 gap-2 mb-5">
              {ALLERGENS.map((a) => {
                const selected = excludedAllergens.includes(a.id);
                return (
                  <button key={a.id}
                          onClick={() => {
                            if (selected) setExcludedAllergens(excludedAllergens.filter((x) => x !== a.id));
                            else setExcludedAllergens([...excludedAllergens, a.id]);
                          }}
                          className="rounded-xl p-3 flex items-center gap-2 transition-all"
                          style={{
                            background: selected ? '#e85d2f' : '#2a2420',
                            color: selected ? '#fff' : '#f5ede0',
                            border: `1px solid ${selected ? '#e85d2f' : '#3a2e2a'}`,
                          }}>
                    <span className="text-lg">{a.emoji}</span>
                    <div className="text-left flex-1">
                      <div className="text-sm font-medium leading-none">{a.cn}</div>
                      <div className="text-[10px] opacity-70 mt-0.5">{a.it}</div>
                    </div>
                    {selected && <Check size={14} />}
                  </button>
                );
              })}
            </div>

            <div className="flex gap-2">
              <button onClick={() => setExcludedAllergens([])}
                      className="flex-1 rounded-xl py-3 text-sm"
                      style={{ background: '#2a2420', color: '#8a7a6e' }}>
                重置
              </button>
              <button onClick={() => setFilterOpen(false)}
                      className="flex-1 rounded-xl py-3 text-sm font-medium"
                      style={{ background: '#e85d2f', color: '#fff' }}>
                应用 {excludedAllergens.length > 0 && `(${excludedAllergens.length})`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ========== 菜品详情弹层 ==========
function ItemDetail({ item, qty, onUpdate, onClose }) {
  const { t } = useT();

  // ESC 关闭
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  // 锁定背景滚动
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-end"
         style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(6px)' }}
         onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="w-full max-w-md mx-auto rounded-t-3xl overflow-hidden flex flex-col"
           style={{
             maxHeight: '88vh',
             background: '#1a1614',
             animation: 'slideUpSheet 0.32s cubic-bezier(0.22,0.61,0.36,1)',
             border: '1px solid #2a2420',
           }}>

        {/* Hero - 图片 OR emoji + 渐变背景 */}
        <div className="relative flex-shrink-0 overflow-hidden"
             style={{
               aspectRatio: '4/3',
               background:
                 item.image ? '#1a1614' :
                 `radial-gradient(circle at 30% 40%, rgba(232,93,47,0.45), transparent 60%),
                  radial-gradient(circle at 70% 70%, rgba(212,165,116,0.30), transparent 70%),
                  linear-gradient(135deg, #2a1810 0%, #1a1614 100%)`,
             }}>
          {item.image ? (
            <img src={item.image} alt={item.name}
                 className="absolute inset-0 w-full h-full object-cover" />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center">
              <span style={{
                fontSize: '7.5rem',
                lineHeight: 1,
                filter: 'drop-shadow(0 8px 20px rgba(0,0,0,0.4))',
              }}>
                {item.emoji || '🍴'}
              </span>
            </div>
          )}

          {/* 顶部渐变 (按钮可见) */}
          <div className="absolute inset-x-0 top-0 h-20 pointer-events-none"
               style={{ background: 'linear-gradient(180deg, rgba(0,0,0,0.4), transparent)' }} />
          {/* 底部渐变 (与内容融合) */}
          <div className="absolute inset-x-0 bottom-0 h-24 pointer-events-none"
               style={{ background: 'linear-gradient(180deg, transparent, #1a1614)' }} />

          {/* 关闭按钮 */}
          <button onClick={onClose}
                  className="absolute top-4 right-4 w-9 h-9 rounded-full flex items-center justify-center transition-transform active:scale-90"
                  style={{ background: 'rgba(20,15,12,0.7)', color: '#fff', backdropFilter: 'blur(8px)' }}>
            <X size={20} />
          </button>

          {/* 类别 / 价格 浮动标签 */}
          <div className="absolute bottom-4 left-5 right-5 flex items-end justify-between">
            {item.emoji && (
              <div className="text-xs tracking-[0.3em]" style={{ color: '#d4a574' }}>
                FUDE RAMEN
              </div>
            )}
            <div className="px-3 py-1 rounded-full font-display text-lg"
                 style={{ background: '#e85d2f', color: '#fff', boxShadow: '0 4px 16px rgba(232,93,47,0.5)' }}>
              €{fmtPrice(item.price)}
            </div>
          </div>
        </div>

        {/* 可滚动内容 */}
        <div className="flex-1 overflow-y-auto px-6 pt-4 pb-2">
          <div className="font-display text-2xl mb-1" style={{ color: '#f5ede0' }}>
            {item.name}
          </div>

          {/* 描述 */}
          <div className="text-xs tracking-[0.3em] mt-4 mb-1.5" style={{ color: '#8a7a6e' }}>
            {t('menu.description').toUpperCase()}
          </div>
          <div className="text-sm leading-relaxed" style={{ color: '#d4c5b9' }}>
            {item.desc || t('menu.noDescription')}
          </div>

          {/* 过敏原 */}
          {item.allergens && item.allergens.length > 0 && (
            <>
              <div className="text-xs tracking-[0.3em] mt-5 mb-2" style={{ color: '#8a7a6e' }}>
                {t('menu.allergens').toUpperCase()} · ALLERGENI
              </div>
              <div className="flex flex-wrap gap-1.5">
                {item.allergens.map((a) => {
                  const al = ALLERGENS.find((x) => x.id === a);
                  return (
                    <div key={a} className="text-xs px-2.5 py-1.5 rounded-lg flex items-center gap-1.5"
                         style={{ background: '#2a2420', color: '#f5ede0', border: '1px solid #3a2e2a' }}>
                      <span className="text-sm">{al?.emoji}</span>
                      <span style={{ color: '#d4a574' }}>{al?.cn || a}</span>
                      <span className="text-[10px]" style={{ color: '#5a4a3e' }}>{a}</span>
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {/* 底部留点空间 */}
          <div className="h-3" />
        </div>

        {/* 底部加购按钮 */}
        <div className="p-4 flex-shrink-0" style={{ borderTop: '1px solid #2a2420', background: '#1a1614' }}>
          {qty === 0 ? (
            <button onClick={() => onUpdate(1)}
                    className="w-full rounded-xl py-3.5 font-medium transition-transform active:scale-[0.98] flex items-center justify-center gap-2"
                    style={{ background: '#e85d2f', color: '#fff', boxShadow: '0 8px 24px rgba(232,93,47,0.3)' }}>
              <Plus size={18} />
              <span>{t('menu.addToCart')} · €{fmtPrice(item.price)}</span>
            </button>
          ) : (
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <button onClick={() => onUpdate(-1)}
                        className="w-12 h-12 rounded-full flex items-center justify-center transition-transform active:scale-90"
                        style={{ background: '#3a2e2a', color: '#f5ede0' }}>
                  <Minus size={20} />
                </button>
                <span className="font-display text-3xl w-10 text-center" style={{ color: '#f5ede0' }}>{qty}</span>
                <button onClick={() => onUpdate(1)}
                        className="w-12 h-12 rounded-full flex items-center justify-center transition-transform active:scale-90"
                        style={{ background: '#e85d2f', color: '#fff', boxShadow: '0 4px 12px rgba(232,93,47,0.4)' }}>
                  <Plus size={20} />
                </button>
              </div>
              <div className="text-right">
                <div className="text-[10px] tracking-widest" style={{ color: '#8a7a6e' }}>TOTALE</div>
                <div className="font-display text-2xl" style={{ color: '#e85d2f' }}>
                  €{fmtPrice(item.price * qty)}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ========== 转盘 ==========
function SpinView({ customer, onBack, onResult }) {
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState(null);
  const canSpin = customer.points >= SPIN_COST;

  const spin = () => {
    if (!canSpin || spinning) return;
    setResult(null);
    const idx = Math.floor(Math.random() * PRIZES.length);
    const segAngle = 360 / PRIZES.length;
    // 让指针(顶部)指向 segment idx 的中心
    const targetMod = 360 - (idx * segAngle + segAngle / 2);
    const currentMod = ((rotation % 360) + 360) % 360;
    const delta = ((targetMod - currentMod) + 360) % 360;
    const newRotation = rotation + 360 * 6 + delta;
    setRotation(newRotation);
    setSpinning(true);
    setTimeout(() => {
      setSpinning(false);
      setResult(PRIZES[idx]);
      onResult(PRIZES[idx]);
    }, 4200);
  };

  const segAngle = 360 / PRIZES.length;
  const R = 140; // 半径
  const cx = 150, cy = 150;

  return (
    <div className="min-h-screen fade-up flex flex-col">
      <div className="px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <div className="flex-1">
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>LUCKY WHEEL</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>幸运转盘</div>
        </div>
        <div className="text-right">
          <div className="text-xs" style={{ color: '#8a7a6e' }}>积分</div>
          <div className="font-display text-xl" style={{ color: '#e85d2f' }}>{customer.points}</div>
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-8">
        <div className="relative" style={{ width: 300, height: 300 }}>
          {/* 装饰外圈 */}
          <div className="absolute inset-0 rounded-full" style={{ background: 'radial-gradient(circle, rgba(232,93,47,0.15) 0%, transparent 70%)' }} />

          <svg
            viewBox="0 0 300 300"
            style={{
              transform: `rotate(${rotation}deg)`,
              transition: spinning ? 'transform 4.2s cubic-bezier(0.17, 0.67, 0.16, 0.99)' : 'none',
              filter: 'drop-shadow(0 8px 24px rgba(0,0,0,0.5))',
            }}
          >
            {PRIZES.map((prize, i) => {
              const start = i * segAngle - 90;
              const end = (i + 1) * segAngle - 90;
              const rad1 = (start * Math.PI) / 180;
              const rad2 = (end * Math.PI) / 180;
              const x1 = cx + R * Math.cos(rad1);
              const y1 = cy + R * Math.sin(rad1);
              const x2 = cx + R * Math.cos(rad2);
              const y2 = cy + R * Math.sin(rad2);
              const midAngle = start + segAngle / 2;
              const midRad = (midAngle * Math.PI) / 180;
              const tx = cx + (R * 0.62) * Math.cos(midRad);
              const ty = cy + (R * 0.62) * Math.sin(midRad);

              return (
                <g key={i}>
                  <path
                    d={`M ${cx} ${cy} L ${x1} ${y1} A ${R} ${R} 0 0 1 ${x2} ${y2} Z`}
                    fill={prize.color}
                    stroke="#1a1614"
                    strokeWidth="2"
                  />
                  <text
                    x={tx}
                    y={ty}
                    fill={prize.text}
                    fontSize="13"
                    fontWeight="600"
                    textAnchor="middle"
                    dominantBaseline="middle"
                    transform={`rotate(${midAngle + 90}, ${tx}, ${ty})`}
                    style={{ fontFamily: "'Noto Sans SC', sans-serif" }}
                  >
                    {prize.label}
                  </text>
                </g>
              );
            })}
            <circle cx={cx} cy={cy} r="22" fill="#1a1614" stroke="#e85d2f" strokeWidth="2" />
          </svg>

          {/* 指针 */}
          <div className="absolute left-1/2 -translate-x-1/2 -top-2" style={{ zIndex: 10 }}>
            <svg width="32" height="40" viewBox="0 0 32 40">
              <path d="M16 38 L4 8 Q16 0 28 8 Z" fill="#e85d2f" stroke="#1a1614" strokeWidth="2" />
              <circle cx="16" cy="10" r="3" fill="#1a1614" />
            </svg>
          </div>

          {/* 中心 SPIN 按钮 */}
          <button
            onClick={spin}
            disabled={!canSpin || spinning}
            className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full w-16 h-16 font-display transition-transform active:scale-95 z-20"
            style={{
              background: canSpin && !spinning ? '#f5ede0' : '#3a2e2a',
              color: canSpin && !spinning ? '#1a1614' : '#5a4a3e',
              fontSize: '13px',
            }}
          >
            {spinning ? '...' : 'SPIN'}
          </button>
        </div>

        <div className="mt-8 text-center">
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>COST PER SPIN</div>
          <div className="font-display text-3xl mt-1" style={{ color: '#e85d2f' }}>{SPIN_COST} 积分</div>
          {!canSpin && <div className="text-xs mt-2" style={{ color: '#c44a25' }}>积分不足</div>}
        </div>

        {result && (
          <div className="mt-6 px-6 py-4 rounded-2xl scale-in text-center"
               style={{ background: '#2a2420', border: '1px solid #e85d2f' }}>
            <div className="text-xs tracking-[0.3em] mb-1" style={{ color: '#e85d2f' }}>RESULT</div>
            <div className="font-display text-xl" style={{ color: '#f5ede0' }}>{result.label}</div>
            {result.type === 'none' && <div className="text-xs mt-1" style={{ color: '#8a7a6e' }}>再接再厉</div>}
          </div>
        )}
      </div>
    </div>
  );
}

// ========== 积分明细 ==========
function HistoryView({ customer, onBack }) {
  return (
    <div className="min-h-screen fade-up">
      <div className="px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <div>
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>HISTORY</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>积分明细</div>
        </div>
      </div>
      <div className="px-6 space-y-2 pb-8">
        {customer.history.length === 0 ? (
          <div className="text-center py-12 text-sm" style={{ color: '#5a4a3e' }}>暂无记录</div>
        ) : customer.history.map((h, i) => (
          <div key={i} className="flex items-center justify-between py-3 px-4 rounded-xl fade-up"
               style={{ background: '#2a2420', animationDelay: `${i * 30}ms` }}>
            <div className="flex-1 min-w-0 pr-3">
              <div className="text-sm" style={{ color: '#f5ede0' }}>{h.text}</div>
              <div className="text-xs mt-0.5" style={{ color: '#5a4a3e' }}>
                {new Date(h.t).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
            <div className="text-right">
              {h.delta !== 0 && (
                <div className="font-display text-lg" style={{ color: h.delta > 0 ? '#e85d2f' : '#8a7a6e' }}>
                  {h.delta > 0 ? '+' : ''}{h.delta} 积分
                </div>
              )}
              {h.balanceDelta && (
                <div className="font-display text-sm" style={{ color: h.balanceDelta > 0 ? '#d4a574' : '#8a7a6e' }}>
                  {h.balanceDelta > 0 ? '+' : ''}€{Math.abs(h.balanceDelta).toFixed(2)}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ========== 员工登录 ==========
function EmployeeLogin({ onBack, onLogin, showToast }) {
  const [pin, setPin] = useState('');
  const submit = () => {
    if (pin === EMPLOYEE_PIN) onLogin();
    else { showToast('PIN 码错误'); setPin(''); }
  };
  return (
    <div className="min-h-screen flex flex-col px-8 py-8 fade-up">
      <button onClick={onBack} className="self-start p-2 -ml-2" style={{ color: '#f5ede0' }}>
        <ArrowLeft size={22} />
      </button>
      <div className="flex-1 flex flex-col justify-center">
        <div className="text-xs tracking-[0.4em] mb-3" style={{ color: '#e85d2f' }}>STAFF LOGIN</div>
        <h2 className="font-display text-3xl mb-2" style={{ color: '#f5ede0' }}>员工登录</h2>
        <div className="text-sm mb-10" style={{ color: '#8a7a6e' }}>请输入 4 位 PIN 码（演示: 1234）</div>

        <div className="flex gap-3 justify-center mb-8">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="w-14 h-16 rounded-xl flex items-center justify-center text-2xl font-display"
                 style={{
                   background: '#2a2420',
                   border: `1px solid ${pin.length === i ? '#e85d2f' : '#3a2e2a'}`,
                   color: '#f5ede0',
                 }}>
              {pin[i] ? '●' : ''}
            </div>
          ))}
        </div>

        <input
          autoFocus
          type="tel"
          value={pin}
          onChange={(e) => {
            const v = e.target.value.replace(/\D/g, '').slice(0, 4);
            setPin(v);
            if (v.length === 4) setTimeout(() => {
              if (v === EMPLOYEE_PIN) onLogin();
              else { showToast('PIN 码错误'); setPin(''); }
            }, 200);
          }}
          className="opacity-0 absolute"
          inputMode="numeric"
        />

        <button
          disabled={pin.length !== 4}
          onClick={submit}
          className="rounded-2xl py-4 font-medium transition-all active:scale-[0.98]"
          style={{ background: pin.length === 4 ? '#e85d2f' : '#3a2e2a', color: pin.length === 4 ? '#fff' : '#5a4a3e' }}
        >
          登录
        </button>
      </div>
    </div>
  );
}

// ========== 员工首页 ==========
function EmployeeHome({ customers, orders, onLogout, onPick, onNew, onOrders, onMenu }) {
  const [q, setQ] = useState('');
  const list = Object.values(customers)
    .filter((c) => !q || c.phone.includes(q) || c.name.includes(q))
    .sort((a, b) => b.createdAt - a.createdAt);

  const totalPoints = list.reduce((s, c) => s + c.points, 0);
  const pendingCount = Object.values(orders || {}).filter((o) => o.status === 'pending').length;
  const readyCount = Object.values(orders || {}).filter((o) => o.status === 'ready').length;

  return (
    <div className="min-h-screen fade-up">
      <div className="px-6 pt-8 pb-4 flex items-start justify-between">
        <div>
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>STAFF DASHBOARD</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>员工后台</div>
        </div>
        <button onClick={onLogout} className="p-2" style={{ color: '#8a7a6e' }}>
          <LogOut size={20} />
        </button>
      </div>

      {/* 打包订单入口 */}
      <button onClick={onOrders}
              className="mx-6 mb-3 rounded-2xl p-5 flex items-center justify-between transition-transform active:scale-[0.98] relative overflow-hidden"
              style={{ background: pendingCount > 0 ? '#e85d2f' : '#2a2420', color: pendingCount > 0 ? '#fff' : '#f5ede0' }}>
        {pendingCount > 0 && (
          <div className="absolute -right-4 -top-4 w-24 h-24 rounded-full opacity-20" style={{ background: '#fff' }} />
        )}
        <div className="flex items-center gap-3 relative">
          <Package size={28} strokeWidth={1.4} />
          <div className="text-left">
            <div className="text-xs tracking-[0.3em] opacity-70">TAKEOUT ORDERS</div>
            <div className="font-display text-lg">打包订单管理</div>
          </div>
        </div>
        <div className="flex gap-2 relative">
          {pendingCount > 0 && (
            <div className="px-2.5 py-1 rounded-full text-xs font-bold" style={{ background: '#fff', color: '#e85d2f' }}>
              新单 {pendingCount}
            </div>
          )}
          {readyCount > 0 && pendingCount === 0 && (
            <div className="px-2.5 py-1 rounded-full text-xs" style={{ background: '#d4a574', color: '#1a1614' }}>
              {readyCount} 待取
            </div>
          )}
        </div>
      </button>

      {/* 菜品管理入口 */}
      <button onClick={onMenu}
              className="mx-6 mb-4 rounded-2xl p-4 flex items-center justify-between transition-transform active:scale-[0.98]"
              style={{ background: '#2a2420', color: '#f5ede0', border: '1px solid #3a2e2a' }}>
        <div className="flex items-center gap-3">
          <Image size={24} strokeWidth={1.4} style={{ color: '#d4a574' }} />
          <div className="text-left">
            <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>MENU PHOTOS</div>
            <div className="text-sm font-medium">菜品照片管理</div>
          </div>
        </div>
        <span className="text-xs" style={{ color: '#e85d2f' }}>→</span>
      </button>

      <div className="px-6 grid grid-cols-2 gap-3 mb-4">
        <div className="rounded-2xl p-4" style={{ background: '#2a2420' }}>
          <div className="text-xs" style={{ color: '#8a7a6e' }}>顾客总数</div>
          <div className="font-display text-3xl mt-1" style={{ color: '#f5ede0' }}>{Object.keys(customers).length}</div>
        </div>
        <div className="rounded-2xl p-4" style={{ background: '#2a2420' }}>
          <div className="text-xs" style={{ color: '#8a7a6e' }}>流通积分</div>
          <div className="font-display text-3xl mt-1" style={{ color: '#e85d2f' }}>{totalPoints}</div>
        </div>
      </div>

      <div className="px-6 mb-2 text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>CUSTOMERS</div>

      <div className="px-6 mb-3 flex gap-2">
        <div className="flex-1 flex items-center gap-2 px-4 py-3 rounded-xl" style={{ background: '#2a2420' }}>
          <Search size={16} style={{ color: '#8a7a6e' }} />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="搜索手机号 / 昵称"
            className="bg-transparent outline-none text-sm flex-1"
            style={{ color: '#f5ede0' }}
          />
        </div>
        <button onClick={onNew} className="px-4 rounded-xl" style={{ background: '#e85d2f', color: '#fff' }}>
          <Plus size={20} />
        </button>
      </div>

      <div className="px-6 space-y-2 pb-8">
        {list.length === 0 ? (
          <div className="text-center py-16 text-sm" style={{ color: '#5a4a3e' }}>暂无顾客，点 + 新增</div>
        ) : list.map((c, i) => (
          <button key={c.phone} onClick={() => onPick(c.phone)}
                  className="w-full flex items-center justify-between p-4 rounded-2xl text-left fade-up transition-transform active:scale-[0.98]"
                  style={{ background: '#2a2420', animationDelay: `${i * 30}ms` }}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full flex items-center justify-center font-display"
                   style={{ background: '#3a2e2a', color: '#e85d2f' }}>
                {c.name[0]}
              </div>
              <div>
                <div className="text-sm font-medium" style={{ color: '#f5ede0' }}>{c.name}</div>
                <div className="text-xs mt-0.5" style={{ color: '#5a4a3e' }}>{formatPhone(c.phone)}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-display text-xl" style={{ color: '#e85d2f' }}>{c.points}</div>
              <div className="text-xs" style={{ color: '#5a4a3e' }}>积分</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// ========== 员工新增顾客 ==========
function EmployeeNewCustomer({ onBack, onCreate }) {
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const valid = PHONE_REGEX.test(phone) && name.trim();

  return (
    <div className="min-h-screen flex flex-col px-8 py-8 fade-up">
      <button onClick={onBack} className="self-start p-2 -ml-2" style={{ color: '#f5ede0' }}>
        <ArrowLeft size={22} />
      </button>
      <div className="flex-1 flex flex-col justify-center">
        <div className="text-xs tracking-[0.4em] mb-3" style={{ color: '#e85d2f' }}>NEW CUSTOMER</div>
        <h2 className="font-display text-3xl mb-8" style={{ color: '#f5ede0' }}>新增顾客</h2>

        <label className="text-xs mb-2" style={{ color: '#8a7a6e' }}>手机号</label>
        <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, PHONE_MAX_LEN))}
               placeholder={PHONE_PLACEHOLDER}
               className="bg-transparent border-b text-xl py-3 mb-6 outline-none"
               style={{ color: '#f5ede0', borderColor: phone ? '#e85d2f' : '#3a2e2a' }} />

        <label className="text-xs mb-2" style={{ color: '#8a7a6e' }}>昵称</label>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="顾客称呼"
               className="bg-transparent border-b text-xl py-3 mb-10 outline-none"
               style={{ color: '#f5ede0', borderColor: name ? '#e85d2f' : '#3a2e2a' }} />

        <button disabled={!valid} onClick={() => onCreate(phone, name.trim())}
                className="rounded-2xl py-4 font-medium transition-all active:scale-[0.98]"
                style={{ background: valid ? '#e85d2f' : '#3a2e2a', color: valid ? '#fff' : '#5a4a3e' }}>
          创建顾客（赠送 50 积分）
        </button>
      </div>
    </div>
  );
}

// ========== 员工 - 顾客详情 ==========
function EmployeeDetail({ customer, onBack, onUpdate, onDelete, showToast }) {
  const [amount, setAmount] = useState('');
  const [mode, setMode] = useState('purchase'); // purchase | add | deduct | recharge | spend

  const balance = customer.balance || 0;

  const apply = () => {
    const n = parseInt(amount, 10);
    if (!n || n <= 0) { showToast('请输入正确数字'); return; }

    if (mode === 'purchase') {
      onUpdate((c) => {
        const oldLevel = getVipLevel(c.totalSpent || 0).level;
        const newSpent = (c.totalSpent || 0) + n;
        const newLevel = getVipLevel(newSpent).level;
        const history = [{ t: Date.now(), text: `消费 €${n} 获得 ${n} 积分`, delta: n }, ...c.history];
        if (newLevel > oldLevel) {
          const lv = VIP_LEVELS.find((x) => x.level === newLevel);
          history.unshift({ t: Date.now(), text: `🎉 升级到 ${lv.emoji} V${lv.level} ${lv.name}！`, delta: 0 });
        }
        return { ...c, points: c.points + n, totalSpent: newSpent, history };
      });
      showToast(`记录消费 €${n}，+${n} 积分`);
    } else if (mode === 'add') {
      onUpdate((c) => ({
        ...c,
        points: c.points + n,
        history: [{ t: Date.now(), text: `员工手动 +${n} 积分`, delta: n }, ...c.history],
      }));
      showToast(`+${n} 积分`);
    } else if (mode === 'deduct') {
      if (n > customer.points) { showToast('积分不足'); return; }
      onUpdate((c) => ({
        ...c,
        points: c.points - n,
        history: [{ t: Date.now(), text: `员工兑换扣除 ${n} 积分`, delta: -n }, ...c.history],
      }));
      showToast(`-${n} 积分`);
    } else if (mode === 'recharge') {
      onUpdate((c) => ({
        ...c,
        balance: (c.balance || 0) + n,
        history: [{ t: Date.now(), text: `员工充值 €${n}`, delta: 0, balanceDelta: n }, ...c.history],
      }));
      showToast(`充值 €${n}`);
    } else if (mode === 'spend') {
      if (n > balance) { showToast('余额不足'); return; }
      onUpdate((c) => {
        const oldLevel = getVipLevel(c.totalSpent || 0).level;
        const newSpent = (c.totalSpent || 0) + n;
        const newLevel = getVipLevel(newSpent).level;
        const history = [{ t: Date.now(), text: `余额支付 €${n}，+${n} 积分`, delta: n, balanceDelta: -n }, ...c.history];
        if (newLevel > oldLevel) {
          const lv = VIP_LEVELS.find((x) => x.level === newLevel);
          history.unshift({ t: Date.now(), text: `🎉 升级到 ${lv.emoji} V${lv.level} ${lv.name}！`, delta: 0 });
        }
        return { ...c, balance: (c.balance || 0) - n, points: c.points + n, totalSpent: newSpent, history };
      });
      showToast(`扣余额 €${n}，+${n} 积分`);
    }
    setAmount('');
  };

  const redeemCoupon = (couponId) => {
    onUpdate((c) => ({
      ...c,
      coupons: c.coupons.filter((x) => x.id !== couponId),
      history: [{ t: Date.now(), text: `核销优惠券`, delta: 0 }, ...c.history],
    }));
    showToast('已核销优惠券');
  };

  const isBalanceMode = mode === 'recharge' || mode === 'spend';

  return (
    <div className="min-h-screen fade-up pb-8">
      <div className="px-6 pt-8 pb-4 flex items-center justify-between">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <button onClick={() => { if (confirm('确定删除该顾客？')) onDelete(); }}
                className="p-2" style={{ color: '#8a7a6e' }}>
          <Trash2 size={18} />
        </button>
      </div>

      <div className="px-6">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-full flex items-center justify-center font-display text-2xl"
               style={{ background: '#3a2e2a', color: '#e85d2f' }}>
            {customer.name[0]}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>{customer.name}</div>
              {(() => {
                const vip = getVipLevel(customer.totalSpent || 0);
                return (
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full font-medium"
                        style={{ background: `${vip.color}25`, color: vip.color, border: `1px solid ${vip.color}60` }}>
                    {vip.emoji} V{vip.level}
                  </span>
                );
              })()}
            </div>
            <div className="text-xs mt-0.5" style={{ color: '#5a4a3e' }}>
              {formatPhone(customer.phone)} · 累计 €{(customer.totalSpent || 0).toFixed(0)}
            </div>
          </div>
        </div>

        {/* 钱包卡 */}
        <div className="rounded-3xl p-5 mb-6 relative overflow-hidden"
             style={{ background: 'linear-gradient(135deg, #e85d2f 0%, #c44a25 100%)' }}>
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="text-xs tracking-[0.3em] text-white/70 mb-1">BALANCE · 余额</div>
              <div className="font-display text-4xl text-white">€{balance.toFixed(2)}</div>
            </div>
            <div className="text-right">
              <div className="text-xs tracking-[0.3em] text-white/70 mb-1">POINTS · 积分</div>
              <div className="font-display text-4xl text-white">{customer.points}</div>
            </div>
          </div>
        </div>

        {/* 模式切换 */}
        <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>POINTS · 积分操作</div>
        <div className="flex gap-2 mb-3">
          {[['purchase', '消费记账'], ['add', '手动加分'], ['deduct', '兑换扣分']].map(([k, label]) => (
            <button key={k} onClick={() => setMode(k)}
                    className="flex-1 py-2 rounded-xl text-xs transition-all"
                    style={{
                      background: mode === k ? '#e85d2f' : '#2a2420',
                      color: mode === k ? '#fff' : '#8a7a6e',
                    }}>
              {label}
            </button>
          ))}
        </div>

        <div className="text-xs tracking-[0.3em] mb-2 mt-4" style={{ color: '#8a7a6e' }}>BALANCE · 余额操作</div>
        <div className="flex gap-2 mb-3">
          {[['recharge', '充值'], ['spend', '余额支付']].map(([k, label]) => (
            <button key={k} onClick={() => setMode(k)}
                    className="flex-1 py-2 rounded-xl text-xs transition-all"
                    style={{
                      background: mode === k ? '#d4a574' : '#2a2420',
                      color: mode === k ? '#1a1614' : '#8a7a6e',
                    }}>
              {label}
            </button>
          ))}
        </div>

        <div className="flex gap-2 mb-6">
          <div className="flex-1 px-4 py-3 rounded-xl flex items-center gap-2" style={{ background: '#2a2420' }}>
            <span className="text-xs" style={{ color: '#8a7a6e' }}>
              {mode === 'purchase' ? '消费 €' : isBalanceMode ? '金额 €' : '积分'}
            </span>
            <input
              type="tel"
              value={amount}
              onChange={(e) => setAmount(e.target.value.replace(/\D/g, ''))}
              placeholder={mode === 'purchase' ? '48' : isBalanceMode ? '100' : '10'}
              className="bg-transparent outline-none text-lg flex-1"
              style={{ color: '#f5ede0' }}
            />
          </div>
          <button onClick={apply} disabled={!amount}
                  className="px-5 rounded-xl font-medium"
                  style={{
                    background: amount ? (isBalanceMode ? '#d4a574' : '#e85d2f') : '#3a2e2a',
                    color: amount ? (isBalanceMode ? '#1a1614' : '#fff') : '#5a4a3e',
                  }}>
            确认
          </button>
        </div>

        {/* 优惠券 */}
        {customer.coupons && customer.coupons.length > 0 && (
          <div className="mb-6">
            <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>COUPONS · 待核销</div>
            <div className="space-y-2">
              {customer.coupons.map((c) => (
                <div key={c.id} className="rounded-xl p-3 flex items-center justify-between"
                     style={{ background: '#2a2420', border: '1px dashed #3a2e2a' }}>
                  <div className="flex items-center gap-2">
                    <Gift size={14} style={{ color: '#e85d2f' }} />
                    <span className="text-sm" style={{ color: '#f5ede0' }}>{c.label}</span>
                  </div>
                  <button onClick={() => redeemCoupon(c.id)}
                          className="text-xs px-3 py-1 rounded-full"
                          style={{ background: '#e85d2f', color: '#fff' }}>
                    核销
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 历史 */}
        <div>
          <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>HISTORY · 最近 10 条</div>
          <div className="space-y-1.5">
            {customer.history.slice(0, 10).map((h, i) => (
              <div key={i} className="flex items-center justify-between py-2 px-3 rounded-lg text-sm"
                   style={{ background: '#221c19' }}>
                <div>
                  <div style={{ color: '#f5ede0' }}>{h.text}</div>
                  <div className="text-xs mt-0.5" style={{ color: '#5a4a3e' }}>
                    {new Date(h.t).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
                {h.delta !== 0 && (
                  <div className="font-display" style={{ color: h.delta > 0 ? '#e85d2f' : '#8a7a6e' }}>
                    {h.delta > 0 ? '+' : ''}{h.delta}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ========== 购物车 / 下单 ==========
function CartView({ cart, cartTotal, customer, currentLocation, onLocation, onUpdateCart, onClear, onBack, onPlace }) {
  const [note, setNote] = useState('');
  const [payMethod, setPayMethod] = useState('pickup'); // pickup | balance
  const [orderType, setOrderType] = useState('takeaway'); // takeaway | delivery
  const [address, setAddress] = useState('');
  const [distance, setDistance] = useState(null); // null | { status, km, eta, msg }
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [searching, setSearching] = useState(false);
  const [addressPicked, setAddressPicked] = useState(false); // true after user picked from list
  const [submitting, setSubmitting] = useState(false);

  const items = Object.entries(cart).map(([id, qty]) => ({ ...findItem(id), qty }));
  const empty = items.length === 0;
  const estPoints = Math.floor(cartTotal);
  const balance = customer.balance || 0;
  const canPayBalance = balance >= cartTotal;
  const loc = STORES[currentLocation] || STORES.schio;

  // 地址输入 → 自动补全建议（用 Photon API）
  useEffect(() => {
    if (orderType !== 'delivery' || addressPicked || address.trim().length < 3) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }
    setSearching(true);
    const t = setTimeout(async () => {
      const results = await autocompleteAddress(address, loc.coords.lat, loc.coords.lng);
      setSuggestions(results);
      setShowSuggestions(true);
      setSearching(false);
    }, 280);
    return () => clearTimeout(t);
  }, [address, orderType, addressPicked, loc.coords.lat, loc.coords.lng]);

  // 切换到外送时清掉成功状态
  useEffect(() => {
    if (orderType === 'takeaway') {
      setDistance(null);
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [orderType]);

  // 切换店铺时重置已确认地址（配送范围可能不同）
  useEffect(() => {
    if (addressPicked) {
      setAddressPicked(false);
      setDistance(null);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentLocation]);

  const computeDistance = (coords) => {
    const km = haversineKm(loc.coords.lat, loc.coords.lng, coords.lat, coords.lng);
    if (km > MAX_DELIVERY_KM) {
      return { status: 'error', km, msg: `🚫 超出配送范围 · ${km.toFixed(1)} km（最远 ${MAX_DELIVERY_KM} km）` };
    }
    const eta = Math.round(km * MIN_PER_KM + MIN_PREP_MIN);
    return { status: 'ok', km, eta, msg: `✅ ${km.toFixed(1)} km · 约 ${eta} 分钟送达` };
  };

  const pickSuggestion = async (s) => {
    const fullAddr = s.secondary ? `${s.display}, ${s.secondary}` : s.display;
    setAddress(fullAddr);
    setSuggestions([]);
    setShowSuggestions(false);
    setAddressPicked(true);
    setSearching(true); // 显示加载: 正在获取坐标
    const coords = await resolveSuggestionCoords(s);
    setSearching(false);
    if (coords) {
      setDistance(computeDistance(coords));
    } else {
      setDistance({ status: 'warn', msg: '⚠️ 无法获取精确坐标,员工将人工核实' });
    }
  };

  const onAddressChange = (v) => {
    setAddress(v);
    if (addressPicked) {
      setAddressPicked(false);
      setDistance(null);
    }
  };

  const deliveryReady = orderType !== 'delivery' || (
    address.trim().length >= 5 &&
    !(addressPicked && distance?.status === 'error')  // 只有在「已选 + 超距」时才阻止
  );
  const canSubmit = !empty && deliveryReady && !submitting;

  const submit = async () => {
    if (!canSubmit) return;
    setSubmitting(true);
    await onPlace({
      note,
      payWithBalance: payMethod === 'balance',
      orderType,
      locationId: currentLocation,
      deliveryAddress: orderType === 'delivery' ? address.trim() : '',
      distanceKm: distance?.km,
      etaMin: distance?.eta,
    });
    setSubmitting(false);
  };

  return (
    <div className="min-h-screen fade-up pb-32">
      <div className="px-6 pt-8 pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
            <ArrowLeft size={22} />
          </button>
          <div>
            <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>CHECKOUT</div>
            <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>确认订单</div>
          </div>
        </div>
        {!empty && (
          <button onClick={onClear} className="text-xs px-3 py-1.5 rounded-full" style={{ color: '#8a7a6e' }}>
            清空
          </button>
        )}
      </div>

      {empty ? (
        <div className="px-6 py-20 text-center">
          <ShoppingBag size={48} strokeWidth={1} className="mx-auto mb-4" style={{ color: '#3a2e2a' }} />
          <div className="text-sm" style={{ color: '#5a4a3e' }}>购物车是空的</div>
          <button onClick={onBack} className="mt-6 px-6 py-2 rounded-full text-sm"
                  style={{ background: '#e85d2f', color: '#fff' }}>
            去选餐
          </button>
        </div>
      ) : (
        <>
          {/* 店铺选择 */}
          <div className="mx-6 mb-3">
            <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>SEDE · 店铺</div>
            <div className="grid grid-cols-2 gap-2">
              {STORE_LIST.map((s) => {
                const selected = s.id === currentLocation;
                return (
                  <button key={s.id} onClick={() => onLocation(s.id)}
                          className="rounded-xl p-3 text-left transition-all"
                          style={{
                            background: selected ? 'rgba(232,93,47,0.15)' : '#2a2420',
                            border: `1px solid ${selected ? '#e85d2f' : '#3a2e2a'}`,
                            color: '#f5ede0',
                          }}>
                    <div className="text-xs" style={{ color: selected ? '#e85d2f' : '#8a7a6e' }}>📍 {s.province}</div>
                    <div className="text-sm font-medium mt-0.5">{s.name}</div>
                    <div className="text-[10px] mt-0.5" style={{ color: '#5a4a3e' }}>{s.phone}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 取餐方式 */}
          <div className="mx-6 mb-4">
            <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>TIPO ORDINE · 类型</div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => setOrderType('takeaway')}
                      className="rounded-xl p-3 flex items-center gap-2 transition-all"
                      style={{
                        background: orderType === 'takeaway' ? '#e85d2f' : '#2a2420',
                        color: orderType === 'takeaway' ? '#fff' : '#f5ede0',
                        border: `1px solid ${orderType === 'takeaway' ? '#e85d2f' : '#3a2e2a'}`,
                      }}>
                <span className="text-xl">🥡</span>
                <div className="text-left flex-1">
                  <div className="text-sm font-medium">Take Away</div>
                  <div className="text-[10px] opacity-70">堂取・到店取餐</div>
                </div>
              </button>
              <button onClick={() => setOrderType('delivery')}
                      className="rounded-xl p-3 flex items-center gap-2 transition-all"
                      style={{
                        background: orderType === 'delivery' ? '#e85d2f' : '#2a2420',
                        color: orderType === 'delivery' ? '#fff' : '#f5ede0',
                        border: `1px solid ${orderType === 'delivery' ? '#e85d2f' : '#3a2e2a'}`,
                      }}>
                <span className="text-xl">🛵</span>
                <div className="text-left flex-1">
                  <div className="text-sm font-medium">Delivery</div>
                  <div className="text-[10px] opacity-70">外送 · 18:30-22:00</div>
                </div>
              </button>
            </div>
          </div>

          {/* 配送地址（仅 delivery） */}
          {orderType === 'delivery' && (
            <div className="mx-6 mb-4 fade-up">
              <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>INDIRIZZO · 配送地址 *</div>
              <div className="relative">
                <input
                  type="text"
                  value={address}
                  onChange={(e) => onAddressChange(e.target.value)}
                  onFocus={() => { if (suggestions.length > 0 && !addressPicked) setShowSuggestions(true); }}
                  placeholder="Via Roma 10, 36015 Schio"
                  autoComplete="off"
                  className="w-full rounded-xl px-4 py-3 pr-10 text-sm outline-none transition-colors"
                  style={{
                    background: '#2a2420',
                    color: '#f5ede0',
                    border: `1px solid ${addressPicked && distance?.status === 'ok' ? '#5fb950' : addressPicked && distance?.status === 'error' ? '#c44a25' : address.trim().length >= 5 ? '#e85d2f' : '#3a2e2a'}`,
                  }}
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center">
                  {searching ? (
                    <Loader2 size={16} className="animate-spin" style={{ color: '#8a7a6e' }} />
                  ) : addressPicked && distance?.status === 'ok' ? (
                    <CheckCircle2 size={16} style={{ color: '#5fb950' }} />
                  ) : address ? (
                    <button onClick={() => { setAddress(''); setAddressPicked(false); setDistance(null); setSuggestions([]); }}
                            style={{ color: '#5a4a3e' }}>
                      <X size={14} />
                    </button>
                  ) : (
                    <Search size={14} style={{ color: '#5a4a3e' }} />
                  )}
                </div>

                {/* 自动补全下拉 */}
                {showSuggestions && suggestions.length > 0 && !addressPicked && (
                  <div className="absolute left-0 right-0 top-full mt-1 rounded-xl overflow-hidden z-20 fade-up"
                       style={{
                         background: '#1f1916',
                         border: '1px solid #3a2e2a',
                         boxShadow: '0 12px 32px rgba(0,0,0,0.5)',
                       }}>
                    {suggestions.map((s, i) => (
                      <button key={i} onClick={() => pickSuggestion(s)}
                              className="w-full px-3 py-2.5 flex items-start gap-2.5 text-left transition-colors"
                              style={{
                                borderTop: i > 0 ? '1px solid #2a2420' : 'none',
                                background: 'transparent',
                              }}
                              onMouseEnter={(e) => e.currentTarget.style.background = '#2a2420'}
                              onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                        <span className="text-sm mt-0.5">📍</span>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm truncate" style={{ color: '#f5ede0' }}>{s.display}</div>
                          {s.secondary && (
                            <div className="text-[11px] mt-0.5 truncate" style={{ color: '#8a7a6e' }}>{s.secondary}</div>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* 状态说明 */}
              <div className="text-[11px] mt-1.5 flex items-start gap-1" style={{ color: '#5a4a3e' }}>
                {addressPicked && distance?.status === 'ok' ? (
                  <span style={{ color: '#5fb950' }}>✓ 地址已确认 · 在 {MAX_DELIVERY_KM} km 配送范围内</span>
                ) : address.trim().length >= 5 ? (
                  <span>请输入完整地址（街道 + 门牌 + 城市 + 邮编）。员工会在备餐前核实是否在 {MAX_DELIVERY_KM} km 配送范围内</span>
                ) : (
                  <span>请输入完整地址 · 配送范围 {MAX_DELIVERY_KM} km</span>
                )}
              </div>

              {/* 距离检测结果 - 只在已选并且超距时显示警告 */}
              {distance && distance.status === 'error' && (
                <div className="mt-3 px-3 py-2.5 rounded-xl text-sm flex items-center gap-2 scale-in"
                     style={{
                       background: 'rgba(196,74,37,0.12)',
                       color: '#e85d2f',
                       border: '1px solid currentColor',
                     }}>
                  <span>{distance.msg}</span>
                </div>
              )}
              {distance && distance.status === 'ok' && (
                <div className="mt-3 px-3 py-2.5 rounded-xl text-sm flex items-center gap-2 scale-in"
                     style={{
                       background: 'rgba(95,185,80,0.12)',
                       color: '#5fb950',
                       border: '1px solid currentColor',
                     }}>
                  <span>{distance.msg}</span>
                </div>
              )}
            </div>
          )}

          {/* 商品列表 */}
          <div className="mx-6 rounded-2xl overflow-hidden mb-4" style={{ background: '#2a2420' }}>
            {items.map((item, idx) => (
              <div key={item.id} className="px-4 py-3 flex items-center gap-3"
                   style={{ borderTop: idx > 0 ? '1px solid #221c19' : 'none' }}>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium" style={{ color: '#f5ede0' }}>{item.name}</div>
                  <div className="text-xs mt-0.5" style={{ color: '#5a4a3e' }}>
                    €{fmtPrice(item.price)}{item.unit && ` / ${item.unit}`}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => onUpdateCart(item.id, -1)}
                          className="w-7 h-7 rounded-full flex items-center justify-center"
                          style={{ background: '#3a2e2a', color: '#f5ede0' }}>
                    <Minus size={12} />
                  </button>
                  <span className="font-display w-6 text-center" style={{ color: '#f5ede0' }}>{item.qty}</span>
                  <button onClick={() => onUpdateCart(item.id, 1)}
                          className="w-7 h-7 rounded-full flex items-center justify-center"
                          style={{ background: '#e85d2f', color: '#fff' }}>
                    <Plus size={12} />
                  </button>
                </div>
                <div className="font-display text-base w-16 text-right" style={{ color: '#e85d2f' }}>
                  €{fmtPrice(item.price * item.qty)}
                </div>
              </div>
            ))}
          </div>

          {/* 备注 */}
          <div className="mx-6 mb-4">
            <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>NOTE · 备注 (allergie, richieste)</div>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value.slice(0, 150))}
              placeholder="例如: 不要香葱、过敏信息、配送楼层..."
              rows={2}
              className="w-full rounded-xl p-3 text-sm outline-none resize-none"
              style={{ background: '#2a2420', color: '#f5ede0', border: '1px solid #3a2e2a' }}
            />
          </div>

          {/* 支付方式 */}
          <div className="mx-6 mb-4">
            <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>PAGAMENTO · 支付方式</div>
            <div className="space-y-2">
              <button onClick={() => canPayBalance && setPayMethod('balance')}
                      disabled={!canPayBalance}
                      className="w-full rounded-xl p-3 flex items-center justify-between transition-all"
                      style={{
                        background: payMethod === 'balance' ? 'rgba(232,93,47,0.15)' : '#2a2420',
                        border: `1px solid ${payMethod === 'balance' ? '#e85d2f' : '#3a2e2a'}`,
                        opacity: canPayBalance ? 1 : 0.5,
                      }}>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center"
                       style={{ background: payMethod === 'balance' ? '#e85d2f' : '#3a2e2a', color: '#fff' }}>
                    €
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-medium" style={{ color: '#f5ede0' }}>余额支付</div>
                    <div className="text-xs mt-0.5" style={{ color: canPayBalance ? '#8a7a6e' : '#c44a25' }}>
                      可用 €{balance.toFixed(2)}{!canPayBalance && ' · 余额不足'}
                    </div>
                  </div>
                </div>
                <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center"
                     style={{ borderColor: payMethod === 'balance' ? '#e85d2f' : '#3a2e2a' }}>
                  {payMethod === 'balance' && <div className="w-2.5 h-2.5 rounded-full" style={{ background: '#e85d2f' }} />}
                </div>
              </button>

              <button onClick={() => setPayMethod('pickup')}
                      className="w-full rounded-xl p-3 flex items-center justify-between transition-all"
                      style={{
                        background: payMethod === 'pickup' ? 'rgba(232,93,47,0.15)' : '#2a2420',
                        border: `1px solid ${payMethod === 'pickup' ? '#e85d2f' : '#3a2e2a'}`,
                      }}>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center"
                       style={{ background: payMethod === 'pickup' ? '#e85d2f' : '#3a2e2a', color: '#fff' }}>
                    <Store size={16} />
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-medium" style={{ color: '#f5ede0' }}>
                      {orderType === 'delivery' ? '送达付款' : '到店付款'}
                    </div>
                    <div className="text-xs mt-0.5" style={{ color: '#8a7a6e' }}>
                      {orderType === 'delivery' ? '骑手送达时付' : '取餐时支付'}
                    </div>
                  </div>
                </div>
                <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center"
                     style={{ borderColor: payMethod === 'pickup' ? '#e85d2f' : '#3a2e2a' }}>
                  {payMethod === 'pickup' && <div className="w-2.5 h-2.5 rounded-full" style={{ background: '#e85d2f' }} />}
                </div>
              </button>
            </div>
          </div>

          {/* 积分预估 */}
          <div className="mx-6 mb-4 rounded-xl p-3 flex items-center justify-between"
               style={{ background: '#2a2420' }}>
            <div className="flex items-center gap-2 text-xs" style={{ color: '#8a7a6e' }}>
              <Sparkles size={14} style={{ color: '#e85d2f' }} />
              <span>完成订单可获得</span>
            </div>
            <div className="font-display text-lg" style={{ color: '#e85d2f' }}>+{estPoints} 积分</div>
          </div>

          {/* 合计 + 提交 */}
          <div className="fixed bottom-0 left-0 right-0 z-30">
            <div className="max-w-md mx-auto px-4 pb-4 pt-2"
                 style={{ background: 'linear-gradient(180deg, transparent 0%, #1a1614 30%)' }}>
              <div className="rounded-2xl p-4" style={{ background: '#2a2420' }}>
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="text-sm" style={{ color: '#8a7a6e' }}>合计</span>
                    <span className="text-[11px] ml-2" style={{ color: '#5a4a3e' }}>
                      {orderType === 'delivery' ? '🛵 外送' : '🥡 到店取'} · {loc.name}
                    </span>
                  </div>
                  <span className="font-display text-2xl" style={{ color: '#f5ede0' }}>€{fmtPrice(cartTotal)}</span>
                </div>
                <button onClick={submit}
                        disabled={!canSubmit}
                        className="w-full rounded-xl py-3.5 font-medium transition-transform active:scale-[0.98] flex items-center justify-center gap-2"
                        style={{
                          background: canSubmit ? '#e85d2f' : '#3a2e2a',
                          color: canSubmit ? '#fff' : '#5a4a3e',
                        }}>
                  {submitting ? <Loader2 size={18} className="animate-spin" /> :
                   orderType === 'delivery' && address.trim().length < 5 ? '请填写配送地址' :
                   orderType === 'delivery' && addressPicked && distance?.status === 'error' ? '超出配送范围' :
                   payMethod === 'balance' ? `余额支付 €${fmtPrice(cartTotal)}` :
                   '提交订单'}
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}


// ========== 顾客订单列表 ==========
function CustomerOrdersView({ orders, onBack }) {
  return (
    <div className="min-h-screen fade-up pb-8">
      <div className="px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <div>
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>MY ORDERS</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>我的订单</div>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="py-20 text-center">
          <Receipt size={48} strokeWidth={1} className="mx-auto mb-4" style={{ color: '#3a2e2a' }} />
          <div className="text-sm" style={{ color: '#5a4a3e' }}>还没有订单</div>
        </div>
      ) : (
        <div className="px-6 space-y-3">
          {orders.map((o, i) => {
            const st = STATUS_META[o.status];
            return (
              <div key={o.id} className="rounded-2xl p-4 fade-up"
                   style={{ background: '#2a2420', animationDelay: `${i * 40}ms` }}>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="text-xs" style={{ color: '#5a4a3e' }}>订单号 · {o.id.slice(-6).toUpperCase()}</div>
                    <div className="text-xs mt-0.5" style={{ color: '#5a4a3e' }}>
                      {new Date(o.createdAt).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                  <div className="px-3 py-1 rounded-full text-xs font-medium"
                       style={{ background: st.bg, color: st.color }}>
                    {st.label}
                  </div>
                </div>

                {/* 取餐方式 + 店铺 */}
                <div className="mb-3 px-2 py-1.5 rounded flex items-center gap-2 text-xs"
                     style={{ background: '#221c19' }}>
                  <span>{o.orderType === 'delivery' ? '🛵' : '🥡'}</span>
                  <span style={{ color: '#f5ede0' }}>
                    {o.orderType === 'delivery' ? '外送' : '到店取餐'}
                  </span>
                  <span style={{ color: '#5a4a3e' }}>·</span>
                  <span style={{ color: '#8a7a6e' }}>{o.locationName || 'Schio'}</span>
                  {o.orderType === 'delivery' && o.etaMin && (
                    <span className="ml-auto" style={{ color: '#d4a574' }}>~{o.etaMin}min</span>
                  )}
                </div>

                {o.orderType === 'delivery' && o.deliveryAddress && (
                  <div className="mb-3 text-xs px-2 py-1.5 rounded flex items-start gap-2"
                       style={{ background: '#221c19', color: '#8a7a6e' }}>
                    <span>📍</span>
                    <span className="flex-1">{o.deliveryAddress}</span>
                  </div>
                )}

                <div className="space-y-1 mb-3">
                  {o.items.map((it) => (
                    <div key={it.id} className="flex items-center justify-between text-sm">
                      <span style={{ color: '#f5ede0' }}>{it.name} <span style={{ color: '#5a4a3e' }}>×{it.qty}</span></span>
                      <span style={{ color: '#8a7a6e' }}>€{fmtPrice(it.price * it.qty)}</span>
                    </div>
                  ))}
                </div>

                {o.note && (
                  <div className="text-xs mb-3 px-2 py-1.5 rounded" style={{ background: '#221c19', color: '#8a7a6e' }}>
                    备注：{o.note}
                  </div>
                )}

                <div className="flex items-center justify-between pt-3" style={{ borderTop: '1px dashed #3a2e2a' }}>
                  <div className="text-xs" style={{ color: '#8a7a6e' }}>
                    {o.status === 'completed' && o.pointsEarned ? `已获得 ${o.pointsEarned} 积分` : `预计获得 ${Math.floor(o.total)} 积分`}
                  </div>
                  <div className="font-display text-lg" style={{ color: '#e85d2f' }}>€{fmtPrice(o.total)}</div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ========== 员工订单管理 ==========
function EmployeeOrdersView({ orders, onBack, onUpdate, showToast }) {
  const [tab, setTab] = useState('pending');
  const list = Object.values(orders).filter((o) => o.status === tab).sort((a, b) => a.createdAt - b.createdAt);
  const counts = {
    pending: Object.values(orders).filter((o) => o.status === 'pending').length,
    ready: Object.values(orders).filter((o) => o.status === 'ready').length,
    completed: Object.values(orders).filter((o) => o.status === 'completed').length,
  };

  return (
    <div className="min-h-screen fade-up pb-8">
      <div className="px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <div>
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>TAKEOUT QUEUE</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>打包订单</div>
        </div>
      </div>

      <div className="px-6 flex gap-2 mb-4">
        {[['pending', '准备中'], ['ready', '可取餐'], ['completed', '已完成']].map(([k, label]) => (
          <button key={k} onClick={() => setTab(k)}
                  className="flex-1 py-2.5 rounded-xl text-xs transition-all relative"
                  style={{
                    background: tab === k ? '#e85d2f' : '#2a2420',
                    color: tab === k ? '#fff' : '#8a7a6e',
                  }}>
            {label}
            {counts[k] > 0 && (
              <span className="ml-1 font-display">{counts[k]}</span>
            )}
          </button>
        ))}
      </div>

      <div className="px-6 space-y-3">
        {list.length === 0 ? (
          <div className="py-16 text-center text-sm" style={{ color: '#5a4a3e' }}>
            {tab === 'pending' ? '暂无新订单' : tab === 'ready' ? '暂无待取订单' : '暂无已完成订单'}
          </div>
        ) : list.map((o, i) => (
          <div key={o.id} className="rounded-2xl p-4 fade-up"
               style={{ background: '#2a2420', animationDelay: `${i * 40}ms`,
                        border: o.status === 'pending' ? '1px solid #e85d2f' : '1px solid transparent' }}>
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <div className="font-display text-lg" style={{ color: '#f5ede0' }}>{o.customerName}</div>
                  <div className="text-xs" style={{ color: '#5a4a3e' }}>{formatPhone(o.customerPhone)}</div>
                </div>
                <div className="text-xs mt-0.5 flex items-center gap-1" style={{ color: '#8a7a6e' }}>
                  <Clock size={11} />
                  {new Date(o.createdAt).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}
                  <span className="mx-1">·</span>
                  #{o.id.slice(-6).toUpperCase()}
                </div>
              </div>
              <div className="text-right">
                <div className="font-display text-xl" style={{ color: '#e85d2f' }}>€{fmtPrice(o.total)}</div>
                {o.paid && (
                  <div className="text-[10px] mt-1 px-2 py-0.5 rounded-full inline-block"
                       style={{ background: 'rgba(95,185,80,0.15)', color: '#5fb950' }}>
                    已付款
                  </div>
                )}
              </div>
            </div>

            {/* 订单类型 + 店铺 + 配送信息 */}
            <div className="mb-3 px-3 py-2 rounded-lg flex items-center gap-2 text-xs"
                 style={{
                   background: o.orderType === 'delivery' ? 'rgba(212,165,116,0.15)' : 'rgba(232,93,47,0.10)',
                   border: `1px solid ${o.orderType === 'delivery' ? '#d4a574' : '#3a2e2a'}`,
                 }}>
              <span className="text-base">{o.orderType === 'delivery' ? '🛵' : '🥡'}</span>
              <div className="flex-1">
                <div className="font-medium" style={{ color: '#f5ede0' }}>
                  {o.orderType === 'delivery' ? 'DELIVERY · 外送' : 'TAKE AWAY · 到店取'}
                </div>
                <div className="text-[10px] mt-0.5" style={{ color: '#8a7a6e' }}>
                  {o.locationName ? `Fude Ramen · ${o.locationName}` : 'Schio'}
                  {o.orderType === 'delivery' && o.distanceKm != null && (
                    <> · {o.distanceKm.toFixed(1)} km · ~{o.etaMin} min</>
                  )}
                </div>
              </div>
            </div>

            {o.orderType === 'delivery' && o.deliveryAddress && (
              <div className="mb-3 px-3 py-2 rounded-lg flex items-start gap-2 text-xs"
                   style={{ background: '#221c19', color: '#d4a574' }}>
                <span className="font-bold">📍 地址</span>
                <span className="flex-1" style={{ color: '#f5ede0' }}>{o.deliveryAddress}</span>
              </div>
            )}

            <div className="space-y-1 mb-3 pb-3" style={{ borderBottom: '1px dashed #3a2e2a' }}>
              {o.items.map((it) => (
                <div key={it.id} className="flex items-center justify-between text-sm">
                  <span style={{ color: '#f5ede0' }}>
                    {it.name} <span style={{ color: '#e85d2f' }}>×{it.qty}</span>
                  </span>
                  <span className="text-xs" style={{ color: '#8a7a6e' }}>€{fmtPrice(it.price * it.qty)}</span>
                </div>
              ))}
            </div>

            {o.note && (
              <div className="text-xs mb-3 px-3 py-2 rounded flex gap-2"
                   style={{ background: 'rgba(232,93,47,0.1)', color: '#e85d2f' }}>
                <span className="font-bold">备注</span>
                <span>{o.note}</span>
              </div>
            )}

            {o.status === 'pending' && (
              <button onClick={async () => { await onUpdate(o.id, 'ready'); showToast('已标记为可取餐'); }}
                      className="w-full rounded-xl py-2.5 text-sm font-medium transition-transform active:scale-[0.98]"
                      style={{ background: '#d4a574', color: '#1a1614' }}>
                <Check size={16} className="inline mr-1" /> 标记为可取餐
              </button>
            )}
            {o.status === 'ready' && (
              <button onClick={async () => { await onUpdate(o.id, 'completed'); showToast(`订单完成！+${Math.floor(o.total)} 积分给顾客`); }}
                      className="w-full rounded-xl py-2.5 text-sm font-medium transition-transform active:scale-[0.98]"
                      style={{ background: '#e85d2f', color: '#fff' }}>
                <Check size={16} className="inline mr-1" /> 完成订单 · 发放 {Math.floor(o.total)} 积分
              </button>
            )}
            {o.status === 'completed' && o.pointsEarned !== undefined && (
              <div className="text-xs text-center" style={{ color: '#8a7a6e' }}>
                已发放 <span style={{ color: '#e85d2f' }}>{o.pointsEarned}</span> 积分
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ========== 员工菜品照片管理 ==========
function EmployeeMenuView({ menuOverrides, onUpdate, onBack, showToast }) {
  const [tab, setTab] = useState('ramen');
  const [editingItem, setEditingItem] = useState(null);
  const [uploading, setUploading] = useState(false);

  const items = MENU[tab] || [];

  // 压缩图片为 dataURL (max 1024px, 0.85 质量, ~150KB)
  const compressImage = (file) => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new window.Image();
      img.onload = () => {
        const maxDim = 1024;
        let w = img.width, h = img.height;
        if (w > maxDim || h > maxDim) {
          if (w > h) { h = (h / w) * maxDim; w = maxDim; }
          else { w = (w / h) * maxDim; h = maxDim; }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

  const handleUpload = async (item, file) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('请选择图片文件');
      return;
    }
    setUploading(true);
    try {
      const dataUrl = await compressImage(file);
      await onUpdate(item.id, { image: dataUrl });
      showToast(`已上传: ${item.name}`);
      setEditingItem(null);
    } catch (e) {
      showToast('上传失败');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (item) => {
    if (!confirm(`删除 "${item.name}" 的照片?`)) return;
    await onUpdate(item.id, null);
    showToast('已删除照片');
    setEditingItem(null);
  };

  const withCount = MENU_TABS.reduce((acc, [id]) => {
    const cat = MENU[id] || [];
    acc[id] = cat.filter((it) => menuOverrides[it.id]?.image).length;
    return acc;
  }, {});
  const totalWith = Object.values(menuOverrides).filter((o) => o.image).length;
  const totalItems = Object.values(MENU).flat().length;

  return (
    <div className="min-h-screen fade-up pb-8">
      <div className="px-6 pt-8 pb-3 flex items-center gap-3">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <div className="flex-1">
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>MENU PHOTOS</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>菜品照片管理</div>
        </div>
      </div>

      {/* 总览进度 */}
      <div className="mx-6 mb-4 rounded-xl p-3 flex items-center gap-3"
           style={{ background: 'rgba(212,165,116,0.1)', border: '1px solid rgba(212,165,116,0.3)' }}>
        <Image size={20} style={{ color: '#d4a574' }} />
        <div className="flex-1">
          <div className="text-xs" style={{ color: '#8a7a6e' }}>覆盖率</div>
          <div className="text-sm font-medium" style={{ color: '#f5ede0' }}>
            <span style={{ color: '#d4a574' }}>{totalWith}</span> / {totalItems} 道菜已有照片
          </div>
        </div>
        <div className="text-2xl font-display" style={{ color: '#d4a574' }}>
          {Math.round((totalWith / totalItems) * 100)}%
        </div>
      </div>

      {/* 类别 tab */}
      <div className="px-6 flex gap-2 mb-4 overflow-x-auto" style={{ scrollbarWidth: 'none' }}>
        {MENU_TABS.map(([id, cn, jp, emoji]) => {
          const total = MENU[id]?.length || 0;
          const done = withCount[id] || 0;
          return (
            <button key={id} onClick={() => setTab(id)}
                    className="flex-shrink-0 px-3 py-2 rounded-xl transition-all relative"
                    style={{
                      background: tab === id ? '#e85d2f' : '#2a2420',
                      color: tab === id ? '#fff' : '#8a7a6e',
                      minWidth: 72,
                    }}>
              <div className="text-base leading-none mb-1">{emoji}</div>
              <div className="text-xs font-medium whitespace-nowrap">{cn}</div>
              <div className="text-[10px] mt-0.5" style={{ color: tab === id ? 'rgba(255,255,255,0.7)' : '#5a4a3e' }}>
                {done}/{total}
              </div>
            </button>
          );
        })}
      </div>

      {/* 菜品列表 - 网格 */}
      <div className="px-6 grid grid-cols-2 gap-3">
        {items.map((item, i) => {
          const override = menuOverrides[item.id] || {};
          const img = override.image;
          return (
            <button key={item.id}
                    onClick={() => setEditingItem(item)}
                    className="rounded-2xl overflow-hidden text-left transition-transform active:scale-[0.97] fade-up flex flex-col"
                    style={{
                      background: '#2a2420',
                      animationDelay: `${Math.min(i * 30, 300)}ms`,
                      border: img ? '1px solid #5fb95040' : '1px solid #3a2e2a',
                    }}>
              <div className="relative" style={{ aspectRatio: '1/1' }}>
                {img ? (
                  <img src={img} alt={item.name} className="absolute inset-0 w-full h-full object-cover" />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center"
                       style={{
                         background: `radial-gradient(circle at 30% 40%, rgba(232,93,47,0.3), transparent 60%),
                                      linear-gradient(135deg, #2a1810 0%, #1a1614 100%)`,
                       }}>
                    <span className="text-5xl">{item.emoji || '🍴'}</span>
                  </div>
                )}
                {img && (
                  <div className="absolute top-1.5 right-1.5 w-5 h-5 rounded-full flex items-center justify-center"
                       style={{ background: '#5fb950', color: '#fff' }}>
                    <Check size={12} strokeWidth={3} />
                  </div>
                )}
              </div>
              <div className="p-2.5 flex-1">
                <div className="text-xs font-medium leading-tight" style={{ color: '#f5ede0' }}>
                  {item.name}
                </div>
                <div className="text-[10px] mt-1" style={{ color: '#e85d2f' }}>€{fmtPrice(item.price)}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* 编辑弹层 */}
      {editingItem && (
        <MenuItemEditor
          item={editingItem}
          override={menuOverrides[editingItem.id] || {}}
          uploading={uploading}
          onUpload={(file) => handleUpload(editingItem, file)}
          onDelete={() => handleDelete(editingItem)}
          onClose={() => setEditingItem(null)}
        />
      )}
    </div>
  );
}

// 单菜品编辑弹层
function MenuItemEditor({ item, override, uploading, onUpload, onDelete, onClose }) {
  const cameraRef = useRef(null);
  const galleryRef = useRef(null);
  const img = override.image;

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = prev;
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-end"
         style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(6px)' }}
         onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="w-full max-w-md mx-auto rounded-t-3xl overflow-hidden flex flex-col"
           style={{
             maxHeight: '88vh',
             background: '#1a1614',
             animation: 'slideUpSheet 0.32s cubic-bezier(0.22,0.61,0.36,1)',
             border: '1px solid #2a2420',
           }}>
        {/* 当前预览 */}
        <div className="relative" style={{ aspectRatio: '4/3' }}>
          {img ? (
            <img src={img} alt={item.name} className="absolute inset-0 w-full h-full object-cover" />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center"
                 style={{
                   background: `radial-gradient(circle at 30% 40%, rgba(232,93,47,0.4), transparent 60%),
                                linear-gradient(135deg, #2a1810 0%, #1a1614 100%)`,
                 }}>
              <span className="text-9xl">{item.emoji || '🍴'}</span>
            </div>
          )}
          <button onClick={onClose}
                  className="absolute top-4 right-4 w-9 h-9 rounded-full flex items-center justify-center"
                  style={{ background: 'rgba(20,15,12,0.7)', color: '#fff', backdropFilter: 'blur(8px)' }}>
            <X size={20} />
          </button>
          {uploading && (
            <div className="absolute inset-0 flex items-center justify-center"
                 style={{ background: 'rgba(0,0,0,0.6)' }}>
              <Loader2 size={32} className="animate-spin" style={{ color: '#e85d2f' }} />
            </div>
          )}
        </div>

        <div className="p-6">
          <div className="font-display text-xl mb-1" style={{ color: '#f5ede0' }}>{item.name}</div>
          <div className="text-sm mb-5" style={{ color: '#8a7a6e' }}>{item.desc}</div>

          <div className="text-xs tracking-[0.3em] mb-3" style={{ color: '#8a7a6e' }}>
            {img ? '更换照片' : '上传照片'}
          </div>

          {/* 隐藏的文件输入 */}
          <input
            ref={cameraRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => onUpload(e.target.files?.[0])}
          />
          <input
            ref={galleryRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => onUpload(e.target.files?.[0])}
          />

          <div className="grid grid-cols-2 gap-2 mb-3">
            <button onClick={() => cameraRef.current?.click()}
                    disabled={uploading}
                    className="rounded-xl py-3.5 flex items-center justify-center gap-2 transition-transform active:scale-[0.98]"
                    style={{ background: '#e85d2f', color: '#fff', opacity: uploading ? 0.5 : 1 }}>
              <Camera size={18} />
              <span className="text-sm font-medium">拍照</span>
            </button>
            <button onClick={() => galleryRef.current?.click()}
                    disabled={uploading}
                    className="rounded-xl py-3.5 flex items-center justify-center gap-2 transition-transform active:scale-[0.98]"
                    style={{ background: '#3a2e2a', color: '#f5ede0', opacity: uploading ? 0.5 : 1 }}>
              <Upload size={18} />
              <span className="text-sm font-medium">从相册选</span>
            </button>
          </div>

          {img && (
            <button onClick={onDelete}
                    disabled={uploading}
                    className="w-full rounded-xl py-3 flex items-center justify-center gap-2 transition-transform active:scale-[0.98]"
                    style={{ background: 'transparent', color: '#c44a25', border: '1px solid rgba(196,74,37,0.5)' }}>
              <Trash2 size={16} />
              <span className="text-sm">删除照片(恢复默认)</span>
            </button>
          )}

          <div className="text-[11px] mt-4 text-center" style={{ color: '#5a4a3e' }}>
            照片会自动压缩到 1024px · JPEG 85% 质量<br />
            {img ? '点击替换或删除' : '建议拍摄菜品俯视图,光线充足'}
          </div>
        </div>
      </div>
    </div>
  );
}

// ========== 充值页面 ==========
function RechargeView({ customer, onBack, onRecharge }) {
  const [selectedTier, setSelectedTier] = useState(0);
  const [customAmount, setCustomAmount] = useState('');
  const [useCustom, setUseCustom] = useState(false);
  const [stripeOpen, setStripeOpen] = useState(false);

  const tier = !useCustom ? RECHARGE_TIERS[selectedTier] : null;
  const customNum = parseInt(customAmount, 10) || 0;
  const finalAmount = useCustom ? customNum : (tier?.amount || 0);
  const finalBonus = useCustom ? 0 : (tier?.bonus || 0);
  const totalCredit = finalAmount + finalBonus;
  const canSubmit = finalAmount >= 10;

  const balance = customer.balance || 0;
  const rechargeHistory = (customer.history || []).filter((h) => h.balanceDelta).slice(0, 5);

  return (
    <div className="min-h-screen fade-up pb-40">
      <div className="px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <div>
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>TOP UP</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>账户充值</div>
        </div>
      </div>

      {/* 当前余额 */}
      <div className="mx-6 rounded-3xl p-5 mb-6 relative overflow-hidden"
           style={{ background: 'linear-gradient(135deg, #2a2420 0%, #3a2e2a 100%)', border: '1px solid #3a2e2a' }}>
        <div className="text-xs tracking-[0.3em] mb-1" style={{ color: '#8a7a6e' }}>CURRENT BALANCE</div>
        <div className="flex items-baseline gap-2">
          <div className="font-display text-4xl" style={{ color: '#f5ede0' }}>€{balance.toFixed(2)}</div>
          <div className="text-xs" style={{ color: '#5a4a3e' }}>当前余额</div>
        </div>
      </div>

      {/* 套餐选择 */}
      <div className="px-6 mb-4">
        <div className="text-xs tracking-[0.3em] mb-3" style={{ color: '#8a7a6e' }}>SELECT AMOUNT · 选择金额</div>
        <div className="grid grid-cols-2 gap-3">
          {RECHARGE_TIERS.map((t, i) => (
            <button key={i} onClick={() => { setSelectedTier(i); setUseCustom(false); }}
                    className="rounded-2xl p-4 text-left relative transition-all"
                    style={{
                      background: !useCustom && selectedTier === i ? '#e85d2f' : '#2a2420',
                      color: !useCustom && selectedTier === i ? '#fff' : '#f5ede0',
                      border: `1px solid ${!useCustom && selectedTier === i ? '#e85d2f' : '#3a2e2a'}`,
                    }}>
              {t.bonus > 0 && (
                <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full text-[10px] font-bold"
                     style={{
                       background: !useCustom && selectedTier === i ? '#fff' : '#e85d2f',
                       color: !useCustom && selectedTier === i ? '#e85d2f' : '#fff',
                     }}>
                  {t.tag}
                </div>
              )}
              <div className="text-xs opacity-70 mb-1">充值</div>
              <div className="font-display text-3xl">€{t.amount}</div>
              {t.bonus > 0 && (
                <div className="text-xs mt-1 opacity-80">
                  到账 €{t.amount + t.bonus}
                </div>
              )}
              {t.bonus === 0 && (
                <div className="text-xs mt-1 opacity-50">无赠送</div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* 自定义金额 */}
      <div className="px-6 mb-6">
        <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>CUSTOM · 自定义</div>
        <div className="rounded-2xl p-4 flex items-center gap-3 transition-all"
             style={{
               background: useCustom ? 'rgba(232,93,47,0.15)' : '#2a2420',
               border: `1px solid ${useCustom ? '#e85d2f' : '#3a2e2a'}`,
             }}>
          <span className="text-2xl font-display" style={{ color: useCustom ? '#e85d2f' : '#5a4a3e' }}>€</span>
          <input
            type="tel"
            value={customAmount}
            onChange={(e) => {
              const v = e.target.value.replace(/\D/g, '').slice(0, 5);
              setCustomAmount(v);
              setUseCustom(true);
            }}
            onFocus={() => setUseCustom(true)}
            placeholder="输入金额 (最低 €10)"
            className="flex-1 bg-transparent outline-none text-xl"
            style={{ color: '#f5ede0' }}
          />
          {useCustom && customAmount && (
            <button onClick={() => { setCustomAmount(''); setUseCustom(false); }}
                    style={{ color: '#5a4a3e' }}>
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* 充值记录 */}
      {rechargeHistory.length > 0 && (
        <div className="px-6 mb-6">
          <div className="text-xs tracking-[0.3em] mb-2" style={{ color: '#8a7a6e' }}>RECENT · 最近记录</div>
          <div className="space-y-1.5">
            {rechargeHistory.map((h, i) => (
              <div key={i} className="flex items-center justify-between py-2.5 px-3 rounded-xl text-sm"
                   style={{ background: '#221c19' }}>
                <div>
                  <div style={{ color: '#f5ede0' }}>{h.text}</div>
                  <div className="text-xs mt-0.5" style={{ color: '#5a4a3e' }}>
                    {new Date(h.t).toLocaleString('zh-CN', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
                <div className="font-display" style={{ color: h.balanceDelta > 0 ? '#e85d2f' : '#8a7a6e' }}>
                  {h.balanceDelta > 0 ? '+' : ''}€{Math.abs(h.balanceDelta).toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 条款说明 */}
      <div className="px-6 mb-4">
        <div className="text-[11px] leading-relaxed" style={{ color: '#5a4a3e' }}>
          · 充值金额可用于店内消费及打包外带订单<br />
          · 赠送金额仅可用于消费，不可提现<br />
          · 一经充值不可退款，请确认后操作
        </div>
      </div>

      {/* 底部确认 */}
      <div className="fixed bottom-0 left-0 right-0 z-30">
        <div className="max-w-md mx-auto px-4 pb-4 pt-2"
             style={{ background: 'linear-gradient(180deg, transparent 0%, #1a1614 30%)' }}>
          <div className="rounded-2xl p-4" style={{ background: '#2a2420' }}>
            {canSubmit ? (
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm" style={{ color: '#8a7a6e' }}>
                  支付 €{finalAmount} {finalBonus > 0 && <span style={{ color: '#e85d2f' }}>· 到账 €{totalCredit}</span>}
                </span>
                <span className="font-display text-xl" style={{ color: '#f5ede0' }}>€{finalAmount}</span>
              </div>
            ) : (
              <div className="text-center text-xs mb-3" style={{ color: '#5a4a3e' }}>
                请选择或输入充值金额（最低 €10）
              </div>
            )}
            <button disabled={!canSubmit}
                    onClick={() => setStripeOpen(true)}
                    className="w-full rounded-xl py-3.5 font-medium transition-transform active:scale-[0.98] flex items-center justify-center gap-2"
                    style={{
                      background: canSubmit ? '#635bff' : '#3a2e2a',
                      color: canSubmit ? '#fff' : '#5a4a3e',
                    }}>
              {canSubmit ? (
                <>
                  <Lock size={14} />
                  使用 Stripe 支付 €{finalAmount}
                </>
              ) : '请选择金额'}
            </button>
          </div>
        </div>
      </div>

      {/* Stripe 支付弹层 */}
      {stripeOpen && (
        <StripeCheckout
          amount={finalAmount}
          bonus={finalBonus}
          customerName={customer.name}
          onCancel={() => setStripeOpen(false)}
          onSuccess={async () => {
            await onRecharge(finalAmount, finalBonus);
            setStripeOpen(false);
          }}
        />
      )}
    </div>
  );
}

// ========== Stripe 支付弹层 ==========
//
// ⚠️ 这是【演示界面】，没有真实扣款。
//
// 接入真实 Stripe 的步骤（需要后端）：
//   1. 后端: 安装 stripe SDK，用 sk_test_xxx 创建 PaymentIntent
//        const intent = await stripe.paymentIntents.create({
//          amount: amount * 100,     // 分为单位
//          currency: 'cny',           // 意大利店改 'eur'
//          metadata: { customerPhone, bonus }
//        });
//        return { clientSecret: intent.client_secret };
//
//   2. 前端: 引入 @stripe/stripe-js, @stripe/react-stripe-js
//        const stripe = useStripe(); const elements = useElements();
//        const { error } = await stripe.confirmCardPayment(clientSecret, {
//          payment_method: { card: elements.getElement(CardElement) }
//        });
//
//   3. Webhook: 监听 payment_intent.succeeded 事件，在数据库给账户加余额
//
function StripeCheckout({ amount, bonus, customerName, onSuccess, onCancel }) {
  const [step, setStep] = useState('form'); // form | processing | success
  const [email, setEmail] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [name, setName] = useState(customerName || '');
  const [postal, setPostal] = useState('');

  const totalCredit = amount + bonus;

  const formatCardNumber = (v) => {
    const digits = v.replace(/\D/g, '').slice(0, 16);
    return digits.replace(/(\d{4})(?=\d)/g, '$1 ');
  };
  const formatExpiry = (v) => {
    const digits = v.replace(/\D/g, '').slice(0, 4);
    if (digits.length >= 3) return digits.slice(0, 2) + ' / ' + digits.slice(2);
    return digits;
  };

  const cardDigits = cardNumber.replace(/\s/g, '');
  const cardBrand =
    cardDigits.startsWith('4') ? 'Visa' :
    cardDigits.match(/^5[1-5]/) || cardDigits.match(/^2[2-7]/) ? 'Mastercard' :
    cardDigits.match(/^3[47]/) ? 'Amex' :
    cardDigits.startsWith('6') ? 'Discover' : '';

  const canPay = email.includes('@') &&
                 cardDigits.length >= 13 &&
                 expiry.replace(/\D/g, '').length === 4 &&
                 cvc.length >= 3 &&
                 name.trim();

  const pay = async () => {
    setStep('processing');
    // === 真实接入点：把下面这行替换为 stripe.confirmCardPayment(clientSecret, ...) ===
    await new Promise((r) => setTimeout(r, 1800));
    setStep('success');
    setTimeout(() => onSuccess(), 1400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center"
         style={{ background: 'rgba(15, 23, 42, 0.7)', backdropFilter: 'blur(10px)' }}
         onClick={(e) => { if (e.target === e.currentTarget && step === 'form') onCancel(); }}>
      <style>{`
        @keyframes slideUpModal { from { transform: translateY(100%); } to { transform: translateY(0); } }
        @keyframes spin { from { transform: rotate(0); } to { transform: rotate(360deg); } }
        @keyframes scaleInPop { 0% { transform: scale(0); opacity: 0; } 60% { transform: scale(1.15); } 100% { transform: scale(1); opacity: 1; } }
        .slide-up-modal { animation: slideUpModal 0.35s cubic-bezier(0.16, 1, 0.3, 1); }
        .spin-anim { animation: spin 0.8s linear infinite; }
        .pop-in { animation: scaleInPop 0.5s cubic-bezier(0.34, 1.56, 0.64, 1); }
      `}</style>

      <div className="w-full max-w-md slide-up-modal rounded-t-3xl"
           style={{ background: '#fff', maxHeight: '92vh', overflowY: 'auto',
                    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>

        {/* Test mode banner */}
        <div className="px-4 py-1.5 text-center text-[11px] font-medium tracking-wide"
             style={{ background: '#ffc043', color: '#0a2540' }}>
          TEST MODE · 演示模式 (不会真实扣款)
        </div>

        {step === 'form' && (
          <div className="p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-5">
              <div>
                <div className="text-xs font-medium" style={{ color: '#697386' }}>Fude Ramen · Take Away</div>
                <div className="font-bold text-2xl mt-1" style={{ color: '#0a2540' }}>€{amount.toFixed(2)}</div>
                {bonus > 0 && (
                  <div className="text-xs mt-0.5" style={{ color: '#635bff' }}>含赠送 €{bonus}，到账 €{totalCredit}</div>
                )}
              </div>
              <button onClick={onCancel} className="p-1.5 rounded-full" style={{ color: '#697386' }}>
                <X size={20} />
              </button>
            </div>

            {/* 提示测试卡号 */}
            <div className="mb-5 p-3 rounded-lg text-[11px] flex items-start gap-2"
                 style={{ background: '#f6f9fc', color: '#425466' }}>
              <Lock size={12} className="mt-0.5 flex-shrink-0" />
              <div>
                测试卡号: <span className="font-mono font-semibold">4242 4242 4242 4242</span>
                <br />到期日填未来任意日期 · CVC 填任意 3 位
              </div>
            </div>

            {/* 邮箱 */}
            <label className="block text-xs font-medium mb-1.5" style={{ color: '#0a2540' }}>邮箱</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                   placeholder="you@example.com"
                   className="w-full px-3 py-2.5 rounded-lg outline-none text-sm transition-all mb-4"
                   style={{ border: '1px solid #e3e8ee', color: '#0a2540',
                            boxShadow: email ? '0 0 0 3px rgba(99,91,255,0.1)' : 'none' }} />

            {/* 卡号 */}
            <label className="block text-xs font-medium mb-1.5" style={{ color: '#0a2540' }}>卡片信息</label>
            <div className="rounded-lg overflow-hidden mb-4" style={{ border: '1px solid #e3e8ee' }}>
              <div className="relative">
                <input
                  value={formatCardNumber(cardNumber)}
                  onChange={(e) => setCardNumber(e.target.value)}
                  placeholder="1234 1234 1234 1234"
                  className="w-full px-3 py-2.5 outline-none text-sm font-mono"
                  style={{ color: '#0a2540' }}
                  inputMode="numeric"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  {cardBrand ? (
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded"
                          style={{ background: '#0a2540', color: '#fff' }}>
                      {cardBrand}
                    </span>
                  ) : (
                    <CreditCard size={18} style={{ color: '#aab7c4' }} />
                  )}
                </div>
              </div>
              <div className="flex" style={{ borderTop: '1px solid #e3e8ee' }}>
                <input value={formatExpiry(expiry)} onChange={(e) => setExpiry(e.target.value)}
                       placeholder="MM / YY"
                       className="flex-1 px-3 py-2.5 outline-none text-sm font-mono"
                       style={{ color: '#0a2540' }}
                       inputMode="numeric" />
                <input value={cvc} onChange={(e) => setCvc(e.target.value.replace(/\D/g, '').slice(0, 4))}
                       placeholder="CVC"
                       className="flex-1 px-3 py-2.5 outline-none text-sm font-mono"
                       style={{ color: '#0a2540', borderLeft: '1px solid #e3e8ee' }}
                       inputMode="numeric" />
              </div>
            </div>

            {/* 姓名 */}
            <label className="block text-xs font-medium mb-1.5" style={{ color: '#0a2540' }}>持卡人姓名</label>
            <input value={name} onChange={(e) => setName(e.target.value)}
                   placeholder="Marco Rossi"
                   className="w-full px-3 py-2.5 rounded-lg outline-none text-sm mb-4"
                   style={{ border: '1px solid #e3e8ee', color: '#0a2540' }} />

            {/* 国家/邮编 */}
            <label className="block text-xs font-medium mb-1.5" style={{ color: '#0a2540' }}>账单邮编（可选）</label>
            <input value={postal} onChange={(e) => setPostal(e.target.value)}
                   placeholder="20121"
                   className="w-full px-3 py-2.5 rounded-lg outline-none text-sm mb-6"
                   style={{ border: '1px solid #e3e8ee', color: '#0a2540' }} />

            {/* Pay 按钮 */}
            <button onClick={pay} disabled={!canPay}
                    className="w-full rounded-lg py-3 font-medium text-sm transition-all flex items-center justify-center gap-2"
                    style={{
                      background: canPay ? '#635bff' : '#aab7c4',
                      color: '#fff',
                      boxShadow: canPay ? '0 4px 6px rgba(50,50,93,0.11), 0 1px 3px rgba(0,0,0,0.08)' : 'none',
                    }}>
              <Lock size={14} />
              支付 €{amount.toFixed(2)}
            </button>

            {/* Powered by Stripe */}
            <div className="mt-5 flex items-center justify-center gap-1.5 text-[11px]" style={{ color: '#697386' }}>
              <Lock size={10} />
              <span>Powered by</span>
              <span className="font-bold tracking-tight" style={{ color: '#635bff' }}>stripe</span>
              <span>· 银行级 256 位加密</span>
            </div>
          </div>
        )}

        {step === 'processing' && (
          <div className="py-20 px-6 text-center">
            <Loader2 size={48} className="spin-anim mx-auto mb-4" style={{ color: '#635bff' }} />
            <div className="font-medium text-lg mb-1" style={{ color: '#0a2540' }}>正在处理付款</div>
            <div className="text-sm" style={{ color: '#697386' }}>请勿关闭页面…</div>
            <div className="mt-6 text-[11px]" style={{ color: '#aab7c4' }}>
              通过 Stripe 安全网关处理 · 银行验证中
            </div>
          </div>
        )}

        {step === 'success' && (
          <div className="py-16 px-6 text-center">
            <div className="pop-in mx-auto mb-5 w-16 h-16 rounded-full flex items-center justify-center"
                 style={{ background: '#00d924' }}>
              <CheckCircle2 size={36} strokeWidth={3} style={{ color: '#fff' }} />
            </div>
            <div className="font-bold text-2xl mb-1" style={{ color: '#0a2540' }}>支付成功</div>
            <div className="text-sm mb-6" style={{ color: '#697386' }}>
              €{totalCredit.toFixed(2)} 已存入您的账户
            </div>
            <div className="inline-block px-4 py-2 rounded-lg text-xs"
                 style={{ background: '#f6f9fc', color: '#425466' }}>
              交易号 · TX_{Date.now().toString(36).toUpperCase()}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ========== VIP 等级详情页 ==========
function VipView({ customer, onBack }) {
  const { t } = useT();
  const totalSpent = customer.totalSpent || 0;
  const vip = getVipLevel(totalSpent);
  const nextVip = getNextVip(vip.level);
  const vipProgress = nextVip ? Math.min(1, (totalSpent - vip.minSpent) / (nextVip.minSpent - vip.minSpent)) : 1;
  const vipName = t(`vip.lv${vip.level}.name`);
  const vipPerks = t(`vip.lv${vip.level}.perks`).split('|');
  const nextName = nextVip ? t(`vip.lv${nextVip.level}.name`) : '';

  return (
    <div className="min-h-screen fade-up pb-8">
      <div className="px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <div>
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>{t('vip.label')}</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>{t('vip.title')}</div>
        </div>
      </div>

      {/* 当前等级大卡 */}
      <div className="mx-6 mb-6 rounded-3xl p-6 relative overflow-hidden"
           style={{
             background: `linear-gradient(135deg, ${vip.color}30 0%, ${vip.color}10 50%, #1a1614 100%)`,
             border: `1px solid ${vip.color}50`,
           }}>
        <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full opacity-20"
             style={{ background: vip.color }} />
        <div className="absolute -right-20 -bottom-20 w-56 h-56 rounded-full opacity-10"
             style={{ background: vip.color }} />

        <div className="relative">
          <div className="text-xs tracking-[0.3em] mb-2" style={{ color: vip.color }}>
            {t('vip.current')}
          </div>
          <div className="flex items-baseline gap-3 mb-1">
            <span className="text-6xl">{vip.emoji}</span>
            <div>
              <div className="font-display text-3xl" style={{ color: '#f5ede0' }}>V{vip.level}</div>
              <div className="text-sm" style={{ color: vip.color }}>{vip.it}</div>
            </div>
          </div>
          <div className="font-display text-xl mt-2" style={{ color: '#f5ede0' }}>{vipName}</div>

          {/* 累计消费 */}
          <div className="mt-5 flex items-center gap-4 text-sm">
            <div>
              <div className="text-[10px] tracking-widest" style={{ color: '#8a7a6e' }}>{t('vip.totalSpent').toUpperCase()}</div>
              <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>€{totalSpent.toFixed(0)}</div>
            </div>
            <div className="w-px h-10" style={{ background: 'rgba(255,255,255,0.15)' }} />
            <div>
              <div className="text-[10px] tracking-widest" style={{ color: '#8a7a6e' }}>{t('vip.pointsBalance')}</div>
              <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>{customer.points}</div>
            </div>
          </div>

          {/* 进度条 */}
          {nextVip ? (
            <div className="mt-5">
              <div className="flex items-center justify-between text-xs mb-2">
                <span style={{ color: '#8a7a6e' }}>{t('vip.toNextLong', { emoji: nextVip.emoji, level: nextVip.level, name: nextName })}</span>
                <span className="font-display" style={{ color: nextVip.color }}>
                  €{(nextVip.minSpent - totalSpent).toFixed(0)}
                </span>
              </div>
              <div className="h-2.5 rounded-full overflow-hidden"
                   style={{ background: 'rgba(255,255,255,0.08)' }}>
                <div className="h-full rounded-full transition-all"
                     style={{
                       width: `${vipProgress * 100}%`,
                       background: `linear-gradient(90deg, ${vip.color}, ${nextVip.color})`,
                       boxShadow: `0 0 12px ${nextVip.color}80`,
                     }} />
              </div>
              <div className="text-[11px] mt-1.5 text-center" style={{ color: '#5a4a3e' }}>
                {t('vip.progressNote', { p: Math.round(vipProgress * 100) })}
              </div>
            </div>
          ) : (
            <div className="mt-5 rounded-xl px-3 py-2.5 text-xs text-center"
                 style={{ background: `${vip.color}25`, color: vip.color, border: `1px solid ${vip.color}` }}>
              {t('vip.maxLevel')}
            </div>
          )}
        </div>
      </div>

      {/* 当前等级权益 */}
      <div className="mx-6 mb-6">
        <div className="text-xs tracking-[0.3em] mb-3" style={{ color: '#8a7a6e' }}>{t('vip.benefits')}</div>
        <div className="rounded-2xl p-4 space-y-2" style={{ background: '#2a2420', border: `1px solid ${vip.color}40` }}>
          {vipPerks.map((p, i) => (
            <div key={i} className="flex items-start gap-2.5 text-sm" style={{ color: '#f5ede0' }}>
              <CheckCircle2 size={16} style={{ color: vip.color, flexShrink: 0, marginTop: 2 }} />
              <span>{p}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 所有等级一览 */}
      <div className="mx-6">
        <div className="text-xs tracking-[0.3em] mb-3" style={{ color: '#8a7a6e' }}>{t('vip.allLevels')}</div>
        <div className="space-y-2.5">
          {VIP_LEVELS.map((lv) => {
            const isCurrent = lv.level === vip.level;
            const isUnlocked = totalSpent >= lv.minSpent;
            const lvName = t(`vip.lv${lv.level}.name`);
            const lvPerks = t(`vip.lv${lv.level}.perks`).split('|');
            return (
              <div key={lv.level} className="rounded-2xl overflow-hidden transition-all"
                   style={{
                     background: isCurrent ? `${lv.color}15` : '#2a2420',
                     border: `1px solid ${isCurrent ? lv.color : '#3a2e2a'}`,
                     opacity: isUnlocked ? 1 : 0.55,
                   }}>
                <div className="p-4 flex items-start gap-3">
                  <div className="text-3xl">{lv.emoji}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-xs tracking-widest font-medium" style={{ color: lv.color }}>
                        V{lv.level} · {lv.it.toUpperCase()}
                      </span>
                      {isCurrent && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full font-bold"
                              style={{ background: lv.color, color: '#1a1614' }}>
                          {t('common.current')}
                        </span>
                      )}
                      {isUnlocked && !isCurrent && (
                        <CheckCircle2 size={12} style={{ color: lv.color }} />
                      )}
                    </div>
                    <div className="font-display text-base" style={{ color: '#f5ede0' }}>{lvName}</div>
                    <div className="text-[11px] mt-0.5" style={{ color: '#8a7a6e' }}>
                      {t('vip.thisLevel')} €{lv.minSpent}{lv.level < 5 ? '+' : '+'}
                    </div>
                  </div>
                </div>
                <div className="px-4 pb-4 pt-1 space-y-1.5"
                     style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
                  {lvPerks.map((p, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs" style={{ color: isUnlocked ? '#f5ede0' : '#5a4a3e' }}>
                      <span style={{ color: lv.color }}>·</span>
                      <span>{p}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 规则说明 */}
      <div className="mx-6 mt-6 px-4 py-3 rounded-xl text-[11px] leading-relaxed"
           style={{ background: '#221c19', color: '#8a7a6e' }}>
        <div className="font-medium mb-1" style={{ color: '#f5ede0' }}>{t('vip.rulesTitle')}</div>
        <div>· {t('vip.rule1')}</div>
        <div>· {t('vip.rule2')}</div>
        <div>· {t('vip.rule3')}</div>
        <div>· {t('vip.rule4')}</div>
      </div>
    </div>
  );
}

// ========== 店铺信息页 ==========
function StoresView({ currentLocation, onSelect, onBack }) {
  const { t } = useT();
  return (
    <div className="min-h-screen fade-up pb-8">
      <div className="px-6 pt-8 pb-4 flex items-center gap-3">
        <button onClick={onBack} className="p-2 -ml-2" style={{ color: '#f5ede0' }}>
          <ArrowLeft size={22} />
        </button>
        <div>
          <div className="text-xs tracking-[0.3em]" style={{ color: '#8a7a6e' }}>{t('stores.label')}</div>
          <div className="font-display text-2xl" style={{ color: '#f5ede0' }}>{t('stores.title')}</div>
        </div>
      </div>

      <div className="px-6 mb-6 text-xs leading-relaxed" style={{ color: '#8a7a6e' }}>
        {t('stores.intro', { km: MAX_DELIVERY_KM })}
      </div>

      <div className="px-6 space-y-4">
        {STORE_LIST.map((s, i) => {
          const isCurrent = s.id === currentLocation;
          const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(s.address + ', ' + s.cap)}`;
          return (
            <div key={s.id} className="rounded-2xl overflow-hidden fade-up"
                 style={{
                   background: '#2a2420',
                   animationDelay: `${i * 80}ms`,
                   border: `1px solid ${isCurrent ? '#e85d2f' : '#3a2e2a'}`,
                 }}>
              {/* 头部 */}
              <div className="p-5 flex items-start justify-between"
                   style={{ borderBottom: '1px solid #3a2e2a' }}>
                <div className="flex-1">
                  <div className="text-xs tracking-[0.3em]" style={{ color: isCurrent ? '#e85d2f' : '#8a7a6e' }}>
                    📍 {s.province} · VENETO
                  </div>
                  <div className="font-display text-2xl mt-1" style={{ color: '#f5ede0' }}>
                    Fude Ramen<br /><span style={{ color: '#e85d2f' }}>{s.name}</span>
                  </div>
                  {s.noteKey && <div className="text-xs mt-2" style={{ color: '#d4a574' }}>{t(s.noteKey)}</div>}
                </div>
                {isCurrent && (
                  <div className="px-2 py-1 rounded-full text-[10px] font-bold"
                       style={{ background: '#e85d2f', color: '#fff' }}>
                    {t('common.selected')}
                  </div>
                )}
              </div>

              {/* 地址 + 电话 */}
              <div className="px-5 py-4 space-y-2.5">
                <div className="flex items-start gap-2.5">
                  <span className="text-sm" style={{ color: '#8a7a6e' }}>📍</span>
                  <div className="flex-1 text-sm" style={{ color: '#f5ede0' }}>
                    {s.address}<br />
                    <span style={{ color: '#8a7a6e' }}>{s.cap}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2.5">
                  <span className="text-sm" style={{ color: '#8a7a6e' }}>📞</span>
                  <a href={`tel:${s.phone.replace(/\s/g, '')}`} className="text-sm" style={{ color: '#e85d2f' }}>
                    {s.phone}
                  </a>
                </div>
              </div>

              {/* 营业时间 */}
              <div className="px-5 pb-4">
                <div className="text-[10px] tracking-widest mb-2" style={{ color: '#8a7a6e' }}>{t('stores.hours')}</div>
                <div className="space-y-1.5">
                  {s.hours.map((h, idx) => (
                    <div key={idx} className="flex justify-between text-xs">
                      <span style={{ color: '#8a7a6e' }}>{t(`stores.day.${h.dayKey}`)}</span>
                      <span style={{ color: '#f5ede0' }}>{h.textKey ? t(h.textKey) : h.text}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 操作按钮 */}
              <div className="px-5 pb-5 flex gap-2">
                <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
                   className="flex-1 py-2.5 rounded-xl text-xs text-center font-medium transition-transform active:scale-[0.98]"
                   style={{ background: '#3a2e2a', color: '#f5ede0' }}>
                  {t('stores.navigate')}
                </a>
                <button onClick={() => onSelect(s.id)}
                        disabled={isCurrent}
                        className="flex-1 py-2.5 rounded-xl text-xs font-medium transition-transform active:scale-[0.98]"
                        style={{
                          background: isCurrent ? '#3a2e2a' : '#e85d2f',
                          color: isCurrent ? '#5a4a3e' : '#fff',
                        }}>
                  {isCurrent ? t('stores.currentSelect') : t('stores.select')}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="px-6 mt-6 text-[11px] text-center leading-relaxed" style={{ color: '#5a4a3e' }}>
        {t('stores.deliveryNote', { km: MAX_DELIVERY_KM })}<br />
        {t('stores.takeAwayNote')}
      </div>
    </div>
  );
}
