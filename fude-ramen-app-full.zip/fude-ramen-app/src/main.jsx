import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './storage-shim.js'; // 必须先于 App 导入
import './index.css';
import App from './App.jsx';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>
);
