// storage-shim.js
// 把 Claude artifact 的 window.storage API 替换成浏览器 localStorage
// 这样从 artifact 拷贝过来的代码无需改动即可工作
//
// 部署到正式后端时,把这里换成调用你 server.js 的 fetch 即可

if (typeof window !== 'undefined' && !window.storage) {
  window.storage = {
    async get(key /*, shared */) {
      const v = localStorage.getItem(key);
      if (v === null) throw new Error('Key not found: ' + key);
      return { key, value: v };
    },
    async set(key, value /*, shared */) {
      localStorage.setItem(key, value);
      return { key, value };
    },
    async delete(key /*, shared */) {
      localStorage.removeItem(key);
      return { key, deleted: true };
    },
    async list(prefix = '' /*, shared */) {
      const keys = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(prefix)) keys.push(k);
      }
      return { keys, prefix };
    },
  };
}
