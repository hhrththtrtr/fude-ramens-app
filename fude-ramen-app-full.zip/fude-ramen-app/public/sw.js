// sw.js - 简单的 PWA Service Worker
// 缓存策略: 网络优先,失败回退到缓存
// 这样新版本能立刻生效,网络不好时也能离线打开

const CACHE_NAME = 'fude-ramen-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png',
  '/apple-touch-icon.png',
];

// 安装时缓存核心资源
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

// 激活时清理旧缓存
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// 拦截 fetch - 网络优先策略
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // 跳过非 GET / 跨域 / API 请求
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) {
    // 第三方资源 (如 fuderamen.com 菜品图、Google Maps API): 网络优先, 缓存图片
    if (request.destination === 'image') {
      event.respondWith(
        caches.match(request).then((cached) => {
          if (cached) return cached;
          return fetch(request).then((resp) => {
            if (resp.ok) {
              const clone = resp.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
            }
            return resp;
          });
        })
      );
    }
    return;
  }

  // 同源: 网络优先, 失败用缓存
  event.respondWith(
    fetch(request)
      .then((resp) => {
        if (resp.ok) {
          const clone = resp.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        return resp;
      })
      .catch(() => caches.match(request).then((c) => c || caches.match('/')))
  );
});
