# 菜品照片目录 / Menu Photos

把菜品照片放到这里,文件名 = 菜品 ID。

## 命名规则

格式: `{菜品id}.{jpg|jpeg|png|webp|avif}`

例子:
- `ramen-1.jpg` → 1. Tonkotsu
- `antipasti-3.webp` → Edamame
- `uramaki-12.png` → California Roll
- `poke-1.jpg` → Poke Salmone

## 查看所有菜品 ID

打开 `src/App.jsx`,搜索 `const MENU = {`,会看到所有 117 个菜品的 id 和名字。

或者运行 `npm run dev`,在员工端"菜品照片管理"页能看到每个菜对应的 id。

## 同步到 app

放好照片后运行:

```bash
npm run sync-images
```

这会生成 `src/menu-images.json`,app 启动时会自动加载这些图片。

## 优先级

如果一个菜品有多个格式(比如 `ramen-1.jpg` 和 `ramen-1.webp`),按以下优先级:

1. `.webp` (最优,体积小)
2. `.jpg` / `.jpeg`
3. `.png`
4. `.avif`

## 拍摄建议

- 俯视角度
- 光线充足(自然光最佳)
- 尺寸 1024×1024 左右(脚本会自动用,过大会浪费带宽)
- WebP 格式压缩率最高
- 在线压缩工具: https://squoosh.app

## Git 忽略大文件

如果照片很多,建议用 Git LFS 或者放到 CDN(七牛/Cloudflare)。
