#!/usr/bin/env node
/**
 * sync-menu-images.js
 *
 * 合并菜品照片来源:
 *   1. menu-images.json 里已有的远程 URL (默认 117 个,从 fuderamen.com)
 *   2. public/menu/ 里的本地文件(可选,优先级更高)
 *
 * 命名规则: {菜品id}.{jpg|jpeg|png|webp|avif}
 * 例如: a1.jpg, rm19.webp, fu103.png
 *
 * 优先级 (高 → 低):
 *   后台员工上传 (localStorage)  >  public/menu/ 本地文件  >  menu-images.json 远程 URL
 *
 * 使用: npm run sync-images
 */

import { readdir, readFile, writeFile, access, mkdir } from 'node:fs/promises';
import { join, parse } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');
const MENU_DIR = join(ROOT, 'public', 'menu');
const OUTPUT = join(ROOT, 'src', 'menu-images.json');

const EXT_PRIORITY = ['.webp', '.jpg', '.jpeg', '.png', '.avif'];

async function main() {
  let existing = {};
  try {
    const txt = await readFile(OUTPUT, 'utf-8');
    existing = JSON.parse(txt);
  } catch {
    console.log('📄 menu-images.json 不存在,从空开始');
  }
  const remoteCount = Object.values(existing).filter((v) => v.startsWith('http')).length;

  let localFiles = [];
  try {
    await access(MENU_DIR);
    localFiles = await readdir(MENU_DIR);
  } catch {
    console.log(`📁 创建目录: ${MENU_DIR}`);
    await mkdir(MENU_DIR, { recursive: true });
  }

  const byId = {};
  for (const file of localFiles) {
    const { name, ext } = parse(file);
    const lower = ext.toLowerCase();
    if (!EXT_PRIORITY.includes(lower)) continue;
    if (!byId[name]) byId[name] = [];
    byId[name].push({ file, ext: lower });
  }

  let localOverrides = 0;
  for (const [id, candidates] of Object.entries(byId)) {
    candidates.sort((a, b) => EXT_PRIORITY.indexOf(a.ext) - EXT_PRIORITY.indexOf(b.ext));
    existing[id] = `/menu/${candidates[0].file}`;
    localOverrides++;
  }

  await writeFile(OUTPUT, JSON.stringify(existing, null, 2) + '\n', 'utf-8');

  console.log(`\n✅ 扫描完成`);
  console.log(`   远程 URL 保留:  ${remoteCount - localOverrides}`);
  console.log(`   本地文件覆盖:  ${localOverrides}`);
  console.log(`   总菜品照片:    ${Object.keys(existing).length}`);
  console.log(`📄 写入: ${OUTPUT}\n`);

  if (localOverrides === 0 && remoteCount > 0) {
    console.log(`💡 默认使用 fuderamen.com 的远程图片(共 ${remoteCount} 张)`);
    console.log('   要替换某张图,放本地文件到 public/menu/{id}.jpg 再次运行');
  }
}

main().catch((err) => {
  console.error('❌ 错误:', err);
  process.exit(1);
});
